<?php
namespace App\Core;

class Request {
    private array $params = [];

    public function method(): string {
        return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    }

    public function isPost(): bool {
        return $this->method() === 'POST';
    }

    public function isGet(): bool {
        return $this->method() === 'GET';
    }

    public function isAjax(): bool {
        return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
            || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');
    }

    public function path(): string {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH) ?? '/';
        return '/' . trim($path, '/');
    }

    public function all(): array {
        $data = array_merge($_GET, $_POST);
        return $this->sanitize($data);
    }

    public function input(string $key, $default = null) {
        $all = $this->all();
        return $all[$key] ?? $default;
    }

    public function setRouteParams(array $params): void {
        $this->params = $params;
    }

    public function param(string $key, $default = null) {
        return $this->params[$key] ?? $default;
    }

    public function file(string $key): ?array {
        return $_FILES[$key] ?? null;
    }

    private function sanitize($data) {
        if (is_array($data)) {
            foreach ($data as $k => $v) {
                $data[$k] = $this->sanitize($v);
            }
            return $data;
        }
        return is_string($data) ? trim($data) : $data;
    }
}
