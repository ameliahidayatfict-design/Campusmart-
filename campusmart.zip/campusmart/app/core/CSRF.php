<?php
namespace App\Core;

class CSRF {
    private const SESSION_KEY = '_csrf_token';

    public static function getToken(): string {
        Session::start();
        $token = Session::get(self::SESSION_KEY);
        if (empty($token)) {
            $token = bin2hex(random_bytes(32));
            Session::set(self::SESSION_KEY, $token);
        }
        return $token;
    }

    public static function validateToken(?string $token): bool {
        if (empty($token)) {
            return false;
        }
        Session::start();
        $storedToken = Session::get(self::SESSION_KEY);
        if (empty($storedToken)) {
            return false;
        }
        return hash_equals($storedToken, $token);
    }
}
