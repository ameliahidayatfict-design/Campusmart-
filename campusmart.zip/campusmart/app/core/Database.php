<?php
namespace App\Core;

use PDO;
use PDOException;

class Database {
    private static ?PDO $instance = null;

    private function __construct() {}
    private function __clone() {}

    /**
     * Get singleton PDO connection instance
     */
    public static function getConnection(): PDO {
        if (self::$instance === null) {
            $host = config('db.host', '127.0.0.1');
            $port = config('db.port', '3306');
            $dbname = config('db.name', 'campusmart');
            $user = config('db.user', 'root');
            $pass = config('db.pass', '');
            $charset = config('db.charset', 'utf8mb4');

            $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset={$charset}";

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];

            try {
                self::$instance = new PDO($dsn, $user, $pass, $options);
            } catch (PDOException $e) {
                Logger::error("Database connection failed: " . $e->getMessage());
                if (config('app.debug', false)) {
                    die("Database connection failed: " . $e->getMessage());
                } else {
                    die("Terjadi kesalahan pada sistem database. Silakan hubungi administrator.");
                }
            }
        }

        return self::$instance;
    }
}
