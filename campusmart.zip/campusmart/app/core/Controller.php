<?php
namespace App\Core;

abstract class Controller {
    protected Request $request;

    public function __construct(Request $request) {
        $this->request = $request;
    }

    protected function render(string $view, array $data = [], ?string $layout = 'student'): void {
        View::render($view, $data, $layout);
    }

    protected function json(array $data, int $status = 200): void {
        Response::json($data, $status);
    }

    protected function redirect(string $path): void {
        Response::redirect($path);
    }

    protected function validateCSRF(): void {
        $token = $this->request->input('_csrf_token');
        if (!CSRF::validateToken($token)) {
            Logger::warning("CSRF validation failed for path: " . $this->request->path());
            flash('error', 'Sesi verifikasi keamanan berakhir atau tidak valid. Silakan coba lagi.');
            $this->redirect($_SERVER['HTTP_REFERER'] ?? '/');
        }
    }
}
