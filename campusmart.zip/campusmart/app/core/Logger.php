<?php
namespace App\Core;

class Logger {
    private static string $logFile = '';

    private static function init(): void {
        if (empty(self::$logFile)) {
            $logDir = dirname(__DIR__, 2) . '/storage/logs';
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0755, true);
            }
            self::$logFile = $logDir . '/app.log';
        }
    }

    public static function log(string $level, string $message, array $context = []): void {
        self::init();

        // Sanitize context for sensitive keys
        $sanitizedContext = self::sanitize($context);
        $contextStr = !empty($sanitizedContext) ? ' ' . json_encode($sanitizedContext, JSON_UNESCAPED_SLASHES) : '';
        $date = date('Y-m-d H:i:s');
        $logEntry = "[{$date}] [{$level}] {$message}{$contextStr}" . PHP_EOL;

        @file_put_contents(self::$logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }

    public static function info(string $message, array $context = []): void {
        self::log('INFO', $message, $context);
    }

    public static function warning(string $message, array $context = []): void {
        self::log('WARNING', $message, $context);
    }

    public static function error(string $message, array $context = []): void {
        self::log('ERROR', $message, $context);
    }

    private static function sanitize(array $data): array {
        $sensitiveKeys = ['password', 'password_hash', 'password_confirmation', 'token', '_csrf_token', 'credit_card', 'secret'];
        foreach ($data as $key => $value) {
            if (in_array(strtolower($key), $sensitiveKeys, true)) {
                $data[$key] = '***REDACTED***';
            } elseif (is_array($value)) {
                $data[$key] = self::sanitize($value);
            }
        }
        return $data;
    }
}
