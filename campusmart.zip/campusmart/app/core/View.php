<?php
namespace App\Core;

class View {
    public static function render(string $viewPath, array $data = [], ?string $layout = 'student'): void {
        $viewsDir = config('paths.views', dirname(__DIR__, 2) . '/views');
        $viewFile = $viewsDir . '/' . str_replace('.', '/', $viewPath) . '.php';

        if (!file_exists($viewFile)) {
            Logger::error("View not found: {$viewPath} ({$viewFile})");
            Response::status(500);
            die("View template tidak ditemukan: " . (config('app.debug') ? e($viewFile) : ''));
        }

        // Extract variables to local scope
        extract($data, EXTR_SKIP);

        if ($layout === null) {
            require $viewFile;
            return;
        }

        // Capture view content
        ob_start();
        require $viewFile;
        $content = ob_get_clean();

        // Render within specified layout
        $layoutFile = $viewsDir . '/layouts/' . $layout . '.php';
        if (!file_exists($layoutFile)) {
            Logger::error("Layout not found: {$layout} ({$layoutFile})");
            echo $content;
            return;
        }

        require $layoutFile;
    }
}
