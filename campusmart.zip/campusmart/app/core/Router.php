<?php
namespace App\Core;

class Router {
    private array $routes = [];

    public function get(string $path, $handler, array $middleware = []): void {
        $this->addRoute('GET', $path, $handler, $middleware);
    }

    public function post(string $path, $handler, array $middleware = []): void {
        $this->addRoute('POST', $path, $handler, $middleware);
    }

    private function addRoute(string $method, string $path, $handler, array $middleware): void {
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[^/]+)', $path);
        $pattern = "#^" . rtrim($pattern, '/') . "$#";
        if ($path === '/' || $path === '') {
            $pattern = "#^/$#";
        }

        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'pattern' => $pattern,
            'handler' => $handler,
            'middleware' => $middleware,
        ];
    }

    public function dispatch(Request $request): void {
        $method = $request->method();
        $path = $request->path();
        if ($path !== '/') {
            $path = rtrim($path, '/');
        }

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }

            if (preg_match($route['pattern'], $path, $matches)) {
                $params = [];
                foreach ($matches as $key => $value) {
                    if (is_string($key)) {
                        $params[$key] = urldecode($value);
                    }
                }
                $request->setRouteParams($params);

                // Run route middleware if defined
                foreach ($route['middleware'] as $mw) {
                    if (is_callable($mw)) {
                        $res = $mw($request);
                        if ($res === false) return;
                    } elseif (is_string($mw) && class_exists($mw)) {
                        $mwObj = new $mw();
                        if (method_exists($mwObj, 'handle')) {
                            $res = $mwObj->handle($request);
                            if ($res === false) return;
                        }
                    }
                }

                $handler = $route['handler'];

                if (is_callable($handler)) {
                    call_user_func($handler, $request, ...array_values($params));
                    return;
                }

                if (is_array($handler)) {
                    [$class, $action] = $handler;
                    if (class_exists($class)) {
                        $controller = new $class($request);
                        if (method_exists($controller, $action)) {
                            call_user_func_array([$controller, $action], array_values($params));
                            return;
                        }
                    }
                }

                Logger::error("Handler not found for route: {$path}");
                Response::status(500);
                die("Handler controller tidak ditemukan.");
            }
        }

        // Route not found -> 404
        Logger::info("Route not found: [{$method}] {$path}");
        Response::status(404);
        View::render('errors.404', ['title' => 'Halaman Tidak Ditemukan'], 'student');
    }
}
