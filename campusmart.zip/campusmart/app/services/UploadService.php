<?php
namespace App\Services;

class UploadService {
    private const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp'];
    private const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
    private const MAX_FILE_SIZE = 2097152; // 2MB

    public static function handleImageUpload(?array $file, string $subfolder = 'products'): array {
        if (!$file || empty($file['tmp_name']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
            return ['success' => true, 'path' => null];
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'error' => 'Gagal mengunggah file (Kode error: ' . $file['error'] . ').'];
        }

        if ($file['size'] > self::MAX_FILE_SIZE) {
            return ['success' => false, 'error' => 'Ukuran file gambar maksimal 2MB.'];
        }

        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, self::ALLOWED_EXTENSIONS, true)) {
            return ['success' => false, 'error' => 'Format file tidak didukung. Hanya file JPG, PNG, atau WebP yang diperbolehkan.'];
        }

        // Validate MIME type securely
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mimeType, self::ALLOWED_MIME_TYPES, true)) {
            return ['success' => false, 'error' => 'Tipe konten file tidak valid.'];
        }

        // Destination folder inside public/uploads/{subfolder}
        $targetDir = dirname(__DIR__, 2) . '/public/uploads/' . $subfolder;
        if (!is_dir($targetDir)) {
            @mkdir($targetDir, 0755, true);
        }

        $newFileName = bin2hex(random_bytes(16)) . '.' . $extension;
        $destination = $targetDir . '/' . $newFileName;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            return ['success' => false, 'error' => 'Gagal menyimpan file gambar ke server.'];
        }

        return [
            'success' => true,
            'path' => '/uploads/' . $subfolder . '/' . $newFileName,
        ];
    }
}
