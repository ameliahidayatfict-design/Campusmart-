<?php
/**
 * Global CampusMart Helper Functions
 */

use App\Core\Session;
use App\Core\CSRF;

/**
 * Escape HTML output to prevent XSS
 */
function e(?string $value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Format currency to Indonesian Rupiah
 */
function rupiah($nominal): string {
    $num = (float)($nominal ?? 0);
    return 'Rp ' . number_format($num, 0, ',', '.');
}

/**
 * Return asset URL
 */
function asset(string $path): string {
    $cleanPath = '/' . ltrim($path, '/');
    return $cleanPath;
}

/**
 * Generate normalized site URL
 */
function url(string $path = ''): string {
    $cleanPath = '/' . ltrim($path, '/');
    return $cleanPath;
}

/**
 * Generate or get CSRF token
 */
function csrf_token(): string {
    return CSRF::getToken();
}

/**
 * Generate hidden CSRF input field
 */
function csrf_field(): string {
    $token = csrf_token();
    return '<input type="hidden" name="_csrf_token" value="' . e($token) . '">';
}

/**
 * Set or get flash message
 */
function flash(string $key, ?string $message = null) {
    if ($message !== null) {
        Session::set('flash_' . $key, $message);
        return;
    }
    $val = Session::get('flash_' . $key);
    Session::remove('flash_' . $key);
    return $val;
}

/**
 * Check if flash message exists
 */
function has_flash(string $key): bool {
    return Session::get('flash_' . $key) !== null;
}

/**
 * Get authenticated user data
 */
function auth_user(): ?array {
    return Session::get('user');
}

/**
 * Check if user is logged in
 */
function is_logged_in(): bool {
    return Session::get('user') !== null;
}

/**
 * Check if current user has admin role
 */
function is_admin(): bool {
    $user = auth_user();
    return $user && isset($user['role']) && $user['role'] === 'admin';
}

/**
 * Old input retrieval for form error recovery
 */
function old(string $key, $default = '') {
    $oldInput = Session::get('old_input', []);
    return $oldInput[$key] ?? $default;
}

/**
 * Clear old input
 */
function clear_old_input(): void {
    Session::remove('old_input');
}
