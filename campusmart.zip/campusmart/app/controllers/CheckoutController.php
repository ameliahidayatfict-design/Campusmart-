<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Core\CSRF;
use App\Models\Cart;
use App\Models\Order;
use App\Models\User;
use App\Models\Setting;
use App\Services\UploadService;

class CheckoutController extends Controller {

    public function index(): void {
        $user = auth_user();
        if (!$user) {
            flash('error', 'Silakan masuk terlebih dahulu untuk melanjutkan proses checkout.');
            $this->redirect('/login');
            return;
        }

        $userId = (int)$user['id'];
        $totals = Cart::getTotals($userId);

        if (empty($totals['items'])) {
            flash('error', 'Keranjang belanja Anda masih kosong. Silakan pilih produk terlebih dahulu.');
            $this->redirect('/cart');
            return;
        }

        if ($totals['has_invalid']) {
            flash('error', 'Terdapat produk yang stoknya tidak mencukupi atau tidak aktif. Silakan sesuaikan keranjang Anda.');
            $this->redirect('/cart');
            return;
        }

        $userData = User::findById($userId);
        $settings = Setting::all();

        $this->render('checkout.index', [
            'title' => 'Checkout Pesanan — CampusMart',
            'items' => $totals['items'],
            'itemCount' => $totals['item_count'],
            'subtotal' => $totals['subtotal'],
            'total' => $totals['total'],
            'user' => $userData,
            'settings' => $settings,
            'old' => Session::flash('old') ?? [],
            'errors' => Session::flash('validation_errors') ?? [],
        ], 'student');
    }

    public function process(): void {
        if (!CSRF::validateToken($this->request->input('_csrf_token'))) {
            flash('error', 'Token keamanan tidak valid. Silakan coba kirim ulang.');
            $this->redirect('/checkout');
            return;
        }

        $user = auth_user();
        if (!$user) {
            flash('error', 'Sesi login telah berakhir.');
            $this->redirect('/login');
            return;
        }

        $userId = (int)$user['id'];
        $customerName = trim($this->request->input('customer_name') ?? '');
        $customerEmail = trim($this->request->input('customer_email') ?? '');
        $customerPhone = trim($this->request->input('customer_phone') ?? '');
        $customerNote = trim($this->request->input('customer_note') ?? '');
        $paymentMethod = trim($this->request->input('payment_method') ?? '');

        $errors = [];

        if (empty($customerName)) {
            $errors['customer_name'] = 'Nama lengkap wajib diisi.';
        }

        if (empty($customerEmail) || !filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
            $errors['customer_email'] = 'Alamat email pemesan tidak valid.';
        }

        if (!in_array($paymentMethod, ['qris', 'cod'], true)) {
            $errors['payment_method'] = 'Silakan pilih metode pembayaran yang valid (QRIS atau COD).';
        }

        if (!empty($errors)) {
            Session::flash('validation_errors', $errors);
            Session::flash('old', [
                'customer_name' => $customerName,
                'customer_email' => $customerEmail,
                'customer_phone' => $customerPhone,
                'customer_note' => $customerNote,
                'payment_method' => $paymentMethod,
            ]);
            $this->redirect('/checkout');
            return;
        }

        // Handle optional initial payment proof upload
        $proofPath = null;
        if ($paymentMethod === 'qris' && isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploadResult = UploadService::handleImageUpload($_FILES['payment_proof'], 'payments');
            if (!$uploadResult['success']) {
                flash('error', $uploadResult['error']);
                Session::flash('old', [
                    'customer_name' => $customerName,
                    'customer_email' => $customerEmail,
                    'customer_phone' => $customerPhone,
                    'customer_note' => $customerNote,
                    'payment_method' => $paymentMethod,
                ]);
                $this->redirect('/checkout');
                return;
            }
            $proofPath = $uploadResult['path'];
        }

        $result = Order::createOrder(
            $userId,
            $customerName,
            $customerEmail,
            $customerPhone ?: null,
            $customerNote ?: null,
            $paymentMethod,
            $proofPath
        );

        if (!$result['success']) {
            flash('error', $result['message']);
            $this->redirect('/checkout');
            return;
        }

        flash('success', 'Pesanan Anda dengan kode #' . $result['order_code'] . ' berhasil dibuat!');
        $this->redirect('/orders/' . $result['order_code']);
    }

    public function uploadProof(string $orderCode): void {
        if (!CSRF::validateToken($this->request->input('_csrf_token'))) {
            flash('error', 'Token keamanan tidak valid.');
            $this->redirect('/orders');
            return;
        }

        $order = Order::findByCode($orderCode);

        if (!$order) {
            flash('error', 'Pesanan tidak ditemukan.');
            $this->redirect('/orders');
            return;
        }

        $user = auth_user();
        $userId = (int)$user['id'];

        if ((int)$order['user_id'] !== $userId) {
            flash('error', 'Anda tidak memiliki akses ke pesanan ini.');
            $this->redirect('/orders');
            return;
        }

        if ($order['payment_method'] !== 'qris') {
            flash('error', 'Metode pembayaran pesanan ini bukan QRIS.');
            $this->redirect('/orders/' . $orderCode);
            return;
        }

        if ($order['payment_status'] === 'paid') {
            flash('error', 'Pembayaran pesanan ini sudah terverifikasi lunas.');
            $this->redirect('/orders/' . $orderCode);
            return;
        }

        if (!isset($_FILES['payment_proof']) || $_FILES['payment_proof']['error'] === UPLOAD_ERR_NO_FILE) {
            flash('error', 'Silakan pilih file bukti pembayaran terlebih dahulu.');
            $this->redirect('/orders/' . $orderCode);
            return;
        }

        $uploadResult = UploadService::handleImageUpload($_FILES['payment_proof'], 'payments');
        if (!$uploadResult['success']) {
            flash('error', $uploadResult['error']);
            $this->redirect('/orders/' . $orderCode);
            return;
        }

        $updated = Order::updatePaymentProof((int)$order['id'], $uploadResult['path'], $userId);
        if ($updated) {
            flash('success', 'Bukti pembayaran berhasil diunggah! Admin akan segera memverifikasi pesanan Anda.');
        } else {
            flash('error', 'Gagal memperbarui bukti pembayaran.');
        }

        $this->redirect('/orders/' . $orderCode);
    }
}
