<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Category;

class CategoryController extends Controller {
    public function index(): void {
        $categories = Category::all(true);

        $this->render('categories.index', [
            'title' => 'Kategori Produk Kampus — CampusMart',
            'categories' => $categories,
        ], 'student');
    }
}
