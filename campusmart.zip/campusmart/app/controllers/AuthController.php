<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\User;

class AuthController extends Controller {
    public function showLogin(): void {
        $this->render('auth.login', [
            'title' => 'Masuk — CampusMart',
        ], 'auth');
    }

    public function login(): void {
        $this->validateCSRF();

        $email = trim($this->request->input('email', ''));
        $password = $this->request->input('password', '');
        $remember = (bool)$this->request->input('remember', false);

        // Rate limiting check
        $attempts = (int)Session::get('login_attempts', 0);
        $lastAttemptTime = (int)Session::get('last_login_attempt', 0);

        if ($attempts >= 5 && (time() - $lastAttemptTime) < 300) {
            $remaining = ceil((300 - (time() - $lastAttemptTime)) / 60);
            flash('error', "Terlalu banyak percobaan gagal. Silakan tunggu {$remaining} menit sebelum mencoba lagi.");
            $this->redirect('/login');
            return;
        }

        if (empty($email) || empty($password)) {
            flash('error', 'Silakan masukkan email dan password.');
            $this->redirect('/login');
            return;
        }

        $user = User::findByEmail($email);

        if (!$user || !password_verify($password, $user['password_hash'])) {
            Session::set('login_attempts', $attempts + 1);
            Session::set('last_login_attempt', time());
            flash('error', 'Kombinasi email atau password tidak sesuai.');
            $this->redirect('/login');
            return;
        }

        if ($user['status'] !== 'active') {
            flash('error', 'Akun Anda sedang ditangguhkan. Silakan hubungi admin kampus.');
            $this->redirect('/login');
            return;
        }

        // Reset rate limit on success
        Session::remove('login_attempts');
        Session::remove('last_login_attempt');

        // Regenerate session ID to prevent session fixation
        Session::regenerate();

        // Store user in session
        Session::set('user', [
            'id' => (int)$user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role'],
            'student_id' => $user['student_id'] ?? null,
        ]);

        flash('success', 'Selamat datang kembali, ' . $user['name'] . '!');

        if ($user['role'] === 'admin') {
            $this->redirect('/admin');
        } else {
            $intended = Session::get('intended_url', '/');
            Session::remove('intended_url');
            $this->redirect($intended);
        }
    }

    public function showRegister(): void {
        $this->render('auth.register', [
            'title' => 'Daftar Akun Mahasiswa — CampusMart',
        ], 'auth');
    }

    public function register(): void {
        $this->validateCSRF();

        $name = trim($this->request->input('name', ''));
        $email = trim($this->request->input('email', ''));
        $phone = trim($this->request->input('phone', ''));
        $studentId = trim($this->request->input('student_id', ''));
        $password = $this->request->input('password', '');
        $passwordConfirm = $this->request->input('password_confirmation', '');
        $terms = $this->request->input('terms');

        // Validation
        if (empty($name) || empty($email) || empty($password)) {
            flash('error', 'Nama lengkap, email, dan password wajib diisi.');
            $this->redirect('/register');
            return;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Format email tidak valid.');
            $this->redirect('/register');
            return;
        }

        if (!User::isEmailUnique($email)) {
            flash('error', 'Email "' . $email . '" sudah terdaftar. Silakan masuk menggunakan akun tersebut.');
            $this->redirect('/register');
            return;
        }

        if (strlen($password) < 6) {
            flash('error', 'Password minimal terdiri dari 6 karakter.');
            $this->redirect('/register');
            return;
        }

        if ($password !== $passwordConfirm) {
            flash('error', 'Konfirmasi password tidak cocok.');
            $this->redirect('/register');
            return;
        }

        if (empty($terms)) {
            flash('error', 'Anda harus menyetujui Syarat & Ketentuan yang berlaku.');
            $this->redirect('/register');
            return;
        }

        // Create new student account (strictly student role, no public admin creation)
        $userId = User::create([
            'name' => $name,
            'email' => $email,
            'password_hash' => password_hash($password, PASSWORD_BCRYPT),
            'student_id' => !empty($studentId) ? $studentId : null,
            'phone' => !empty($phone) ? $phone : null,
            'role' => 'student',
            'status' => 'active',
        ]);

        // Auto login
        Session::regenerate();
        Session::set('user', [
            'id' => $userId,
            'name' => $name,
            'email' => $email,
            'role' => 'student',
            'student_id' => $studentId,
        ]);

        flash('success', 'Akun mahasiswa Anda berhasil dibuat! Selamat berbelanja di CampusMart.');
        $this->redirect('/');
    }

    public function logout(): void {
        if ($this->request->method() === 'POST' && $this->request->input('_csrf_token')) {
            $this->validateCSRF();
        }
        Session::destroy();
        Session::start();
        flash('success', 'Anda telah berhasil keluar dari sistem.');
        $this->redirect('/login');
    }
}
