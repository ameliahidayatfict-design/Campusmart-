<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use PDO;

class HomeController extends Controller {
    public function index(): void {
        $pdo = Database::getConnection();

        // 1. Fetch active categories
        $catStmt = $pdo->query("SELECT id, name, slug, icon FROM categories WHERE status = 'active' ORDER BY name ASC");
        $categories = $catStmt->fetchAll();

        // 2. Fetch latest active products with category name
        $prodStmt = $pdo->query("
            SELECT p.id, p.name, p.slug, p.price, p.stock, p.image_path, c.name as category_name
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE p.status = 'active'
            ORDER BY p.id DESC
            LIMIT 12
        ");
        $products = $prodStmt->fetchAll();

        $this->render('home.index', [
            'title' => 'Beranda — Marketplace Kampus',
            'categories' => $categories,
            'products' => $products,
        ], 'student');
    }

    public function about(): void {
        $pdo = Database::getConnection();
        $settingsStmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
        $settings = [];
        foreach ($settingsStmt->fetchAll() as $s) {
            $settings[$s['setting_key']] = $s['setting_value'];
        }

        $this->render('home.about', [
            'title' => 'Tentang CampusMart',
            'settings' => $settings,
        ], 'student');
    }
}
