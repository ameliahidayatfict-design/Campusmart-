<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Product;
use App\Models\Category;

class ProductController extends Controller {
    public function index(): void {
        $q = trim($this->request->input('q', ''));
        $categorySlug = trim($this->request->input('category', ''));
        $sort = trim($this->request->input('sort', ''));
        $page = (int)$this->request->input('page', 1);

        $filters = [
            'status' => 'active',
            'q' => $q,
            'category_slug' => $categorySlug,
            'sort' => $sort,
        ];

        $paginated = Product::paginate($filters, $page, 12);
        $categories = Category::all(true);

        $currentCategory = null;
        if (!empty($categorySlug)) {
            $currentCategory = Category::findBySlug($categorySlug);
        }

        $this->render('products.index', [
            'title' => $currentCategory ? 'Katalog ' . $currentCategory['name'] : 'Katalog Produk Mahasiswa',
            'products' => $paginated['items'],
            'total' => $paginated['total'],
            'page' => $paginated['page'],
            'perPage' => $paginated['perPage'],
            'totalPages' => $paginated['totalPages'],
            'categories' => $categories,
            'currentCategory' => $currentCategory,
            'q' => $q,
            'sort' => $sort,
        ], 'student');
    }

    public function show(string $slug): void {
        $product = Product::findBySlug($slug);

        if (!$product || $product['status'] !== 'active') {
            $this->render('errors.404', ['title' => 'Produk Tidak Ditemukan'], 'student');
            return;
        }

        // Fetch related products from same category
        $related = Product::paginate([
            'status' => 'active',
            'category_id' => $product['category_id'],
        ], 1, 4)['items'];

        // Exclude current product from related list
        $related = array_filter($related, fn($p) => $p['id'] !== $product['id']);

        $this->render('products.show', [
            'title' => $product['name'] . ' — CampusMart',
            'product' => $product,
            'related' => $related,
        ], 'student');
    }
}
