<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Order;
use App\Models\Setting;

class OrderController extends Controller {
    public function index(): void {
        $userId = (int)auth_user()['id'];
        $page = (int)$this->request->input('page', 1);

        $paginated = Order::paginate(['user_id' => $userId], $page, 10);

        $this->render('orders.index', [
            'title' => 'Riwayat Pesanan Saya — CampusMart',
            'orders' => $paginated['items'],
            'total' => $paginated['total'],
            'page' => $paginated['page'],
            'perPage' => $paginated['perPage'],
            'totalPages' => $paginated['totalPages'],
        ], 'student');
    }

    public function show(string $orderCode): void {
        $userId = (int)auth_user()['id'];
        $order = Order::findByCode($orderCode);

        if (!$order) {
            flash('error', 'Pesanan tidak ditemukan.');
            $this->redirect('/orders');
            return;
        }

        // Strict ownership check (security requirement)
        if ((int)$order['user_id'] !== $userId && !is_admin()) {
            $this->render('errors.403', ['title' => 'Akses Pesanan Ditolak'], 'student');
            return;
        }

        $items = Order::getItems((int)$order['id']);
        $histories = Order::getHistories((int)$order['id']);
        $payment = Order::getPayment((int)$order['id']);

        $this->render('orders.show', [
            'title' => 'Pesanan #' . $order['order_code'] . ' — CampusMart',
            'order' => $order,
            'items' => $items,
            'histories' => $histories,
            'payment' => $payment,
            'settings' => Setting::all(),
        ], 'student');
    }
}
