<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Core\CSRF;
use App\Models\Cart;
use App\Models\Product;

class CartController extends Controller {

    public function index(): void {
        $user = auth_user();
        if (!$user) {
            flash('error', 'Silakan masuk terlebih dahulu untuk mengakses keranjang belanja.');
            $this->redirect('/login');
            return;
        }

        $userId = (int)$user['id'];
        $totals = Cart::getTotals($userId);
        $cartCount = Cart::countItems($userId);

        $this->render('cart.index', [
            'title' => 'Keranjang Belanja — CampusMart',
            'items' => $totals['items'],
            'itemCount' => $cartCount,
            'subtotal' => $totals['subtotal'],
            'total' => $totals['total'],
            'hasInvalid' => $totals['has_invalid'],
            'errors' => $totals['errors'],
        ], 'student');
    }

    public function add(): void {
        if (!CSRF::validateToken($this->request->input('_csrf_token'))) {
            if ($this->request->isAjax()) {
                $this->json(['success' => false, 'message' => 'Token keamanan sesi tidak valid.'], 403);
                return;
            }
            flash('error', 'Token keamanan sesi tidak valid.');
            $this->redirect('/cart');
            return;
        }

        $user = auth_user();
        if (!$user) {
            if ($this->request->isAjax()) {
                $this->json(['success' => false, 'message' => 'Silakan masuk terlebih dahulu untuk belanja.', 'redirect' => '/login'], 401);
                return;
            }
            flash('error', 'Silakan masuk terlebih dahulu.');
            $this->redirect('/login');
            return;
        }

        $userId = (int)$user['id'];
        $productId = (int)$this->request->input('product_id');
        $quantity = (int)($this->request->input('quantity', 1) ?: 1);

        if ($productId <= 0) {
            if ($this->request->isAjax()) {
                $this->json(['success' => false, 'message' => 'Produk tidak valid.'], 422);
                return;
            }
            flash('error', 'Produk tidak valid.');
            $this->redirect('/products');
            return;
        }

        $result = Cart::addItem($userId, $productId, $quantity);

        if ($this->request->isAjax()) {
            $cartCount = Cart::countItems($userId);
            $totals = Cart::getTotals($userId);
            $this->json([
                'success' => $result['success'],
                'message' => $result['message'],
                'cartCount' => $cartCount,
                'subtotal' => $totals['subtotal'],
                'total' => $totals['total']
            ], $result['success'] ? 200 : 422);
            return;
        }

        if ($result['success']) {
            flash('success', $result['message']);
        } else {
            flash('error', $result['message']);
        }

        $referrer = $_SERVER['HTTP_REFERER'] ?? null;
        if ($referrer && str_contains($referrer, '/products')) {
            $this->redirect($referrer);
            return;
        }

        $this->redirect('/cart');
    }

    public function update(): void {
        if (!CSRF::validateToken($this->request->input('_csrf_token'))) {
            if ($this->request->isAjax()) {
                $this->json(['success' => false, 'message' => 'Token keamanan sesi tidak valid.'], 403);
                return;
            }
            flash('error', 'Token keamanan sesi tidak valid.');
            $this->redirect('/cart');
            return;
        }

        $user = auth_user();
        if (!$user) {
            if ($this->request->isAjax()) {
                $this->json(['success' => false, 'message' => 'Silakan masuk terlebih dahulu.', 'redirect' => '/login'], 401);
                return;
            }
            $this->redirect('/login');
            return;
        }

        $userId = (int)$user['id'];
        $productId = (int)$this->request->input('product_id');
        $quantity = (int)$this->request->input('quantity');

        if ($productId <= 0) {
            if ($this->request->isAjax()) {
                $this->json(['success' => false, 'message' => 'Produk tidak valid.'], 422);
                return;
            }
            flash('error', 'Produk tidak valid.');
            $this->redirect('/cart');
            return;
        }

        $result = Cart::updateItem($userId, $productId, $quantity);

        if ($this->request->isAjax()) {
            $cartCount = Cart::countItems($userId);
            $totals = Cart::getTotals($userId);
            $this->json([
                'success' => $result['success'],
                'message' => $result['message'],
                'cartCount' => $cartCount,
                'subtotal' => $totals['subtotal'],
                'total' => $totals['total'],
                'items' => $totals['items']
            ], $result['success'] ? 200 : 422);
            return;
        }

        if ($result['success']) {
            flash('success', $result['message']);
        } else {
            flash('error', $result['message']);
        }

        $this->redirect('/cart');
    }

    public function remove(): void {
        if (!CSRF::validateToken($this->request->input('_csrf_token'))) {
            if ($this->request->isAjax()) {
                $this->json(['success' => false, 'message' => 'Token keamanan sesi tidak valid.'], 403);
                return;
            }
            flash('error', 'Token keamanan sesi tidak valid.');
            $this->redirect('/cart');
            return;
        }

        $user = auth_user();
        if (!$user) {
            if ($this->request->isAjax()) {
                $this->json(['success' => false, 'message' => 'Silakan masuk terlebih dahulu.', 'redirect' => '/login'], 401);
                return;
            }
            $this->redirect('/login');
            return;
        }

        $userId = (int)$user['id'];
        $productId = (int)$this->request->input('product_id');

        if ($productId <= 0) {
            if ($this->request->isAjax()) {
                $this->json(['success' => false, 'message' => 'Produk tidak valid.'], 422);
                return;
            }
            flash('error', 'Produk tidak valid.');
            $this->redirect('/cart');
            return;
        }

        Cart::removeItem($userId, $productId);

        if ($this->request->isAjax()) {
            $cartCount = Cart::countItems($userId);
            $totals = Cart::getTotals($userId);
            $this->json([
                'success' => true,
                'message' => 'Produk telah dihapus dari keranjang.',
                'cartCount' => $cartCount,
                'subtotal' => $totals['subtotal'],
                'total' => $totals['total'],
                'items' => $totals['items']
            ]);
            return;
        }

        flash('success', 'Produk telah dihapus dari keranjang.');
        $this->redirect('/cart');
    }
}
