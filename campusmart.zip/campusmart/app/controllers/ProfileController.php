<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\User;
use App\Models\Order;

class ProfileController extends Controller {
    public function show(): void {
        $sessionUser = auth_user();
        $user = User::findById((int)$sessionUser['id']);

        if (!$user) {
            flash('error', 'Data pengguna tidak ditemukan.');
            $this->redirect('/login');
            return;
        }

        // Get user order count & recent orders
        $orders = Order::paginate(['user_id' => $user['id']], 1, 5)['items'];

        $this->render('profile.show', [
            'title' => 'Profil Saya — CampusMart',
            'user' => $user,
            'orders' => $orders,
        ], 'student');
    }

    public function update(): void {
        $this->validateCSRF();

        $sessionUser = auth_user();
        $userId = (int)$sessionUser['id'];
        $user = User::findById($userId);

        if (!$user) {
            flash('error', 'Sesi tidak valid.');
            $this->redirect('/login');
            return;
        }

        $name = trim($this->request->input('name', ''));
        $phone = trim($this->request->input('phone', ''));
        $studentId = trim($this->request->input('student_id', ''));
        $currentPassword = $this->request->input('current_password', '');
        $newPassword = $this->request->input('new_password', '');
        $newPasswordConfirm = $this->request->input('new_password_confirmation', '');

        if (empty($name)) {
            flash('error', 'Nama lengkap tidak boleh kosong.');
            $this->redirect('/profile');
            return;
        }

        $updateData = [
            'name' => $name,
            'phone' => $phone,
            'student_id' => $studentId,
        ];

        // Check if user wants to change password
        if (!empty($newPassword)) {
            if (empty($currentPassword) || !password_verify($currentPassword, $user['password_hash'])) {
                flash('error', 'Password saat ini salah. Perubahan password dibatalkan.');
                $this->redirect('/profile');
                return;
            }

            if (strlen($newPassword) < 6) {
                flash('error', 'Password baru minimal 6 karakter.');
                $this->redirect('/profile');
                return;
            }

            if ($newPassword !== $newPasswordConfirm) {
                flash('error', 'Konfirmasi password baru tidak cocok.');
                $this->redirect('/profile');
                return;
            }

            $updateData['password_hash'] = password_hash($newPassword, PASSWORD_BCRYPT);
        }

        User::update($userId, $updateData);

        // Update session display name
        $sessionUser['name'] = $name;
        $sessionUser['student_id'] = $studentId;
        Session::set('user', $sessionUser);

        flash('success', 'Profil Anda berhasil diperbarui.');
        $this->redirect('/profile');
    }
}
