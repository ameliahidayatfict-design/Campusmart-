<?php
namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\Category;

class CategoryController extends Controller {
    public function index(): void {
        $categories = Category::all(false);

        $this->render('admin.categories.index', [
            'title' => 'Kelola Kategori — Admin CampusMart',
            'pageHeader' => 'Kelola Kategori Produk',
            'categories' => $categories,
        ], 'admin');
    }

    public function create(): void {
        $this->render('admin.categories.create', [
            'title' => 'Tambah Kategori — Admin CampusMart',
            'pageHeader' => 'Tambah Kategori Baru',
        ], 'admin');
    }

    public function store(): void {
        $this->validateCSRF();

        $name = trim($this->request->input('name', ''));
        $slug = trim($this->request->input('slug', ''));
        $description = trim($this->request->input('description', ''));
        $icon = trim($this->request->input('icon', 'folder'));
        $status = $this->request->input('status', 'active');

        // Automatic slug generation if left empty
        if (empty($slug)) {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
        }

        // Validation
        if (empty($name)) {
            flash('error', 'Nama kategori wajib diisi.');
            $this->redirect('/admin/categories/create');
            return;
        }

        if (!Category::isSlugUnique($slug)) {
            flash('error', 'Slug kategori "' . $slug . '" sudah digunakan. Gunakan slug lain.');
            $this->redirect('/admin/categories/create');
            return;
        }

        Category::create([
            'name' => $name,
            'slug' => $slug,
            'description' => $description,
            'icon' => $icon,
            'status' => in_array($status, ['active', 'inactive'], true) ? $status : 'active',
        ]);

        flash('success', 'Kategori "' . $name . '" berhasil ditambahkan.');
        $this->redirect('/admin/categories');
    }

    public function edit(string $id): void {
        $category = Category::findById((int)$id);
        if (!$category) {
            flash('error', 'Kategori tidak ditemukan.');
            $this->redirect('/admin/categories');
            return;
        }

        $this->render('admin.categories.edit', [
            'title' => 'Edit Kategori — Admin CampusMart',
            'pageHeader' => 'Edit Kategori: ' . $category['name'],
            'category' => $category,
        ], 'admin');
    }

    public function update(string $id): void {
        $this->validateCSRF();

        $catId = (int)$id;
        $category = Category::findById($catId);
        if (!$category) {
            flash('error', 'Kategori tidak ditemukan.');
            $this->redirect('/admin/categories');
            return;
        }

        $name = trim($this->request->input('name', ''));
        $slug = trim($this->request->input('slug', ''));
        $description = trim($this->request->input('description', ''));
        $icon = trim($this->request->input('icon', 'folder'));
        $status = $this->request->input('status', 'active');

        if (empty($slug)) {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
        }

        if (empty($name)) {
            flash('error', 'Nama kategori wajib diisi.');
            $this->redirect('/admin/categories/' . $catId . '/edit');
            return;
        }

        if (!Category::isSlugUnique($slug, $catId)) {
            flash('error', 'Slug kategori "' . $slug . '" sudah digunakan oleh kategori lain.');
            $this->redirect('/admin/categories/' . $catId . '/edit');
            return;
        }

        Category::update($catId, [
            'name' => $name,
            'slug' => $slug,
            'description' => $description,
            'icon' => $icon,
            'status' => in_array($status, ['active', 'inactive'], true) ? $status : 'active',
        ]);

        flash('success', 'Kategori "' . $name . '" berhasil diperbarui.');
        $this->redirect('/admin/categories');
    }

    public function delete(string $id): void {
        $this->validateCSRF();

        $catId = (int)$id;
        $category = Category::findById($catId);
        if (!$category) {
            flash('error', 'Kategori tidak ditemukan.');
            $this->redirect('/admin/categories');
            return;
        }

        // Safety check: verify no active or inactive products are attached
        $productCount = Category::countProducts($catId);
        if ($productCount > 0) {
            flash('error', 'Tidak dapat menghapus kategori "' . $category['name'] . '" karena masih memuat ' . $productCount . ' produk. Nonaktifkan kategori atau pindahkan produk terlebih dahulu.');
            $this->redirect('/admin/categories');
            return;
        }

        Category::delete($catId);
        flash('success', 'Kategori "' . $category['name'] . '" berhasil dihapus.');
        $this->redirect('/admin/categories');
    }
}
