<?php
namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Core\Database;
use PDO;

class DashboardController extends Controller {
    public function index(): void {
        $pdo = Database::getConnection();

        // 1. Total Active Products
        $totalProducts = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE status = 'active'")->fetchColumn();

        // 2. Total Orders
        $totalOrders = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();

        // 3. Total Students
        $totalStudents = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();

        // 4. Total Paid Revenue
        $totalRevenue = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = 'paid'")->fetchColumn();

        // 5. Recent 5 orders
        $recentOrders = $pdo->query("
            SELECT o.*, u.name as customer_name
            FROM orders o
            JOIN users u ON o.user_id = u.id
            ORDER BY o.id DESC
            LIMIT 5
        ")->fetchAll();

        $this->render('admin.dashboard', [
            'title' => 'Dashboard Admin — CampusMart',
            'pageHeader' => 'Dashboard Utama',
            'totalProducts' => $totalProducts,
            'totalOrders' => $totalOrders,
            'totalStudents' => $totalStudents,
            'totalRevenue' => $totalRevenue,
            'recentOrders' => $recentOrders,
        ], 'admin');
    }
}
