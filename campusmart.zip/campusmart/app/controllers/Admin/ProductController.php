<?php
namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\Product;
use App\Models\Category;
use App\Services\UploadService;

class ProductController extends Controller {
    public function index(): void {
        $q = trim($this->request->input('q', ''));
        $categoryId = (int)$this->request->input('category_id', 0);
        $page = (int)$this->request->input('page', 1);

        $filters = [];
        if (!empty($q)) {
            $filters['q'] = $q;
        }
        if ($categoryId > 0) {
            $filters['category_id'] = $categoryId;
        }

        $paginated = Product::paginate($filters, $page, 15);
        $categories = Category::all(false);

        $this->render('admin.products.index', [
            'title' => 'Kelola Produk — Admin CampusMart',
            'pageHeader' => 'Kelola Produk CampusMart',
            'products' => $paginated['items'],
            'total' => $paginated['total'],
            'page' => $paginated['page'],
            'perPage' => $paginated['perPage'],
            'totalPages' => $paginated['totalPages'],
            'categories' => $categories,
            'selectedCategory' => $categoryId,
            'q' => $q,
        ], 'admin');
    }

    public function create(): void {
        $categories = Category::all(true);

        $this->render('admin.products.create', [
            'title' => 'Tambah Produk — Admin CampusMart',
            'pageHeader' => 'Tambah Produk Baru',
            'categories' => $categories,
        ], 'admin');
    }

    public function store(): void {
        $this->validateCSRF();

        $name = trim($this->request->input('name', ''));
        $categoryId = (int)$this->request->input('category_id', 0);
        $slug = trim($this->request->input('slug', ''));
        $price = $this->request->input('price', '');
        $stock = $this->request->input('stock', '');
        $description = trim($this->request->input('description', ''));
        $status = $this->request->input('status', 'active');

        // Validation
        if (empty($name)) {
            flash('error', 'Nama produk wajib diisi.');
            $this->redirect('/admin/products/create');
            return;
        }

        $category = Category::findById($categoryId);
        if (!$category) {
            flash('error', 'Kategori yang dipilih tidak valid.');
            $this->redirect('/admin/products/create');
            return;
        }

        if (!is_numeric($price) || (float)$price < 0) {
            flash('error', 'Harga produk harus berupa angka nominal yang valid dan tidak boleh negatif.');
            $this->redirect('/admin/products/create');
            return;
        }

        if (!is_numeric($stock) || (int)$stock < 0 || (int)$stock != $stock) {
            flash('error', 'Stok produk harus berupa bilangan bulat positif atau nol.');
            $this->redirect('/admin/products/create');
            return;
        }

        if (empty($slug)) {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
        }

        if (!Product::isSlugUnique($slug)) {
            $slug .= '-' . time();
        }

        // Image upload handling
        $imagePath = null;
        $file = $this->request->file('image');
        if ($file && !empty($file['name'])) {
            $uploadResult = UploadService::handleImageUpload($file, 'products');
            if (!$uploadResult['success']) {
                flash('error', $uploadResult['error']);
                $this->redirect('/admin/products/create');
                return;
            }
            $imagePath = $uploadResult['path'];
        }

        Product::create([
            'category_id' => $categoryId,
            'name' => $name,
            'slug' => $slug,
            'description' => $description,
            'price' => (float)$price,
            'stock' => (int)$stock,
            'image_path' => $imagePath,
            'status' => in_array($status, ['active', 'inactive'], true) ? $status : 'active',
        ]);

        flash('success', 'Produk "' . $name . '" berhasil ditambahkan ke katalog.');
        $this->redirect('/admin/products');
    }

    public function edit(string $id): void {
        $product = Product::findById((int)$id);
        if (!$product) {
            flash('error', 'Produk tidak ditemukan.');
            $this->redirect('/admin/products');
            return;
        }

        $categories = Category::all(false);

        $this->render('admin.products.edit', [
            'title' => 'Edit Produk — Admin CampusMart',
            'pageHeader' => 'Edit Produk: ' . $product['name'],
            'product' => $product,
            'categories' => $categories,
        ], 'admin');
    }

    public function update(string $id): void {
        $this->validateCSRF();

        $prodId = (int)$id;
        $product = Product::findById($prodId);
        if (!$product) {
            flash('error', 'Produk tidak ditemukan.');
            $this->redirect('/admin/products');
            return;
        }

        $name = trim($this->request->input('name', ''));
        $categoryId = (int)$this->request->input('category_id', 0);
        $slug = trim($this->request->input('slug', ''));
        $price = $this->request->input('price', '');
        $stock = $this->request->input('stock', '');
        $description = trim($this->request->input('description', ''));
        $status = $this->request->input('status', 'active');

        if (empty($name)) {
            flash('error', 'Nama produk wajib diisi.');
            $this->redirect('/admin/products/' . $prodId . '/edit');
            return;
        }

        $category = Category::findById($categoryId);
        if (!$category) {
            flash('error', 'Kategori yang dipilih tidak valid.');
            $this->redirect('/admin/products/' . $prodId . '/edit');
            return;
        }

        if (!is_numeric($price) || (float)$price < 0) {
            flash('error', 'Harga produk tidak valid.');
            $this->redirect('/admin/products/' . $prodId . '/edit');
            return;
        }

        if (!is_numeric($stock) || (int)$stock < 0) {
            flash('error', 'Stok produk tidak valid.');
            $this->redirect('/admin/products/' . $prodId . '/edit');
            return;
        }

        if (empty($slug)) {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
        }

        if (!Product::isSlugUnique($slug, $prodId)) {
            flash('error', 'Slug produk sudah digunakan oleh produk lain.');
            $this->redirect('/admin/products/' . $prodId . '/edit');
            return;
        }

        $updateData = [
            'category_id' => $categoryId,
            'name' => $name,
            'slug' => $slug,
            'description' => $description,
            'price' => (float)$price,
            'stock' => (int)$stock,
            'status' => in_array($status, ['active', 'inactive'], true) ? $status : 'active',
        ];

        // Handle optional new image upload
        $file = $this->request->file('image');
        if ($file && !empty($file['name'])) {
            $uploadResult = UploadService::handleImageUpload($file, 'products');
            if (!$uploadResult['success']) {
                flash('error', $uploadResult['error']);
                $this->redirect('/admin/products/' . $prodId . '/edit');
                return;
            }
            $updateData['image_path'] = $uploadResult['path'];
        }

        Product::update($prodId, $updateData);

        flash('success', 'Produk "' . $name . '" berhasil diperbarui.');
        $this->redirect('/admin/products');
    }

    public function delete(string $id): void {
        $this->validateCSRF();

        $prodId = (int)$id;
        $product = Product::findById($prodId);
        if (!$product) {
            flash('error', 'Produk tidak ditemukan.');
            $this->redirect('/admin/products');
            return;
        }

        // Check if product is referenced in order_items
        $ordersCount = Product::countOrders($prodId);
        if ($ordersCount > 0) {
            // Soft deactivation to protect transaction history integrity
            Product::update($prodId, [
                'category_id' => $product['category_id'],
                'name' => $product['name'],
                'slug' => $product['slug'],
                'description' => $product['description'],
                'price' => $product['price'],
                'stock' => 0,
                'status' => 'inactive',
            ]);
            flash('warning', 'Produk "' . $product['name'] . '" telah memiliki ' . $ordersCount . ' riwayat pesanan. Status dialihkan menjadi Nonaktif demi menjaga integritas data riwayat transaksi.');
            $this->redirect('/admin/products');
            return;
        }

        Product::delete($prodId);
        flash('success', 'Produk "' . $product['name'] . '" berhasil dihapus.');
        $this->redirect('/admin/products');
    }
}
