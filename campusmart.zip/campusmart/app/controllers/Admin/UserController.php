<?php
namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\User;
use App\Models\Order;

class UserController extends Controller {
    public function index(): void {
        $q = trim($this->request->input('q', ''));
        $role = trim($this->request->input('role', ''));
        $status = trim($this->request->input('status', ''));
        $page = (int)$this->request->input('page', 1);

        $filters = [];
        if (!empty($q)) $filters['q'] = $q;
        if (!empty($role)) $filters['role'] = $role;
        if (!empty($status)) $filters['status'] = $status;

        $paginated = User::paginate($filters, $page, 15);

        $this->render('admin.users.index', [
            'title' => 'Kelola Pengguna — Admin CampusMart',
            'pageHeader' => 'Kelola Pengguna',
            'users' => $paginated['items'],
            'total' => $paginated['total'],
            'page' => $paginated['page'],
            'perPage' => $paginated['perPage'],
            'totalPages' => $paginated['totalPages'],
            'q' => $q,
            'role' => $role,
            'status' => $status,
        ], 'admin');
    }

    public function show(string $id): void {
        $user = User::findById((int)$id);
        if (!$user) {
            flash('error', 'Pengguna tidak ditemukan.');
            $this->redirect('/admin/users');
            return;
        }

        // Get user order history
        $orders = Order::paginate(['user_id' => $user['id']], 1, 20)['items'];

        $this->render('admin.users.show', [
            'title' => 'Detail Pengguna: ' . $user['name'] . ' — Admin CampusMart',
            'pageHeader' => 'Detail Pengguna',
            'user' => $user,
            'orders' => $orders,
        ], 'admin');
    }

    public function toggleStatus(string $id): void {
        $this->validateCSRF();

        $userId = (int)$id;
        $user = User::findById($userId);
        if (!$user) {
            flash('error', 'Pengguna tidak ditemukan.');
            $this->redirect('/admin/users');
            return;
        }

        $newStatus = ($user['status'] === 'active') ? 'suspended' : 'active';

        // Critical safety check: Do not suspend the last remaining active admin
        if ($user['role'] === 'admin' && $newStatus === 'suspended') {
            $activeAdmins = User::countAdmins();
            if ($activeAdmins <= 1) {
                flash('error', 'Tidak dapat menangguhkan akun administrator aktif terakhir dalam sistem.');
                $this->redirect('/admin/users');
                return;
            }
        }

        User::updateStatus($userId, $newStatus);

        flash('success', 'Status akun "' . $user['name'] . '" berhasil diubah menjadi ' . ($newStatus === 'active' ? 'Aktif' : 'Ditangguhkan') . '.');
        $this->redirect('/admin/users');
    }
}
