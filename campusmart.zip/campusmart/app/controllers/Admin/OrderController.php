<?php
namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\Order;

class OrderController extends Controller {
    public function index(): void {
        $q = trim($this->request->input('q', ''));
        $status = trim($this->request->input('status', ''));
        $paymentStatus = trim($this->request->input('payment_status', ''));
        $paymentMethod = trim($this->request->input('payment_method', ''));
        $page = (int)$this->request->input('page', 1);

        $filters = [];
        if (!empty($q)) $filters['q'] = $q;
        if (!empty($status)) $filters['status'] = $status;
        if (!empty($paymentStatus)) $filters['payment_status'] = $paymentStatus;
        if (!empty($paymentMethod)) $filters['payment_method'] = $paymentMethod;

        $paginated = Order::paginate($filters, $page, 15);

        $this->render('admin.orders.index', [
            'title' => 'Kelola Pesanan — Admin CampusMart',
            'pageHeader' => 'Kelola Pesanan Masuk',
            'orders' => $paginated['items'],
            'total' => $paginated['total'],
            'page' => $paginated['page'],
            'perPage' => $paginated['perPage'],
            'totalPages' => $paginated['totalPages'],
            'q' => $q,
            'status' => $status,
            'paymentStatus' => $paymentStatus,
            'paymentMethod' => $paymentMethod,
        ], 'admin');
    }

    public function show(string $id): void {
        $order = Order::findById((int)$id);
        if (!$order) {
            flash('error', 'Pesanan tidak ditemukan.');
            $this->redirect('/admin/orders');
            return;
        }

        $items = Order::getItems((int)$order['id']);
        $histories = Order::getHistories((int)$order['id']);
        $payment = Order::getPayment((int)$order['id']);
        $allowedTransitions = Order::getAllowedTransitions($order['status']);

        $this->render('admin.orders.show', [
            'title' => 'Detail Pesanan #' . $order['order_code'] . ' — Admin CampusMart',
            'pageHeader' => 'Detail Pesanan: #' . $order['order_code'],
            'order' => $order,
            'items' => $items,
            'histories' => $histories,
            'payment' => $payment,
            'allowedTransitions' => $allowedTransitions,
        ], 'admin');
    }

    public function updateStatus(string $id): void {
        $this->validateCSRF();

        $orderId = (int)$id;
        $order = Order::findById($orderId);
        if (!$order) {
            flash('error', 'Pesanan tidak ditemukan.');
            $this->redirect('/admin/orders');
            return;
        }

        $newStatus = trim($this->request->input('status', ''));
        $note = trim($this->request->input('note', ''));
        $adminId = (int)auth_user()['id'];

        if (!Order::isTransitionAllowed($order['status'], $newStatus)) {
            flash('error', 'Perubahan status dari "' . $order['status'] . '" ke "' . $newStatus . '" tidak diizinkan oleh sistem.');
            $this->redirect('/admin/orders/' . $orderId);
            return;
        }

        $success = Order::updateStatus($orderId, $newStatus, $adminId, !empty($note) ? $note : 'Status diubah oleh admin.');

        if ($success) {
            flash('success', 'Status pesanan #' . $order['order_code'] . ' berhasil diubah menjadi ' . strtoupper(str_replace('_', ' ', $newStatus)) . '.');
        } else {
            flash('error', 'Gagal memperbarui status pesanan. Silakan coba lagi.');
        }

        $this->redirect('/admin/orders/' . $orderId);
    }

    public function updatePayment(string $id): void {
        $this->validateCSRF();

        $orderId = (int)$id;
        $order = Order::findById($orderId);
        if (!$order) {
            flash('error', 'Pesanan tidak ditemukan.');
            $this->redirect('/admin/orders');
            return;
        }

        $newPaymentStatus = trim($this->request->input('payment_status', ''));
        $adminId = (int)auth_user()['id'];

        if (!in_array($newPaymentStatus, ['unpaid', 'pending_verification', 'paid', 'rejected'], true)) {
            flash('error', 'Status pembayaran tidak valid.');
            $this->redirect('/admin/orders/' . $orderId);
            return;
        }

        if ($order['status'] === 'cancelled' && $newPaymentStatus === 'paid') {
            flash('error', 'Pesanan yang telah dibatalkan tidak dapat ditandai sebagai lunas.');
            $this->redirect('/admin/orders/' . $orderId);
            return;
        }

        Order::updatePaymentStatus($orderId, $newPaymentStatus, $adminId);

        // Also record an audit trail note in history
        $pdo = \App\Core\Database::getConnection();
        $historyStmt = $pdo->prepare("
            INSERT INTO order_status_histories (order_id, old_status, new_status, changed_by, note)
            VALUES (?, ?, ?, ?, ?)
        ");
        $historyStmt->execute([$orderId, $order['status'], $order['status'], $adminId, 'Status pembayaran diubah menjadi ' . strtoupper($newPaymentStatus)]);

        flash('success', 'Status pembayaran pesanan #' . $order['order_code'] . ' berhasil diperbarui menjadi ' . strtoupper($newPaymentStatus) . '.');
        $this->redirect('/admin/orders/' . $orderId);
    }
}
