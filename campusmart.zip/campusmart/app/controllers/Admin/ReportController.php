<?php
namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\Order;

class ReportController extends Controller {

    public function index(): void {
        $startDate = trim($this->request->input('start_date', '') ?? '');
        $endDate = trim($this->request->input('end_date', '') ?? '');
        $status = trim($this->request->input('status', '') ?? '');
        $paymentStatus = trim($this->request->input('payment_status', '') ?? '');
        $page = (int)($this->request->input('page', 1) ?: 1);

        $filters = [];
        if (!empty($startDate) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate)) {
            $filters['start_date'] = $startDate;
        }
        if (!empty($endDate) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate)) {
            $filters['end_date'] = $endDate;
        }
        if (!empty($status)) {
            $filters['status'] = $status;
        }
        if (!empty($paymentStatus)) {
            $filters['payment_status'] = $paymentStatus;
        }

        $reportData = Order::getSalesReport($filters);
        $paginatedOrders = Order::paginate($filters, $page, 15);

        $this->render('admin.reports.index', [
            'title' => 'Laporan Penjualan & Transaksi — Admin CampusMart',
            'metrics' => $reportData['metrics'],
            'topProducts' => $reportData['top_products'],
            'orders' => $paginatedOrders['items'],
            'total' => $paginatedOrders['total'],
            'page' => $paginatedOrders['page'],
            'perPage' => $paginatedOrders['perPage'],
            'totalPages' => $paginatedOrders['totalPages'],
            'filters' => [
                'start_date' => $startDate,
                'end_date' => $endDate,
                'status' => $status,
                'payment_status' => $paymentStatus,
            ],
        ], 'admin');
    }
}
