<?php
namespace App\Models;

use App\Core\Database;
use PDO;

class Cart {
    public static function getOrCreateCartId(int $userId): int {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT id FROM carts WHERE user_id = ? LIMIT 1");
        $stmt->execute([$userId]);
        $cartId = $stmt->fetchColumn();

        if ($cartId) {
            return (int)$cartId;
        }

        $insertStmt = $pdo->prepare("INSERT INTO carts (user_id) VALUES (?)");
        $insertStmt->execute([$userId]);
        return (int)$pdo->lastInsertId();
    }

    public static function getItems(int $userId): array {
        $pdo = Database::getConnection();
        $cartId = self::getOrCreateCartId($userId);

        $stmt = $pdo->prepare("
            SELECT ci.id as item_id, ci.quantity, ci.product_id,
                   p.name, p.slug, p.price, p.stock, p.image_path, p.status as product_status,
                   c.name as category_name
            FROM cart_items ci
            JOIN products p ON ci.product_id = p.id
            JOIN categories c ON p.category_id = c.id
            WHERE ci.cart_id = ?
            ORDER BY ci.id DESC
        ");
        $stmt->execute([$cartId]);
        $rows = $stmt->fetchAll();

        $items = [];
        foreach ($rows as $row) {
            $isAvailable = ($row['product_status'] === 'active' && (int)$row['stock'] > 0);
            $qty = (int)$row['quantity'];
            $stock = (int)$row['stock'];
            $price = (float)$row['price'];
            $lineTotal = $price * $qty;

            $items[] = [
                'item_id' => (int)$row['item_id'],
                'product_id' => (int)$row['product_id'],
                'name' => $row['name'],
                'slug' => $row['slug'],
                'price' => $price,
                'stock' => $stock,
                'quantity' => $qty,
                'line_total' => $lineTotal,
                'image_path' => $row['image_path'],
                'category_name' => $row['category_name'],
                'product_status' => $row['product_status'],
                'is_available' => $isAvailable,
                'is_stock_sufficient' => ($isAvailable && $qty <= $stock),
            ];
        }

        return $items;
    }

    public static function addItem(int $userId, int $productId, int $quantity = 1): array {
        if ($quantity <= 0) {
            return ['success' => false, 'message' => 'Jumlah barang harus lebih dari 0.'];
        }

        $product = Product::findById($productId);
        if (!$product || $product['status'] !== 'active') {
            return ['success' => false, 'message' => 'Produk tidak tersedia atau sedang dinonaktifkan.'];
        }

        $cartId = self::getOrCreateCartId($userId);
        $pdo = Database::getConnection();

        // Check if item already exists in cart
        $stmt = $pdo->prepare("SELECT quantity FROM cart_items WHERE cart_id = ? AND product_id = ?");
        $stmt->execute([$cartId, $productId]);
        $existingQty = $stmt->fetchColumn();

        $newQty = ($existingQty !== false) ? ((int)$existingQty + $quantity) : $quantity;

        if ($newQty > (int)$product['stock']) {
            return [
                'success' => false,
                'message' => 'Jumlah pesanan melebihi stok yang tersedia (Sisa stok: ' . (int)$product['stock'] . ' unit).'
            ];
        }

        if ($existingQty !== false) {
            $updateStmt = $pdo->prepare("UPDATE cart_items SET quantity = ?, updated_at = NOW() WHERE cart_id = ? AND product_id = ?");
            $updateStmt->execute([$newQty, $cartId, $productId]);
        } else {
            $insertStmt = $pdo->prepare("INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?, ?, ?)");
            $insertStmt->execute([$cartId, $productId, $newQty]);
        }

        return ['success' => true, 'message' => 'Produk berhasil ditambahkan ke keranjang.'];
    }

    public static function updateItem(int $userId, int $productId, int $quantity): array {
        $cartId = self::getOrCreateCartId($userId);
        $pdo = Database::getConnection();

        if ($quantity <= 0) {
            self::removeItem($userId, $productId);
            return ['success' => true, 'message' => 'Barang dihapus dari keranjang.'];
        }

        $product = Product::findById($productId);
        if (!$product || $product['status'] !== 'active') {
            return ['success' => false, 'message' => 'Produk tidak aktif atau sudah tidak dijual.'];
        }

        if ($quantity > (int)$product['stock']) {
            return [
                'success' => false,
                'message' => 'Stok tidak mencukupi. Maksimal ' . (int)$product['stock'] . ' unit.'
            ];
        }

        $stmt = $pdo->prepare("UPDATE cart_items SET quantity = ?, updated_at = NOW() WHERE cart_id = ? AND product_id = ?");
        $stmt->execute([$quantity, $cartId, $productId]);

        return ['success' => true, 'message' => 'Jumlah barang berhasil diperbarui.'];
    }

    public static function removeItem(int $userId, int $productId): bool {
        $cartId = self::getOrCreateCartId($userId);
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?");
        return $stmt->execute([$cartId, $productId]);
    }

    public static function clearCart(int $userId): bool {
        $cartId = self::getOrCreateCartId($userId);
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("DELETE FROM cart_items WHERE cart_id = ?");
        return $stmt->execute([$cartId]);
    }

    public static function countItems(int $userId): int {
        $cartId = self::getOrCreateCartId($userId);
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT COALESCE(SUM(quantity), 0) FROM cart_items WHERE cart_id = ?");
        $stmt->execute([$cartId]);
        return (int)$stmt->fetchColumn();
    }

    public static function getTotals(int $userId): array {
        $items = self::getItems($userId);
        $subtotal = 0.0;
        $hasInvalid = false;
        $errors = [];

        foreach ($items as $item) {
            if (!$item['is_available']) {
                $hasInvalid = true;
                $errors[] = 'Produk "' . $item['name'] . '" sudah tidak aktif/dijual.';
            } elseif (!$item['is_stock_sufficient']) {
                $hasInvalid = true;
                $errors[] = 'Stok untuk "' . $item['name'] . '" tidak mencukupi (Tersisa: ' . $item['stock'] . ' unit).';
            } else {
                $subtotal += $item['line_total'];
            }
        }

        return [
            'items' => $items,
            'item_count' => count($items),
            'subtotal' => $subtotal,
            'total' => $subtotal, // Ongkir internal kampus Rp 0
            'has_invalid' => $hasInvalid,
            'errors' => $errors,
        ];
    }
}
