<?php
namespace App\Models;

use App\Core\Database;
use PDO;

class Category {
    public static function all(bool $onlyActive = false): array {
        $pdo = Database::getConnection();
        $sql = "
            SELECT c.*, COUNT(p.id) as product_count 
            FROM categories c
            LEFT JOIN products p ON c.id = p.category_id AND p.status = 'active'
        ";
        if ($onlyActive) {
            $sql .= " WHERE c.status = 'active'";
        }
        $sql .= " GROUP BY c.id ORDER BY c.name ASC";
        return $pdo->query($sql)->fetchAll();
    }

    public static function findById(int $id): ?array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public static function findBySlug(string $slug): ?array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE slug = ?");
        $stmt->execute([$slug]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public static function create(array $data): int {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            INSERT INTO categories (name, slug, description, icon, status)
            VALUES (:name, :slug, :description, :icon, :status)
        ");
        $stmt->execute([
            ':name' => $data['name'],
            ':slug' => $data['slug'],
            ':description' => $data['description'] ?? null,
            ':icon' => $data['icon'] ?? 'folder',
            ':status' => $data['status'] ?? 'active',
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            UPDATE categories 
            SET name = :name, slug = :slug, description = :description, icon = :icon, status = :status
            WHERE id = :id
        ");
        return $stmt->execute([
            ':id' => $id,
            ':name' => $data['name'],
            ':slug' => $data['slug'],
            ':description' => $data['description'] ?? null,
            ':icon' => $data['icon'] ?? 'folder',
            ':status' => $data['status'] ?? 'active',
        ]);
    }

    public static function delete(int $id): bool {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public static function countProducts(int $categoryId): int {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
        $stmt->execute([$categoryId]);
        return (int)$stmt->fetchColumn();
    }

    public static function isSlugUnique(string $slug, ?int $excludeId = null): bool {
        $pdo = Database::getConnection();
        if ($excludeId !== null) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE slug = ? AND id != ?");
            $stmt->execute([$slug, $excludeId]);
        } else {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE slug = ?");
            $stmt->execute([$slug]);
        }
        return (int)$stmt->fetchColumn() === 0;
    }
}
