<?php
namespace App\Models;

use App\Core\Database;
use PDO;

class User {
    public static function findByEmail(string $email): ?array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([trim($email)]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public static function findById(int $id): ?array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public static function create(array $data): int {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            INSERT INTO users (name, email, password_hash, student_id, phone, role, status)
            VALUES (:name, :email, :password_hash, :student_id, :phone, :role, :status)
        ");
        $stmt->execute([
            ':name' => $data['name'],
            ':email' => trim($data['email']),
            ':password_hash' => $data['password_hash'],
            ':student_id' => $data['student_id'] ?? null,
            ':phone' => $data['phone'] ?? null,
            ':role' => $data['role'] ?? 'student',
            ':status' => $data['status'] ?? 'active',
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $pdo = Database::getConnection();
        $fields = [
            'name = :name',
            'phone = :phone',
            'student_id = :student_id',
        ];
        $params = [
            ':id' => $id,
            ':name' => $data['name'],
            ':phone' => $data['phone'] ?? null,
            ':student_id' => $data['student_id'] ?? null,
        ];

        if (!empty($data['password_hash'])) {
            $fields[] = 'password_hash = :password_hash';
            $params[':password_hash'] = $data['password_hash'];
        }

        if (isset($data['status'])) {
            $fields[] = 'status = :status';
            $params[':status'] = $data['status'];
        }

        $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }

    public static function updateStatus(int $id, string $status): bool {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        return $stmt->execute([$status, $id]);
    }

    public static function paginate(array $filters = [], int $page = 1, int $perPage = 15): array {
        $pdo = Database::getConnection();
        $params = [];
        $whereClauses = [];

        if (!empty($filters['role'])) {
            $whereClauses[] = "u.role = :role";
            $params[':role'] = $filters['role'];
        }

        if (!empty($filters['status'])) {
            $whereClauses[] = "u.status = :status";
            $params[':status'] = $filters['status'];
        }

        if (!empty($filters['q'])) {
            $whereClauses[] = "(u.name LIKE :search_name OR u.email LIKE :search_email OR u.student_id LIKE :search_nim)";
            $params[':search_name'] = '%' . $filters['q'] . '%';
            $params[':search_email'] = '%' . $filters['q'] . '%';
            $params[':search_nim'] = '%' . $filters['q'] . '%';
        }

        $whereSql = !empty($whereClauses) ? ' WHERE ' . implode(' AND ', $whereClauses) : '';

        // Count total
        $countSql = "SELECT COUNT(*) FROM users u {$whereSql}";
        $countStmt = $pdo->prepare($countSql);
        foreach ($params as $k => $v) {
            $countStmt->bindValue($k, $v);
        }
        $countStmt->execute();
        $total = (int)$countStmt->fetchColumn();

        $page = max(1, $page);
        $offset = ($page - 1) * $perPage;
        $totalPages = (int)ceil($total / $perPage);

        $sql = "
            SELECT u.id, u.name, u.email, u.student_id, u.phone, u.role, u.status, u.created_at,
                   (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) as order_count
            FROM users u
            {$whereSql}
            ORDER BY u.id DESC
            LIMIT :limit OFFSET :offset
        ";

        $stmt = $pdo->prepare($sql);
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v);
        }
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $items = $stmt->fetchAll();

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => $totalPages,
        ];
    }

    public static function countAdmins(): int {
        $pdo = Database::getConnection();
        return (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND status = 'active'")->fetchColumn();
    }

    public static function isEmailUnique(string $email, ?int $excludeId = null): bool {
        $pdo = Database::getConnection();
        if ($excludeId !== null) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND id != ?");
            $stmt->execute([trim($email), $excludeId]);
        } else {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
            $stmt->execute([trim($email)]);
        }
        return (int)$stmt->fetchColumn() === 0;
    }
}
