<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Logger;
use PDO;

class Order {
    private const ALLOWED_TRANSITIONS = [
        'pending' => ['confirmed', 'cancelled'],
        'confirmed' => ['processing', 'cancelled'],
        'processing' => ['ready_for_pickup', 'cancelled'],
        'ready_for_pickup' => ['completed', 'cancelled'],
        'completed' => [],
        'cancelled' => [],
    ];

    public static function getAllowedTransitions(string $currentStatus): array {
        return self::ALLOWED_TRANSITIONS[$currentStatus] ?? [];
    }

    public static function isTransitionAllowed(string $from, string $to): bool {
        $allowed = self::getAllowedTransitions($from);
        return in_array($to, $allowed, true);
    }

    public static function paginate(array $filters = [], int $page = 1, int $perPage = 15): array {
        $pdo = Database::getConnection();
        $params = [];
        $where = [];

        if (!empty($filters['status'])) {
            $where[] = "o.status = :status";
            $params[':status'] = $filters['status'];
        }

        if (!empty($filters['payment_status'])) {
            $where[] = "o.payment_status = :payment_status";
            $params[':payment_status'] = $filters['payment_status'];
        }

        if (!empty($filters['payment_method'])) {
            $where[] = "o.payment_method = :payment_method";
            $params[':payment_method'] = $filters['payment_method'];
        }

        if (!empty($filters['user_id'])) {
            $where[] = "o.user_id = :user_id";
            $params[':user_id'] = (int)$filters['user_id'];
        }

        if (!empty($filters['start_date'])) {
            $where[] = "DATE(o.created_at) >= :start_date";
            $params[':start_date'] = $filters['start_date'];
        }

        if (!empty($filters['end_date'])) {
            $where[] = "DATE(o.created_at) <= :end_date";
            $params[':end_date'] = $filters['end_date'];
        }

        if (!empty($filters['q'])) {
            $where[] = "(o.order_code LIKE :search_code OR o.customer_name LIKE :search_name OR o.customer_email LIKE :search_email)";
            $params[':search_code'] = '%' . $filters['q'] . '%';
            $params[':search_name'] = '%' . $filters['q'] . '%';
            $params[':search_email'] = '%' . $filters['q'] . '%';
        }

        $whereSql = !empty($where) ? ' WHERE ' . implode(' AND ', $where) : '';

        // Total count
        $countSql = "SELECT COUNT(*) FROM orders o {$whereSql}";
        $countStmt = $pdo->prepare($countSql);
        foreach ($params as $k => $v) {
            $countStmt->bindValue($k, $v);
        }
        $countStmt->execute();
        $total = (int)$countStmt->fetchColumn();

        $page = max(1, $page);
        $offset = ($page - 1) * $perPage;
        $totalPages = (int)ceil($total / $perPage);

        $sql = "
            SELECT o.*, u.name as user_account_name, u.student_id,
                   (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) as item_count
            FROM orders o
            JOIN users u ON o.user_id = u.id
            {$whereSql}
            ORDER BY o.id DESC
            LIMIT :limit OFFSET :offset
        ";

        $stmt = $pdo->prepare($sql);
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v);
        }
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $items = $stmt->fetchAll();

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => $totalPages,
        ];
    }

    public static function findById(int $id): ?array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT o.*, u.name as user_account_name, u.email as user_account_email, u.student_id
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.id = ?
            LIMIT 1
        ");
        $stmt->execute([$id]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public static function findByCode(string $code): ?array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT o.*, u.name as user_account_name, u.email as user_account_email, u.student_id
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_code = ?
            LIMIT 1
        ");
        $stmt->execute([trim($code)]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public static function getItems(int $orderId): array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT oi.*, p.image_path, p.slug as product_slug
            FROM order_items oi
            LEFT JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ?
            ORDER BY oi.id ASC
        ");
        $stmt->execute([$orderId]);
        return $stmt->fetchAll();
    }

    public static function getHistories(int $orderId): array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT osh.*, u.name as actor_name, u.role as actor_role
            FROM order_status_histories osh
            LEFT JOIN users u ON osh.changed_by = u.id
            WHERE osh.order_id = ?
            ORDER BY osh.created_at ASC, osh.id ASC
        ");
        $stmt->execute([$orderId]);
        return $stmt->fetchAll();
    }

    public static function getPayment(int $orderId): ?array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT p.*, u.name as verifier_name
            FROM payments p
            LEFT JOIN users u ON p.verified_by = u.id
            WHERE p.order_id = ?
            ORDER BY p.id DESC
            LIMIT 1
        ");
        $stmt->execute([$orderId]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    /**
     * Create an order with transactional row locking (SELECT ... FOR UPDATE) and stock deduction
     */
    public static function createOrder(
        int $userId,
        string $customerName,
        string $customerEmail,
        ?string $customerPhone,
        ?string $customerNote,
        string $paymentMethod,
        ?string $proofPath = null
    ): array {
        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            $cartId = Cart::getOrCreateCartId($userId);

            // Fetch cart items
            $cartStmt = $pdo->prepare("
                SELECT ci.product_id, ci.quantity
                FROM cart_items ci
                WHERE ci.cart_id = ?
            ");
            $cartStmt->execute([$cartId]);
            $cartRows = $cartStmt->fetchAll();

            if (empty($cartRows)) {
                $pdo->rollBack();
                return ['success' => false, 'message' => 'Keranjang belanja Anda masih kosong.'];
            }

            $orderItems = [];
            $subtotal = 0.0;

            // Lock products rows with FOR UPDATE to prevent race conditions
            foreach ($cartRows as $row) {
                $productId = (int)$row['product_id'];
                $requestedQty = (int)$row['quantity'];

                $prodStmt = $pdo->prepare("
                    SELECT id, name, price, stock, status 
                    FROM products 
                    WHERE id = ? 
                    FOR UPDATE
                ");
                $prodStmt->execute([$productId]);
                $product = $prodStmt->fetch();

                if (!$product || $product['status'] !== 'active') {
                    $pdo->rollBack();
                    return [
                        'success' => false,
                        'message' => 'Produk "' . ($product['name'] ?? 'Pilihan') . '" sudah tidak aktif/tersedia.'
                    ];
                }

                if ((int)$product['stock'] < $requestedQty) {
                    $pdo->rollBack();
                    return [
                        'success' => false,
                        'message' => 'Stok untuk "' . $product['name'] . '" tidak mencukupi (Tersisa: ' . (int)$product['stock'] . ' unit).'
                    ];
                }

                $unitPrice = (float)$product['price'];
                $lineTotal = $unitPrice * $requestedQty;
                $subtotal += $lineTotal;

                $orderItems[] = [
                    'product_id' => $productId,
                    'product_name' => $product['name'],
                    'unit_price' => $unitPrice,
                    'quantity' => $requestedQty,
                    'line_total' => $lineTotal,
                ];
            }

            $total = $subtotal; // Ongkir internal kampus Rp 0

            // Generate unique order code
            $orderCode = 'CM' . date('ymd') . strtoupper(bin2hex(random_bytes(2)));

            // 1. Insert Order
            $orderStmt = $pdo->prepare("
                INSERT INTO orders (order_code, user_id, customer_name, customer_email, customer_phone, customer_note, status, payment_method, payment_status, subtotal, total)
                VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)
            ");
            $initialPaymentStatus = ($paymentMethod === 'qris') ? 'pending_verification' : 'unpaid';
            $orderStmt->execute([
                $orderCode,
                $userId,
                $customerName,
                $customerEmail,
                $customerPhone,
                $customerNote,
                $paymentMethod,
                $initialPaymentStatus,
                $subtotal,
                $total
            ]);
            $orderId = (int)$pdo->lastInsertId();

            // 2. Insert Order Items & Deduct Stock
            $itemStmt = $pdo->prepare("
                INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity, line_total)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stockStmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");

            foreach ($orderItems as $item) {
                $itemStmt->execute([
                    $orderId,
                    $item['product_id'],
                    $item['product_name'],
                    $item['unit_price'],
                    $item['quantity'],
                    $item['line_total'],
                ]);

                // Deduct stock safely
                $stockStmt->execute([$item['quantity'], $item['product_id']]);
            }

            // 3. Insert Payment
            $payStmt = $pdo->prepare("
                INSERT INTO payments (order_id, method, amount, status, proof_path, reference)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $reference = 'REF-' . strtoupper($paymentMethod) . '-' . date('Ymd') . '-' . $orderId;
            $payStmt->execute([
                $orderId,
                $paymentMethod,
                $total,
                $initialPaymentStatus,
                $proofPath,
                $reference,
            ]);

            // 4. Insert Initial History
            $histStmt = $pdo->prepare("
                INSERT INTO order_status_histories (order_id, old_status, new_status, changed_by, note)
                VALUES (?, NULL, 'pending', ?, ?)
            ");
            $histNote = ($paymentMethod === 'qris') 
                ? 'Pesanan dibuat mahasiswa dengan metode QRIS (Menunggu Verifikasi)'
                : 'Pesanan dibuat mahasiswa dengan metode COD (Bayar di Tempat)';
            $histStmt->execute([$orderId, $userId, $histNote]);

            // 5. Clear User's Cart
            $clearStmt = $pdo->prepare("DELETE FROM cart_items WHERE cart_id = ?");
            $clearStmt->execute([$cartId]);

            $pdo->commit();

            return [
                'success' => true,
                'order_id' => $orderId,
                'order_code' => $orderCode,
            ];
        } catch (\Throwable $e) {
            $pdo->rollBack();
            Logger::error("Checkout transaction failed: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem saat memproses checkout: ' . $e->getMessage()
            ];
        }
    }

    public static function updateStatus(int $orderId, string $newStatus, ?int $changedBy = null, ?string $note = null): bool {
        $order = self::findById($orderId);
        if (!$order) {
            return false;
        }

        $oldStatus = $order['status'];
        if (!self::isTransitionAllowed($oldStatus, $newStatus)) {
            return false;
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            // Update orders table
            $stmt = $pdo->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$newStatus, $orderId]);

            // Insert into order_status_histories
            $historyStmt = $pdo->prepare("
                INSERT INTO order_status_histories (order_id, old_status, new_status, changed_by, note)
                VALUES (?, ?, ?, ?, ?)
            ");
            $historyStmt->execute([$orderId, $oldStatus, $newStatus, $changedBy, $note]);

            // Safe Stock Recovery & Payment Voiding: If order is cancelled, return reserved stock back to products
            if ($newStatus === 'cancelled' && $oldStatus !== 'cancelled') {
                $items = self::getItems($orderId);
                $restoreStockStmt = $pdo->prepare("UPDATE products SET stock = stock + ? WHERE id = ?");
                foreach ($items as $item) {
                    if (!empty($item['product_id'])) {
                        $restoreStockStmt->execute([$item['quantity'], $item['product_id']]);
                    }
                }

                // Void payment status on cancellation so cancelled orders are never considered paid
                $voidOrderPayStmt = $pdo->prepare("UPDATE orders SET payment_status = 'rejected', updated_at = NOW() WHERE id = ?");
                $voidOrderPayStmt->execute([$orderId]);

                $voidPayTableStmt = $pdo->prepare("UPDATE payments SET status = 'rejected', updated_at = NOW() WHERE order_id = ?");
                $voidPayTableStmt->execute([$orderId]);
            }

            $pdo->commit();
            return true;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            Logger::error("Failed to update order status: " . $e->getMessage());
            return false;
        }
    }

    public static function updatePaymentStatus(int $orderId, string $newPaymentStatus, ?int $verifiedBy = null): bool {
        $order = self::findById($orderId);
        if (!$order) {
            return false;
        }

        if ($order['status'] === 'cancelled' && $newPaymentStatus === 'paid') {
            return false;
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            // Update order payment status
            $stmt = $pdo->prepare("UPDATE orders SET payment_status = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$newPaymentStatus, $orderId]);

            // Update payments table
            $payStmt = $pdo->prepare("
                UPDATE payments 
                SET status = ?, verified_by = ?, verified_at = IF(? = 'paid', NOW(), verified_at), updated_at = NOW()
                WHERE order_id = ?
            ");
            $payStmt->execute([$newPaymentStatus, $verifiedBy, $newPaymentStatus, $orderId]);

            $pdo->commit();
            return true;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            return false;
        }
    }

    public static function updatePaymentProof(int $orderId, string $proofPath, ?int $userId = null): bool {
        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare("
                UPDATE payments 
                SET proof_path = ?, status = 'pending_verification', updated_at = NOW()
                WHERE order_id = ?
            ");
            $stmt->execute([$proofPath, $orderId]);

            $orderStmt = $pdo->prepare("
                UPDATE orders 
                SET payment_status = 'pending_verification', updated_at = NOW()
                WHERE id = ?
            ");
            $orderStmt->execute([$orderId]);

            $histStmt = $pdo->prepare("
                INSERT INTO order_status_histories (order_id, old_status, new_status, changed_by, note)
                VALUES (?, (SELECT status FROM orders WHERE id = ?), (SELECT status FROM orders WHERE id = ?), ?, 'Mahasiswa mengunggah bukti transfer pembayaran QRIS')
            ");
            $histStmt->execute([$orderId, $orderId, $orderId, $userId]);

            $pdo->commit();
            return true;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            Logger::error("Failed to update payment proof: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Sales Report Aggregations for Admin
     */
    public static function getSalesReport(array $filters = []): array {
        $pdo = Database::getConnection();
        $params = [];
        $where = [];

        if (!empty($filters['start_date'])) {
            $where[] = "DATE(o.created_at) >= :start_date";
            $params[':start_date'] = $filters['start_date'];
        }

        if (!empty($filters['end_date'])) {
            $where[] = "DATE(o.created_at) <= :end_date";
            $params[':end_date'] = $filters['end_date'];
        }

        if (!empty($filters['status'])) {
            $where[] = "o.status = :status";
            $params[':status'] = $filters['status'];
        }

        if (!empty($filters['payment_status'])) {
            $where[] = "o.payment_status = :payment_status";
            $params[':payment_status'] = $filters['payment_status'];
        }

        $whereSql = !empty($where) ? ' WHERE ' . implode(' AND ', $where) : '';

        // 1. Overall Metrics
        $metricsSql = "
            SELECT 
                COUNT(*) as total_orders,
                COALESCE(SUM(CASE WHEN o.status != 'cancelled' THEN o.total ELSE 0 END), 0) as total_gmv,
                COALESCE(SUM(CASE WHEN o.payment_status = 'paid' AND o.status != 'cancelled' THEN o.total ELSE 0 END), 0) as total_paid_revenue,
                COALESCE(SUM(CASE WHEN o.payment_status != 'paid' AND o.status != 'cancelled' THEN o.total ELSE 0 END), 0) as total_unpaid_revenue,
                COUNT(CASE WHEN o.status = 'completed' THEN 1 END) as completed_count,
                COUNT(CASE WHEN o.status = 'cancelled' THEN 1 END) as cancelled_count
            FROM orders o
            {$whereSql}
        ";
        $metricsStmt = $pdo->prepare($metricsSql);
        foreach ($params as $k => $v) {
            $metricsStmt->bindValue($k, $v);
        }
        $metricsStmt->execute();
        $metrics = $metricsStmt->fetch();

        // 2. Top Selling Products
        $topSql = "
            SELECT oi.product_name, SUM(oi.quantity) as total_qty, SUM(oi.line_total) as total_sales
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            {$whereSql}
            " . (empty($whereSql) ? "WHERE o.status != 'cancelled'" : "AND o.status != 'cancelled'") . "
            GROUP BY oi.product_name
            ORDER BY total_qty DESC
            LIMIT 5
        ";
        $topStmt = $pdo->prepare($topSql);
        foreach ($params as $k => $v) {
            $topStmt->bindValue($k, $v);
        }
        $topStmt->execute();
        $topProducts = $topStmt->fetchAll();

        return [
            'metrics' => $metrics,
            'top_products' => $topProducts,
        ];
    }
}
