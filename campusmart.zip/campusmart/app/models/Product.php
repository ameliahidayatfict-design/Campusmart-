<?php
namespace App\Models;

use App\Core\Database;
use PDO;

class Product {
    public static function paginate(array $filters = [], int $page = 1, int $perPage = 12): array {
        $pdo = Database::getConnection();
        $params = [];
        $whereClauses = [];

        if (!empty($filters['status'])) {
            $whereClauses[] = "p.status = :status";
            $params[':status'] = $filters['status'];
        }

        if (!empty($filters['category_id'])) {
            $whereClauses[] = "p.category_id = :category_id";
            $params[':category_id'] = (int)$filters['category_id'];
        }

        if (!empty($filters['category_slug'])) {
            $whereClauses[] = "c.slug = :category_slug";
            $params[':category_slug'] = $filters['category_slug'];
        }

        if (!empty($filters['q'])) {
            $whereClauses[] = "(p.name LIKE :search_name OR p.description LIKE :search_desc)";
            $params[':search_name'] = '%' . $filters['q'] . '%';
            $params[':search_desc'] = '%' . $filters['q'] . '%';
        }

        $whereSql = !empty($whereClauses) ? ' WHERE ' . implode(' AND ', $whereClauses) : '';

        // Count total records
        $countSql = "
            SELECT COUNT(*) 
            FROM products p
            JOIN categories c ON p.category_id = c.id
            {$whereSql}
        ";
        $countStmt = $pdo->prepare($countSql);
        foreach ($params as $key => $val) {
            $countStmt->bindValue($key, $val);
        }
        $countStmt->execute();
        $total = (int)$countStmt->fetchColumn();

        // Sort order
        $orderBy = "p.id DESC";
        if (!empty($filters['sort'])) {
            if ($filters['sort'] === 'price_asc') {
                $orderBy = "p.price ASC";
            } elseif ($filters['sort'] === 'price_desc') {
                $orderBy = "p.price DESC";
            } elseif ($filters['sort'] === 'name_asc') {
                $orderBy = "p.name ASC";
            }
        }

        // Pagination calculations
        $page = max(1, $page);
        $offset = ($page - 1) * $perPage;
        $totalPages = (int)ceil($total / $perPage);

        $sql = "
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products p
            JOIN categories c ON p.category_id = c.id
            {$whereSql}
            ORDER BY {$orderBy}
            LIMIT :limit OFFSET :offset
        ";

        $stmt = $pdo->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $items = $stmt->fetchAll();

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => $totalPages,
        ];
    }

    public static function findById(int $id): ?array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE p.id = ?
        ");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public static function findBySlug(string $slug): ?array {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE p.slug = ?
        ");
        $stmt->execute([$slug]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public static function create(array $data): int {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            INSERT INTO products (category_id, name, slug, description, price, stock, image_path, status)
            VALUES (:category_id, :name, :slug, :description, :price, :stock, :image_path, :status)
        ");
        $stmt->execute([
            ':category_id' => $data['category_id'],
            ':name' => $data['name'],
            ':slug' => $data['slug'],
            ':description' => $data['description'] ?? null,
            ':price' => $data['price'],
            ':stock' => $data['stock'],
            ':image_path' => $data['image_path'] ?? null,
            ':status' => $data['status'] ?? 'active',
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $pdo = Database::getConnection();
        $sql = "
            UPDATE products 
            SET category_id = :category_id,
                name = :name,
                slug = :slug,
                description = :description,
                price = :price,
                stock = :stock,
                status = :status
        ";
        $params = [
            ':id' => $id,
            ':category_id' => $data['category_id'],
            ':name' => $data['name'],
            ':slug' => $data['slug'],
            ':description' => $data['description'] ?? null,
            ':price' => $data['price'],
            ':stock' => $data['stock'],
            ':status' => $data['status'] ?? 'active',
        ];

        if (array_key_exists('image_path', $data) && $data['image_path'] !== null) {
            $sql .= ", image_path = :image_path";
            $params[':image_path'] = $data['image_path'];
        }

        $sql .= " WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }

    public static function delete(int $id): bool {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public static function countOrders(int $productId): int {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM order_items WHERE product_id = ?");
        $stmt->execute([$productId]);
        return (int)$stmt->fetchColumn();
    }

    public static function isSlugUnique(string $slug, ?int $excludeId = null): bool {
        $pdo = Database::getConnection();
        if ($excludeId !== null) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE slug = ? AND id != ?");
            $stmt->execute([$slug, $excludeId]);
        } else {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE slug = ?");
            $stmt->execute([$slug]);
        }
        return (int)$stmt->fetchColumn() === 0;
    }

    public static function countActive(): int {
        $pdo = Database::getConnection();
        return (int)$pdo->query("SELECT COUNT(*) FROM products WHERE status = 'active'")->fetchColumn();
    }
}
