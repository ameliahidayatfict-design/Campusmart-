<?php
/**
 * CampusMart Configuration Loader
 */

// Load .env file if exists in project root
$envFile = dirname(__DIR__, 2) . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        if (strpos($line, '=') !== false) {
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            // Remove wrapping quotes if present
            if (preg_match('/^"(.*)"$/', $value, $matches) || preg_match("/^'(.*)'$/", $value, $matches)) {
                $value = $matches[1];
            }
            if (!array_key_exists($key, $_SERVER) && !array_key_exists($key, $_ENV)) {
                putenv("{$key}={$value}");
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
}

$config = [
    'app' => [
        'name' => getenv('APP_NAME') ?: 'CAMPUSMART',
        'env' => getenv('APP_ENV') ?: 'development',
        'debug' => filter_var(getenv('APP_DEBUG') ?: true, FILTER_VALIDATE_BOOLEAN),
        'url' => rtrim(getenv('APP_URL') ?: 'http://localhost:8080', '/'),
        'timezone' => getenv('APP_TIMEZONE') ?: 'Asia/Jakarta',
    ],
    'db' => [
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        'port' => getenv('DB_PORT') ?: '3306',
        'name' => getenv('DB_NAME') ?: 'campusmart',
        'user' => getenv('DB_USER') ?: 'root',
        'pass' => getenv('DB_PASS') !== false ? getenv('DB_PASS') : '',
        'charset' => 'utf8mb4',
    ],
    'session' => [
        'lifetime' => (int)(getenv('SESSION_LIFETIME') ?: 7200),
        'secure_cookie' => filter_var(getenv('SESSION_SECURE_COOKIE') ?: false, FILTER_VALIDATE_BOOLEAN),
    ],
    'security' => [
        'csrf_secret' => getenv('CSRF_SECRET') ?: 'campusmart_default_secret_key_change_in_production',
    ],
    'paths' => [
        'root' => dirname(__DIR__, 2),
        'app' => dirname(__DIR__, 2) . '/app',
        'views' => dirname(__DIR__, 2) . '/views',
        'public' => dirname(__DIR__, 2) . '/public',
        'storage' => dirname(__DIR__, 2) . '/storage',
        'logs' => dirname(__DIR__, 2) . '/storage/logs',
        'uploads' => dirname(__DIR__, 2) . '/storage/uploads',
    ]
];

function config(string $key, $default = null) {
    global $config;
    $parts = explode('.', $key);
    $val = $config;
    foreach ($parts as $part) {
        if (!is_array($val) || !array_key_exists($part, $val)) {
            return $default;
        }
        $val = $val[$part];
    }
    return $val;
}

return $config;
