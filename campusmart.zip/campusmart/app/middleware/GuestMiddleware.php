<?php
namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;

class GuestMiddleware {
    public function handle(Request $request): bool {
        if (is_logged_in()) {
            if (is_admin()) {
                Response::redirect('/admin');
            } else {
                Response::redirect('/');
            }
            return false;
        }
        return true;
    }
}
