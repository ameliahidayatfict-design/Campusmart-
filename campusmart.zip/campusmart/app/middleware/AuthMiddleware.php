<?php
namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;

class AuthMiddleware {
    public function handle(Request $request): bool {
        if (!is_logged_in()) {
            flash('error', 'Silakan masuk terlebih dahulu untuk melanjutkan.');

            // Store intended URL so user returns here after login
            $referer = $_SERVER['HTTP_REFERER'] ?? null;
            if ($request->isGet()) {
                Session::set('intended_url', $request->path());
            } elseif ($referer) {
                $refPath = parse_url($referer, PHP_URL_PATH);
                if ($refPath && !str_starts_with($refPath, '/login') && !str_starts_with($refPath, '/register')) {
                    Session::set('intended_url', $refPath);
                }
            }

            if ($request->isAjax()) {
                Response::json([
                    'success' => false,
                    'redirect' => '/login',
                    'message' => 'Silakan masuk terlebih dahulu untuk menambahkan produk ke keranjang.'
                ], 401);
                return false;
            }

            Response::redirect('/login');
            return false;
        }
        return true;
    }
}
