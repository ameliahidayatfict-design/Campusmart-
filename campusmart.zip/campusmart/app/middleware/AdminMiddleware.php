<?php
namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\View;

class AdminMiddleware {
    public function handle(Request $request): bool {
        if (!is_logged_in()) {
            flash('error', 'Silakan masuk dengan akun admin.');
            Response::redirect('/login');
            return false;
        }

        if (!is_admin()) {
            Response::status(403);
            View::render('errors.403', ['title' => 'Akses Ditolak'], 'student');
            return false;
        }

        return true;
    }
}
