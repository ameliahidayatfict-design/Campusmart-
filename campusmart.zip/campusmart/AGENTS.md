# CAMPUSMART — Instructions for AI Coding Agent

## Wajib dibaca
Sebelum menulis atau mengubah kode, baca:
- `docs/README.md`
- `docs/01-project-requirements.md`
- `docs/02-ui-ux-guidelines.md`
- `docs/03-architecture-database.md`
- `docs/04-features-security.md`
- `docs/05-development-testing-deployment.md`

## Stack yang tidak boleh diganti
- PHP Native
- PDO
- MySQL/MariaDB
- HTML, CSS, JavaScript, Fetch API/AJAX bila diperlukan
- Dilarang menggunakan Laravel, CodeIgniter, atau framework backend/frontend tanpa persetujuan eksplisit.

## Prinsip implementasi
1. Ikuti requirement dan batasan client; jangan menambahkan fitur di luar scope tanpa mencatatnya sebagai usulan.
2. Gunakan struktur modular sederhana dan konsisten. Pisahkan route, controller, model, service, view, konfigurasi, dan aset.
3. Gunakan desain mobile CAMPUSMART yang diberikan sebagai referensi visual utama. Buat adaptasi desktop yang sesuai, bukan sekadar memperbesar mobile.
4. Gunakan identitas maroon dan logo resmi client. Jangan mengganti logo atau membuat identitas baru.
5. Semua query database memakai PDO prepared statements.
6. Terapkan validasi server, output escaping, password hashing, CSRF protection, session yang aman, serta RBAC pada setiap aksi terlindungi.
7. Hitung harga dan total di server. Verifikasi ulang stok dan status produk saat checkout. Gunakan transaksi database untuk pembuatan pesanan.
8. QRIS belum boleh dianggap otomatis terverifikasi sebelum mekanisme final ditentukan. Jangan membuat QRIS palsu.
9. COD tidak otomatis lunas ketika pesanan dibuat.
10. Tidak ada integrasi ekspedisi atau ongkos kirim. Proses serah-terima internal kampus harus mengikuti keputusan client.
11. Jangan menaruh secret, `.env`, log, atau dump database di public web root.
12. Jangan memasukkan data rahasia atau password ke log.

## Cara bekerja
- Kerjakan secara bertahap mengikuti 13 tahapan pada dokumen.
- Sebelum setiap tahap, sampaikan rencana ringkas dan file yang terdampak.
- Hindari menulis seluruh aplikasi sekaligus dalam satu perubahan besar.
- Jangan menimpa atau menghapus aset/file yang sudah ada tanpa memeriksa dan mempertimbangkan dampaknya.
- Setelah perubahan, jalankan `php -l` pada file PHP yang berubah dan tes relevan lainnya.
- Periksa UI pada mobile dan desktop bila ada perubahan frontend.
- Jangan menyatakan tes lulus jika belum dijalankan.
- Jika keputusan bisnis belum jelas, catat pertanyaan dan gunakan asumsi sementara yang diberi label; jangan menyamarkannya sebagai keputusan client.
- Perbarui catatan progres setelah tiap tahap.

## Larangan
- Jangan memakai query SQL dengan menggabungkan input pengguna secara langsung.
- Jangan percaya total harga, role, status pembayaran, atau status pesanan yang dikirim dari browser.
- Jangan hanya mengandalkan validasi JavaScript.
- Jangan membuat tombol yang tampak aktif tetapi tidak memiliki fungsi.
- Jangan meninggalkan placeholder, dummy data, atau link mati pada fitur yang diklaim selesai.
- Jangan menambahkan dependency besar tanpa kebutuhan yang jelas.

## Laporan akhir tiap tahap
Laporkan:
1. Ringkasan yang diimplementasikan.
2. File yang dibuat/diubah.
3. Pengujian yang benar-benar dijalankan beserta hasil.
4. Hal yang belum selesai atau keputusan yang masih menunggu client.
5. Tahap berikutnya yang disarankan.
