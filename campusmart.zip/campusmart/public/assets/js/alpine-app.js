/**
 * CAMPUSMART — Alpine.js Core Components & Live Interaction System
 * Features:
 * - Live Cart Updates & Reactive Badge Counter
 * - Animated Popup Toasts & Floating Feedback Notifications
 * - Interactive Click Ripple & Micro-Popup Animations
 * - Quick-View Animated Modal Popups
 */

document.addEventListener('alpine:init', () => {

  // 1. Global Popup Notification Store & Manager
  Alpine.data('popupNotifications', () => ({
    notifications: [],
    
    init() {
      // Listen for global notify events: window.dispatchEvent(new CustomEvent('notify', { detail: { type, title, message } }))
      window.addEventListener('notify', (e) => {
        this.add(e.detail);
      });
    },

    add({ type = 'success', title = '', message = '', duration = 3500 }) {
      const id = Date.now() + Math.random().toString(36).substring(2, 6);
      const item = { id, type, title, message, visible: true };
      this.notifications.push(item);

      if (duration > 0) {
        setTimeout(() => {
          this.remove(id);
        }, duration);
      }
    },

    remove(id) {
      const idx = this.notifications.findIndex(n => n.id === id);
      if (idx !== -1) {
        this.notifications.splice(idx, 1);
      }
    }
  }));

  // 2. Reactive Cart Badge Counter Component
  Alpine.data('cartBadge', (initialCount = 0) => ({
    count: initialCount,
    popping: false,

    init() {
      window.addEventListener('cart-updated', (e) => {
        if (typeof e.detail?.count !== 'undefined') {
          this.count = parseInt(e.detail.count) || 0;
          this.popping = true;
          setTimeout(() => { this.popping = false; }, 600);
        }
      });
    }
  }));

  // 3. Live Product Add to Cart Component
  Alpine.data('productAddToCart', (config = {}) => ({
    stock: config.stock || 0,
    isLoggedIn: !!config.isLoggedIn,
    qty: 1,
    loading: false,
    added: false,

    increment() {
      if (this.qty < this.stock) this.qty++;
    },

    decrement() {
      if (this.qty > 1) this.qty--;
    },

    async submit(formEl) {
      if (this.stock <= 0 || this.loading) return;

      this.loading = true;
      const formData = new FormData(formEl);
      formData.set('quantity', this.qty);

      try {
        const res = await fetch(formEl.action, {
          method: 'POST',
          body: formData,
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
          }
        });

        // If server responded with 401 Unauthorized or redirected to login
        if (res.status === 401 || (res.redirected && res.url.includes('/login'))) {
          window.location.href = '/login';
          return;
        }

        const data = await res.json().catch(() => null);

        if (data?.redirect) {
          window.location.href = data.redirect;
          return;
        }

        if (res.ok && data?.success) {
          this.added = true;
          // Dispatch live cart count update
          window.dispatchEvent(new CustomEvent('cart-updated', {
            detail: { count: data.cartCount }
          }));

          // Trigger animated popup notification
          window.dispatchEvent(new CustomEvent('notify', {
            detail: {
              type: 'success',
              title: 'Berhasil Masuk Keranjang! 🛒',
              message: `${this.qty} unit produk telah ditambahkan.`
            }
          }));

          setTimeout(() => { this.added = false; }, 2200);
        } else {
          window.dispatchEvent(new CustomEvent('notify', {
            detail: {
              type: 'error',
              title: 'Gagal Menambah Keranjang',
              message: data?.message || 'Terjadi kesalahan sistem.'
            }
          }));
        }
      } catch (err) {
        // Fallback natural form submit if network fails
        formEl.submit();
      } finally {
        this.loading = false;
      }
    }
  }));

  // 4. Live Interactive Cart Manager on /cart
  Alpine.data('liveCartManager', (initialTotals = {}) => ({
    subtotal: initialTotals.subtotal || 0,
    total: initialTotals.total || 0,
    itemCount: initialTotals.itemCount || 0,
    isUpdating: false,

    formatRupiah(val) {
      return 'Rp ' + Number(val).toLocaleString('id-ID');
    },

    async updateQty(productId, newQty, csrfToken, cardEl) {
      if (this.isUpdating) return;
      this.isUpdating = true;

      const fd = new FormData();
      fd.append('product_id', productId);
      fd.append('quantity', newQty);
      fd.append('_csrf_token', csrfToken);

      try {
        const res = await fetch('/cart/update', {
          method: 'POST',
          body: fd,
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
          }
        });
        const data = await res.json().catch(() => null);

        if (res.ok && data?.success) {
          this.subtotal = data.subtotal;
          this.total = data.total;
          this.itemCount = data.cartCount;

          // Dispatch navbar cart update
          window.dispatchEvent(new CustomEvent('cart-updated', {
            detail: { count: data.cartCount }
          }));

          // Micro popup feedback badge
          window.dispatchEvent(new CustomEvent('notify', {
            detail: {
              type: 'success',
              title: 'Keranjang Diperbarui',
              message: data.message || 'Kuantitas berhasil diubah.',
              duration: 2500
            }
          }));
        } else {
          window.dispatchEvent(new CustomEvent('notify', {
            detail: {
              type: 'error',
              title: 'Gagal Memperbarui',
              message: data?.message || 'Gagal mengubah jumlah.'
            }
          }));
        }
      } catch (e) {
        console.error(e);
      } finally {
        this.isUpdating = false;
      }
    },

    async removeItem(productId, csrfToken, rowEl) {
      // SweetAlert confirmation popup
      if (typeof Swal !== 'undefined') {
        const confirmResult = await Swal.fire({
          title: 'Hapus dari Keranjang?',
          text: 'Produk ini akan dikeluarkan dari keranjang belanja Anda.',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#B91C1C',
          cancelButtonColor: '#64748B',
          confirmButtonText: 'Ya, Hapus',
          cancelButtonText: 'Batal',
          reverseButtons: true,
          customClass: { popup: 'cm-swal-popup' }
        });

        if (!confirmResult.isConfirmed) return;
      } else {
        if (!confirm('Hapus produk ini dari keranjang?')) return;
      }

      const fd = new FormData();
      fd.append('product_id', productId);
      fd.append('_csrf_token', csrfToken);

      try {
        const res = await fetch('/cart/remove', {
          method: 'POST',
          body: fd,
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
          }
        });
        const data = await res.json().catch(() => null);

        if (res.ok && data?.success) {
          // Smooth row collapse animation
          if (rowEl) {
            rowEl.style.transition = 'all 0.3s ease-out';
            rowEl.style.opacity = '0';
            rowEl.style.transform = 'scale(0.95) translateY(-8px)';
            setTimeout(() => {
              rowEl.remove();
              if (data.cartCount <= 0) {
                window.location.reload();
              }
            }, 300);
          }

          this.subtotal = data.subtotal;
          this.total = data.total;
          this.itemCount = data.cartCount;

          window.dispatchEvent(new CustomEvent('cart-updated', {
            detail: { count: data.cartCount }
          }));

          window.dispatchEvent(new CustomEvent('notify', {
            detail: {
              type: 'info',
              title: 'Produk Dihapus',
              message: 'Item berhasil dikeluarkan dari keranjang.',
              duration: 2500
            }
          }));
        }
      } catch (e) {
        console.error(e);
      }
    }
  }));



});

// 6. Interactive Click Ripple & Micro-Popup Burst Animation Across Website
document.addEventListener('DOMContentLoaded', () => {
  // Global Click Ripple Animation
  document.addEventListener('click', (e) => {
    const target = e.target.closest('.btn, .icon-btn, .bottom-nav-item, .product-card, .promo-card, .badge');
    if (!target) return;

    // Create ripple circle
    const rect = target.getBoundingClientRect();
    const ripple = document.createElement('span');
    ripple.className = 'cm-click-ripple';
    
    const size = Math.max(rect.width, rect.height) * 1.5;
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;

    ripple.style.width = `${size}px`;
    ripple.style.height = `${size}px`;
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;

    // Ensure target position relative
    const style = window.getComputedStyle(target);
    if (style.position === 'static') {
      target.style.position = 'relative';
    }
    target.style.overflow = 'hidden';

    target.appendChild(ripple);
    setTimeout(() => { ripple.remove(); }, 600);
  });
});
