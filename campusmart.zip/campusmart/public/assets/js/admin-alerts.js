/**
 * CAMPUSMART — Admin SweetAlert2 Integration (Legacy Alias)
 * Delegates directly to campus-alerts.js
 */
require && console.log('Admin alerts alias loaded');
