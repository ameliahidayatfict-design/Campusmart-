/**
 * CAMPUSMART — Global SweetAlert2 Integration
 * Provides modern modals, toasts, and confirmation dialogs
 * themed to CampusMart maroon brand identity across all user & admin pages.
 */

(function () {
  'use strict';

  // Ensure SweetAlert2 is loaded
  if (typeof Swal === 'undefined') {
    console.warn('SweetAlert2 is not loaded.');
    return;
  }

  // Brand Palette
  const CM_PRIMARY = '#800020';
  const CM_DANGER  = '#B91C1C';
  const CM_MUTED   = '#64748B';

  // Create Toast Instance for non-blocking notifications
  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3500,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.onmouseenter = Swal.stopTimer;
      toast.onmouseleave = Swal.resumeTimer;
    }
  });

  // Global helper object
  window.CampusAlert = {
    toast: function (message, icon = 'success') {
      return Toast.fire({
        icon: icon,
        title: message
      });
    },

    success: function (message, title = 'Berhasil!') {
      return Swal.fire({
        icon: 'success',
        title: title,
        text: message,
        confirmButtonColor: CM_PRIMARY,
        confirmButtonText: 'OK',
        customClass: { popup: 'cm-swal-popup' }
      });
    },

    error: function (message, title = 'Perhatian') {
      return Swal.fire({
        icon: 'error',
        title: title,
        text: message,
        confirmButtonColor: CM_PRIMARY,
        confirmButtonText: 'Tutup',
        customClass: { popup: 'cm-swal-popup' }
      });
    },

    warning: function (message, title = 'Peringatan') {
      return Swal.fire({
        icon: 'warning',
        title: title,
        text: message,
        confirmButtonColor: CM_PRIMARY,
        confirmButtonText: 'Mengerti',
        customClass: { popup: 'cm-swal-popup' }
      });
    },

    info: function (message, title = 'Informasi') {
      return Swal.fire({
        icon: 'info',
        title: title,
        text: message,
        confirmButtonColor: CM_PRIMARY,
        confirmButtonText: 'OK',
        customClass: { popup: 'cm-swal-popup' }
      });
    },

    confirm: function (message, onConfirm, options = {}) {
      const isDelete = options.isDelete || 
                       message.toLowerCase().includes('hapus') || 
                       message.toLowerCase().includes('nonaktif') || 
                       message.toLowerCase().includes('keluar') ||
                       message.toLowerCase().includes('batal');

      return Swal.fire({
        title: options.title || (isDelete ? 'Konfirmasi Tindakan' : 'Apakah Anda yakin?'),
        text: message,
        icon: isDelete ? 'warning' : 'question',
        showCancelButton: true,
        confirmButtonColor: isDelete ? CM_DANGER : CM_PRIMARY,
        cancelButtonColor: CM_MUTED,
        confirmButtonText: options.confirmText || (isDelete ? 'Ya, Lanjutkan' : 'Ya, Setuju'),
        cancelButtonText: options.cancelText || 'Batal',
        reverseButtons: true,
        focusCancel: isDelete,
        customClass: { popup: 'cm-swal-popup' }
      }).then((result) => {
        if (result.isConfirmed && typeof onConfirm === 'function') {
          onConfirm();
        }
        return result;
      });
    }
  };

  // 1. Process Flash Messages on Page Load with SweetAlert
  document.addEventListener('DOMContentLoaded', function () {
    const flashEls = document.querySelectorAll('.alert-auto-dismiss, [data-flash]');
    flashEls.forEach((el) => {
      let type = el.getAttribute('data-flash') || '';
      if (!type) {
        if (el.classList.contains('alert-success')) type = 'success';
        else if (el.classList.contains('alert-danger')) type = 'error';
        else if (el.classList.contains('alert-warning')) type = 'warning';
        else if (el.classList.contains('alert-info')) type = 'info';
      }

      const text = el.getAttribute('data-message') || (el.querySelector('span') ? el.querySelector('span').innerText : el.innerText);
      const cleanText = (text || '').trim();

      if (cleanText) {
        if (type === 'success') {
          // If message is order confirmation or lengthy, show modal; else toast
          if (cleanText.toLowerCase().includes('pesanan') && cleanText.includes('#')) {
            CampusAlert.success(cleanText, 'Pesanan Berhasil Dibuat! 🎉');
          } else {
            CampusAlert.toast(cleanText, 'success');
          }
        } else if (type === 'error') {
          CampusAlert.error(cleanText);
        } else if (type === 'warning') {
          CampusAlert.warning(cleanText);
        } else if (type === 'info') {
          CampusAlert.info(cleanText);
        }
      }

      // Remove the inline flash DOM element so only SweetAlert is visible
      el.remove();
    });
  });

  // 2. Intercept Form Submissions with Confirmations
  document.addEventListener('submit', function (e) {
    const form = e.target;
    if (!form || form.tagName !== 'FORM') return;

    // Already confirmed through SweetAlert
    if (form.dataset.swalConfirmed === 'true') {
      return;
    }

    let confirmMsg = form.dataset.confirm;
    const onsubmitAttr = form.getAttribute('onsubmit');

    if (!confirmMsg && onsubmitAttr && onsubmitAttr.includes('confirm(')) {
      const match = onsubmitAttr.match(/confirm\s*\(\s*['"]([^'"]+)['"]\s*\)/);
      if (match) {
        confirmMsg = match[1];
      }
    }

    if (!confirmMsg && e.submitter && e.submitter.dataset.confirm) {
      confirmMsg = e.submitter.dataset.confirm;
    }

    if (confirmMsg) {
      e.preventDefault();
      e.stopImmediatePropagation();

      const isDelete = confirmMsg.toLowerCase().includes('hapus') || 
                       confirmMsg.toLowerCase().includes('nonaktif') || 
                       confirmMsg.toLowerCase().includes('keluar') ||
                       confirmMsg.toLowerCase().includes('batal');

      Swal.fire({
        title: isDelete ? 'Konfirmasi Tindakan' : 'Konfirmasi Aksi',
        text: confirmMsg,
        icon: isDelete ? 'warning' : 'question',
        showCancelButton: true,
        confirmButtonColor: isDelete ? CM_DANGER : CM_PRIMARY,
        cancelButtonColor: CM_MUTED,
        confirmButtonText: isDelete ? 'Ya, Lanjutkan' : 'Ya, Setuju',
        cancelButtonText: 'Batal',
        reverseButtons: true,
        focusCancel: isDelete,
        customClass: { popup: 'cm-swal-popup' }
      }).then((result) => {
        if (result.isConfirmed) {
          form.dataset.swalConfirmed = 'true';
          // Preserve clicked submitter button value if present
          if (e.submitter && e.submitter.name) {
            const hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = e.submitter.name;
            hidden.value = e.submitter.value || '';
            form.appendChild(hidden);
          }
          form.submit();
        }
      });
    }
  }, true);

  // 3. Intercept Links with data-confirm
  document.addEventListener('click', function (e) {
    const link = e.target.closest('a[data-confirm]');
    if (!link) return;

    e.preventDefault();
    const confirmMsg = link.dataset.confirm;
    const isDelete = confirmMsg.toLowerCase().includes('hapus') || 
                     confirmMsg.toLowerCase().includes('batal') ||
                     confirmMsg.toLowerCase().includes('keluar');

    Swal.fire({
      title: isDelete ? 'Konfirmasi Tindakan' : 'Konfirmasi',
      text: confirmMsg,
      icon: isDelete ? 'warning' : 'question',
      showCancelButton: true,
      confirmButtonColor: isDelete ? CM_DANGER : CM_PRIMARY,
      cancelButtonColor: CM_MUTED,
      confirmButtonText: isDelete ? 'Ya, Lanjutkan' : 'Ya, Setuju',
      cancelButtonText: 'Batal',
      reverseButtons: true,
      customClass: { popup: 'cm-swal-popup' }
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = link.href;
      }
    });
  });

})();
