<?php
/**
 * CampusMart — Front Controller & Entry Point
 * All web requests are dispatched through this file.
 */

declare(strict_types=1);

// 1. PSR-4 Class Autoloader for 'App\' namespace
spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    $baseDir = dirname(__DIR__) . '/app/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});

// 2. Load Configuration and Helper Functions
require_once dirname(__DIR__) . '/app/config/config.php';
require_once dirname(__DIR__) . '/app/helpers/helpers.php';

// 3. Set Application Timezone
date_default_timezone_set(config('app.timezone', 'Asia/Jakarta'));

// 4. Configure Error Reporting & Custom Exception Handler
$isDebug = config('app.debug', false);
if ($isDebug) {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(0);
}

set_exception_handler(function (Throwable $e) use ($isDebug): void {
    \App\Core\Logger::error("Unhandled Exception: " . $e->getMessage(), [
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString(),
    ]);

    \App\Core\Response::status(500);
    if ($isDebug) {
        echo "<div style='font-family: sans-serif; padding: 2rem; background: #fff0f0; border-left: 4px solid #b91c1c;'>";
        echo "<h2 style='color: #b91c1c;'>Unhandled Exception</h2>";
        echo "<p><strong>Message:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<p><strong>File:</strong> " . htmlspecialchars($e->getFile()) . " (line " . $e->getLine() . ")</p>";
        echo "<pre style='background: #fff; padding: 1rem; border: 1px solid #ddd;'>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
        echo "</div>";
    } else {
        \App\Core\View::render('errors.500', ['title' => 'Terjadi Kesalahan Server'], 'student');
    }
    exit;
});

// 5. Initialize Secure Session
\App\Core\Session::start();

// 6. Router & Request Dispatching
$router = new \App\Core\Router();
require_once dirname(__DIR__) . '/routes/web.php';

$request = new \App\Core\Request();
$router->dispatch($request);
