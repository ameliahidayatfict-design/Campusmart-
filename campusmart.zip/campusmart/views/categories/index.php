<div class="container" style="margin-top: var(--spacing-6);">
  <div style="margin-bottom: var(--spacing-6);">
    <h1 style="font-size: var(--font-size-2xl); font-weight: 800; color: var(--color-text-main); margin-bottom: var(--spacing-2);">
      Kategori Kebutuhan Kampus
    </h1>
    <p style="color: var(--color-text-muted); font-size: var(--font-size-sm);">
      Temukan perlengkapan kuliah dan perkuliahan berdasarkan kelompok kategori favorit.
    </p>
  </div>

  <div style="display: grid; grid-template-columns: repeat(1, 1fr); gap: var(--spacing-4);" class="categories-grid">
    <?php foreach ($categories as $cat): ?>
      <a href="/products?category=<?= urlencode($cat['slug']) ?>" style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-6); box-shadow: var(--shadow-sm); display: flex; align-items: center; justify-content: space-between; transition: var(--transition);" class="category-card">
        <div style="display: flex; align-items: center; gap: var(--spacing-4);">
          <div style="width: 54px; height: 54px; border-radius: var(--radius-md); background: var(--color-primary-soft); color: var(--color-primary); display: flex; align-items: center; justify-content: center;">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
          </div>
          <div>
            <h2 style="font-size: var(--font-size-lg); font-weight: 700; color: var(--color-text-main); margin-bottom: 2px;">
              <?= e($cat['name']) ?>
            </h2>
            <p style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
              <?= e($cat['description'] ?: 'Semua produk dalam kategori ' . $cat['name']) ?>
            </p>
          </div>
        </div>

        <div style="display: flex; align-items: center; gap: var(--spacing-3);">
          <span class="badge" style="background: var(--color-primary-soft); color: var(--color-primary); font-size: 0.8rem; padding: 4px 12px;">
            <?= (int)$cat['product_count'] ?> Produk
          </span>
          <span style="color: var(--color-primary); font-weight: 700; font-size: 1.2rem;">&rsaquo;</span>
        </div>
      </a>
    <?php endforeach; ?>
  </div>

  <style>
    @media (min-width: 768px) {
      .categories-grid {
        grid-template-columns: repeat(2, 1fr) !important;
      }
    }
    .category-card:hover {
      border-color: var(--color-primary);
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
  </style>
</div>
