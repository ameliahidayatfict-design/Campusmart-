<div class="container" style="max-width: 1000px; margin-top: var(--spacing-4);">
  <div style="margin-bottom: var(--spacing-6);">
    <h1 style="font-size: var(--font-size-2xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 4px;">
      Keranjang Belanja
    </h1>
    <div style="font-size: var(--font-size-sm); color: var(--color-text-muted);">
      Periksa kembali barang belanjaan Anda sebelum melanjutkan ke proses checkout.
    </div>
  </div>

  <?php if (!empty($errors)): ?>
    <div style="background: #FEF2F2; border-left: 4px solid var(--color-danger); padding: var(--spacing-4); border-radius: 0 var(--radius-md) var(--radius-md) 0; margin-bottom: var(--spacing-6);">
      <div style="font-weight: 700; font-size: var(--font-size-sm); color: var(--color-danger); margin-bottom: 4px;">
        Perhatian: Beberapa item memerlukan penyesuaian:
      </div>
      <ul style="margin: 0; padding-left: 20px; font-size: var(--font-size-xs); color: #991B1B;">
        <?php foreach ($errors as $err): ?>
          <li><?= e($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <?php if (empty($items)): ?>
    <!-- Empty State matching Frame 8 -->
    <div style="text-align: center; padding: 60px 20px; background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); box-shadow: var(--shadow-sm);">
      <div style="width: 80px; height: 80px; margin: 0 auto 20px; background: var(--color-primary-soft); border-radius: var(--radius-full); display: flex; align-items: center; justify-content: center; color: var(--color-primary);">
        <svg width="40" height="40" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
      </div>
      <h2 style="font-size: var(--font-size-xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 8px;">
        Keranjang Belanja Kosong
      </h2>
      <p style="font-size: var(--font-size-sm); color: var(--color-text-muted); max-width: 420px; margin: 0 auto 24px;">
        Belum ada perlengkapan kuliah atau produk kampus yang kamu masukkan ke keranjang.
      </p>
      <a href="/products" class="btn btn-primary" style="padding: 10px 24px; font-weight: 700;">
        &larr; Jelajahi Katalog Produk
      </a>
    </div>
  <?php else: ?>
    <div 
      x-data="liveCartManager({ subtotal: <?= (float)$subtotal ?>, total: <?= (float)$total ?>, itemCount: <?= (int)$itemCount ?> })"
      style="display: grid; grid-template-columns: 1fr; gap: var(--spacing-6);" 
      class="cart-layout-grid"
    >
      <!-- Left Column: Cart Items List -->
      <div style="display: flex; flex-direction: column; gap: var(--spacing-4);">
        <?php foreach ($items as $item): ?>
          <div 
            x-data="{ qty: <?= (int)$item['quantity'] ?>, stock: <?= (int)$item['stock'] ?>, lineTotal: <?= (float)$item['line_total'] ?>, price: <?= (float)$item['price'] ?> }"
            class="cart-item-card"
            style="background: #FFFFFF; border: 1px solid <?= (!$item['is_available'] || !$item['is_stock_sufficient']) ? '#FCA5A5' : 'var(--color-border)' ?>; border-radius: var(--radius-lg); padding: var(--spacing-4); box-shadow: var(--shadow-sm); display: flex; flex-direction: column; gap: var(--spacing-3);"
          >
            <div style="display: flex; gap: var(--spacing-4); align-items: flex-start;">
              <!-- Product Image -->
              <div style="width: 80px; height: 80px; border-radius: var(--radius-md); background: #F8FAFC; border: 1px solid var(--color-border); overflow: hidden; flex-shrink: 0; display: flex; align-items: center; justify-content: center;">
                <?php if (!empty($item['image_path'])): ?>
                  <img src="<?= asset($item['image_path']) ?>" alt="<?= e($item['name']) ?>" style="width: 100%; height: 100%; object-fit: contain;">
                <?php else: ?>
                  <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--color-text-muted);"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                <?php endif; ?>
              </div>

              <!-- Product Info -->
              <div style="flex: 1; min-width: 0;">
                <div style="font-size: 0.75rem; color: var(--color-primary); font-weight: 700; text-transform: uppercase;">
                  <?= e($item['category_name']) ?>
                </div>
                <a href="/products/<?= e($item['slug']) ?>" style="font-weight: 700; font-size: var(--font-size-base); color: var(--color-text-main); text-decoration: none; display: block; margin: 2px 0;">
                  <?= e($item['name']) ?>
                </a>
                <div style="font-size: var(--font-size-sm); color: var(--color-primary); font-weight: 700;">
                  <?= rupiah($item['price']) ?>
                </div>

                <?php if (!$item['is_available']): ?>
                  <div style="margin-top: 4px;">
                    <span class="badge badge-cancelled" style="font-size: 0.7rem;">Produk Tidak Aktif</span>
                  </div>
                <?php elseif (!$item['is_stock_sufficient']): ?>
                  <div style="margin-top: 4px;">
                    <span class="badge badge-unpaid" style="font-size: 0.7rem; background: #FEF3C7; color: #92400E;">Stok Sisa <?= $item['stock'] ?> Unit</span>
                  </div>
                <?php endif; ?>
              </div>
            </div>

            <!-- Stepper and Actions -->
            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--color-border); padding-top: var(--spacing-3); flex-wrap: wrap; gap: 8px;">
              <!-- Remove Item Button Form -->
              <form action="/cart/remove" method="POST" style="margin: 0;" @submit.prevent="removeItem(<?= (int)$item['product_id'] ?>, '<?= csrf_token() ?>', $el.closest('.cart-item-card'))">
                <?= csrf_field() ?>
                <input type="hidden" name="product_id" value="<?= (int)$item['product_id'] ?>">
                <button type="submit" class="cart-remove-btn" title="Hapus produk dari keranjang">
                  <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                  <span>Hapus</span>
                </button>
              </form>

              <!-- Stepper & Subtotal -->
              <div style="display: flex; align-items: center; gap: 16px;">
                <!-- Quantity Stepper Form -->
                <form action="/cart/update" method="POST" class="cart-stepper" style="margin: 0;">
                  <?= csrf_field() ?>
                  <input type="hidden" name="product_id" value="<?= (int)$item['product_id'] ?>">
                  
                  <!-- Decrement button -->
                  <button 
                    type="button" 
                    class="cart-stepper-btn"
                    title="Kurangi kuantitas"
                    @click="if (qty > 1) { qty--; lineTotal = qty * price; updateQty(<?= (int)$item['product_id'] ?>, qty, '<?= csrf_token() ?>', $el.closest('.cart-item-card')); }"
                    :disabled="qty <= 1"
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                  </button>
                  
                  <input type="number" name="quantity" x-model="qty" min="1" max="<?= max(1, (int)$item['stock']) ?>" class="cart-stepper-input" readonly>
                  
                  <!-- Increment button -->
                  <button 
                    type="button" 
                    class="cart-stepper-btn"
                    title="Tambah kuantitas"
                    @click="if (qty < stock) { qty++; lineTotal = qty * price; updateQty(<?= (int)$item['product_id'] ?>, qty, '<?= csrf_token() ?>', $el.closest('.cart-item-card')); }"
                    :disabled="qty >= stock"
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                  </button>
                </form>

                <div 
                  x-text="formatRupiah(lineTotal)"
                  style="font-weight: 800; font-size: var(--font-size-base); color: var(--color-primary); min-width: 90px; text-align: right;"
                >
                  <?= rupiah($item['line_total']) ?>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- Right Column: Cart Summary Sidebar (matching Frame 8) -->
      <div>
        <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-6); box-shadow: var(--shadow-sm); position: sticky; top: 80px;">
          <h2 style="font-size: var(--font-size-base); font-weight: 800; margin-bottom: var(--spacing-4); color: var(--color-text-main);">
            Ringkasan Pesanan
          </h2>

          <div style="display: flex; justify-content: space-between; font-size: var(--font-size-sm); margin-bottom: 8px;">
            <span style="color: var(--color-text-muted);">Total Barang</span>
            <span style="font-weight: 600;" x-text="itemCount + ' item'"><?= (int)$itemCount ?> item</span>
          </div>

          <div style="display: flex; justify-content: space-between; font-size: var(--font-size-sm); margin-bottom: 8px;">
            <span style="color: var(--color-text-muted);">Subtotal Produk</span>
            <span style="font-weight: 600;" x-text="formatRupiah(subtotal)"><?= rupiah($subtotal) ?></span>
          </div>

          <div style="display: flex; justify-content: space-between; font-size: var(--font-size-sm); margin-bottom: 12px;">
            <span style="color: var(--color-text-muted);">Pengiriman Kampus</span>
            <span style="font-weight: 700; color: var(--color-success);">Rp 0 (Counter Kampus)</span>
          </div>

          <div style="border-top: 2px dashed var(--color-border); padding-top: var(--spacing-3); margin-top: var(--spacing-3); display: flex; justify-content: space-between; align-items: baseline; margin-bottom: var(--spacing-5);">
            <span style="font-size: var(--font-size-base); font-weight: 800; color: var(--color-text-main);">Total Biaya</span>
            <span style="font-size: var(--font-size-xl); font-weight: 800; color: var(--color-primary);" x-text="formatRupiah(total)"><?= rupiah($total) ?></span>
          </div>

          <?php if ($hasInvalid): ?>
            <div style="margin-bottom: var(--spacing-4); font-size: var(--font-size-xs); color: var(--color-danger); text-align: center;">
              Harap sesuaikan atau hapus barang yang bermasalah sebelum checkout.
            </div>
            <button class="btn btn-secondary btn-block" disabled style="opacity: 0.6; cursor: not-allowed; padding: 12px; font-weight: 700;">
              Lanjut ke Checkout
            </button>
          <?php else: ?>
            <a href="/checkout" class="btn btn-primary btn-block" style="padding: 12px; font-weight: 700; font-size: var(--font-size-sm); text-align: center; text-decoration: none;">
              Lanjut ke Checkout &rarr;
            </a>
          <?php endif; ?>

          <div style="margin-top: var(--spacing-4); font-size: 0.75rem; color: var(--color-text-muted); text-align: center;">
            &bull; Pengambilan pesanan dilakukan di Counter CampusMart Rektorat Lt. 1 tanpa biaya ongkir.
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>

<style>
@media (min-width: 768px) {
  .cart-layout-grid {
    grid-template-columns: 1fr 340px !important;
  }
}
</style>
