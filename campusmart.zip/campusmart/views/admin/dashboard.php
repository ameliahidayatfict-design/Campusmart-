<div style="margin-bottom: var(--spacing-6);">
  <div style="background: linear-gradient(135deg, var(--color-primary) 0%, #4A0012 100%); border-radius: var(--radius-lg); padding: var(--spacing-6); color: #FFFFFF; margin-bottom: var(--spacing-6);">
    <h1 style="font-size: var(--font-size-xl); font-weight: 800; margin-bottom: 4px;">Selamat Datang di Panel Admin CampusMart</h1>
    <p style="font-size: var(--font-size-sm); color: rgba(255, 255, 255, 0.85);">
      Pantau dan kelola seluruh transaksi, katalog produk, pengguna, dan laporan penjualan dalam satu tempat.
    </p>
  </div>

  <!-- 4 Stat Cards (matching Frame 27) -->
  <div class="stat-grid">
    <!-- Stat 1: Produk Aktif -->
    <div class="stat-card">
      <div class="stat-icon">
        <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
      </div>
      <div class="stat-title">Produk Aktif</div>
      <div class="stat-value"><?= $totalProducts ?></div>
      <div style="font-size: 0.75rem; color: var(--color-success); margin-top: 4px; font-weight: 600;">Katalog Siap Dijual</div>
    </div>

    <!-- Stat 2: Total Pesanan -->
    <div class="stat-card">
      <div class="stat-icon" style="background-color: #FEF3C7; color: #B45309;">
        <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
      </div>
      <div class="stat-title">Total Pesanan</div>
      <div class="stat-value"><?= $totalOrders ?></div>
      <div style="font-size: 0.75rem; color: var(--color-text-muted); margin-top: 4px;">Semua Transaksi Kampus</div>
    </div>

    <!-- Stat 3: Mahasiswa Terdaftar -->
    <div class="stat-card">
      <div class="stat-icon" style="background-color: #EDE9FE; color: #6D28D9;">
        <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
      </div>
      <div class="stat-title">Mahasiswa Terdaftar</div>
      <div class="stat-value"><?= $totalStudents ?></div>
      <div style="font-size: 0.75rem; color: var(--color-text-muted); margin-top: 4px;">Akun Sivitas Aktif</div>
    </div>

    <!-- Stat 4: Total Pendapatan Lunas -->
    <div class="stat-card">
      <div class="stat-icon" style="background-color: var(--color-success-bg); color: var(--color-success);">
        <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
      </div>
      <div class="stat-title">Pendapatan Terverifikasi</div>
      <div class="stat-value" style="font-size: 1.35rem; color: var(--color-success);"><?= rupiah($totalRevenue) ?></div>
      <div style="font-size: 0.75rem; color: var(--color-text-muted); margin-top: 4px;">Status Pembayaran Lunas</div>
    </div>
  </div>

  <!-- Quick Actions (matching Frame 27) -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); margin-bottom: var(--spacing-6); box-shadow: var(--shadow-sm);">
    <h2 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3);">Aksi Cepat Manajemen</h2>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--spacing-3);">
      <a href="/admin/products/create" class="btn btn-primary" style="justify-content: flex-start; gap: 8px;">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        <span>Tambah Produk Baru</span>
      </a>
      <a href="/admin/categories/create" class="btn btn-secondary" style="justify-content: flex-start; gap: 8px;">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        <span>Tambah Kategori</span>
      </a>
      <a href="/admin/orders" class="btn btn-secondary" style="justify-content: flex-start; gap: 8px;">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/></svg>
        <span>Kelola Semua Pesanan</span>
      </a>
    </div>
  </div>

  <!-- Recent Orders Table -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-4);">
      <h2 style="font-size: var(--font-size-base); font-weight: 700;">Pesanan Terbaru</h2>
      <a href="/admin/orders" style="font-size: var(--font-size-xs); color: var(--color-primary); font-weight: 600;">Lihat Semua &rarr;</a>
    </div>

    <?php if (!empty($recentOrders)): ?>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Kode Pesanan</th>
              <th>Pemesan</th>
              <th>Metode</th>
              <th>Total</th>
              <th>Status Pesanan</th>
              <th>Status Bayar</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recentOrders as $order): ?>
              <tr>
                <td><strong>#<?= e($order['order_code']) ?></strong></td>
                <td><?= e($order['customer_name']) ?></td>
                <td style="text-transform: uppercase; font-weight: 600; font-size: 0.75rem;"><?= e($order['payment_method']) ?></td>
                <td style="font-weight: 700; color: var(--color-primary);"><?= rupiah($order['total']) ?></td>
                <td>
                  <span class="badge badge-<?= e($order['status']) ?>"><?= e(str_replace('_', ' ', $order['status'])) ?></span>
                </td>
                <td>
                  <span class="badge badge-<?= e($order['payment_status']) ?>"><?= e(str_replace('_', ' ', $order['payment_status'])) ?></span>
                </td>
                <td>
                  <a href="/admin/orders/<?= (int)$order['id'] ?>" class="btn btn-secondary btn-sm" style="padding: 3px 8px;">Detail</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <p style="color: var(--color-text-muted); font-size: var(--font-size-sm); text-align: center; padding: 2rem 0;">Belum ada pesanan terbaru.</p>
    <?php endif; ?>
  </div>
</div>
