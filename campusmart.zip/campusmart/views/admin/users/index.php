<div style="margin-bottom: var(--spacing-6);">
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-4); flex-wrap: wrap; gap: var(--spacing-3);">
    <div>
      <h1 style="font-size: var(--font-size-xl); font-weight: 700;">Kelola Pengguna</h1>
      <p style="font-size: var(--font-size-xs); color: var(--color-text-muted);">Lihat data akun mahasiswa dan administrator CampusMart.</p>
    </div>
  </div>

  <!-- Search and Role Filter Bar (matching Frame 30) -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); margin-bottom: var(--spacing-4); box-shadow: var(--shadow-sm);">
    <form action="/admin/users" method="GET" style="display: flex; gap: var(--spacing-3); flex-wrap: wrap;">
      <div style="flex: 1; min-width: 220px; position: relative;">
        <span style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--color-text-muted);">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        </span>
        <input type="text" name="q" class="form-control" placeholder="Cari nama, email, atau NIM pengguna..." value="<?= e($q) ?>" style="padding-left: 2.4rem;">
      </div>

      <div style="width: 180px;">
        <select name="role" class="form-control" onchange="this.form.submit()">
          <option value="">Semua Role</option>
          <option value="student" <?= $role === 'student' ? 'selected' : '' ?>>Mahasiswa</option>
          <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
        </select>
      </div>

      <div style="width: 180px;">
        <select name="status" class="form-control" onchange="this.form.submit()">
          <option value="">Semua Status</option>
          <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Aktif</option>
          <option value="suspended" <?= $status === 'suspended' ? 'selected' : '' ?>>Ditangguhkan</option>
        </select>
      </div>

      <button type="submit" class="btn btn-secondary">Cari</button>
      <?php if (!empty($q) || !empty($role) || !empty($status)): ?>
        <a href="/admin/users" class="btn btn-secondary" title="Reset">&times;</a>
      <?php endif; ?>
    </form>
  </div>

  <!-- Users Table (matching Frame 30) -->
  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th>Pengguna</th>
          <th>NIM & Kontak</th>
          <th>Role</th>
          <th>Total Pesanan</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($users)): ?>
          <?php foreach ($users as $u): ?>
            <tr>
              <td>
                <div style="display: flex; align-items: center; gap: 10px;">
                  <div style="width: 38px; height: 38px; border-radius: var(--radius-full); background: var(--color-primary-soft); color: var(--color-primary); display: flex; align-items: center; justify-content: center; font-weight: 700;">
                    <?= strtoupper(substr($u['name'], 0, 1)) ?>
                  </div>
                  <div>
                    <div style="font-weight: 700; color: var(--color-text-main);"><?= e($u['name']) ?></div>
                    <div style="font-size: 0.75rem; color: var(--color-text-muted);"><?= e($u['email']) ?></div>
                  </div>
                </div>
              </td>
              <td>
                <div>NIM: <strong><?= e($u['student_id'] ?: '-') ?></strong></div>
                <div style="font-size: 0.75rem; color: var(--color-text-muted);"><?= e($u['phone'] ?: '-') ?></div>
              </td>
              <td>
                <span class="badge" style="background: <?= $u['role'] === 'admin' ? 'var(--color-primary-soft); color: var(--color-primary);' : '#F1F5F9; color: var(--color-text-main);' ?> font-weight: 700;">
                  <?= $u['role'] === 'admin' ? 'Administrator' : 'Mahasiswa' ?>
                </span>
              </td>
              <td>
                <strong><?= (int)$u['order_count'] ?></strong> pesanan
              </td>
              <td>
                <span class="badge badge-<?= $u['status'] === 'active' ? 'completed' : 'cancelled' ?>">
                  <?= $u['status'] === 'active' ? 'Aktif' : 'Ditangguhkan' ?>
                </span>
              </td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <a href="/admin/users/<?= (int)$u['id'] ?>" class="btn btn-secondary btn-sm">
                    Detail
                  </a>
                  <form action="/admin/users/<?= (int)$u['id'] ?>/status" method="POST" style="display: inline;" onsubmit="return confirm('Apakah Anda yakin ingin mengubah status akun ini?');">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-<?= $u['status'] === 'active' ? 'danger' : 'secondary' ?> btn-sm">
                      <?= $u['status'] === 'active' ? 'Tangguhkan' : 'Aktifkan' ?>
                    </button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="6" style="text-align: center; color: var(--color-text-muted); padding: 3rem 0;">
              Tidak ada data pengguna yang ditemukan.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($totalPages > 1): ?>
    <div style="margin-top: var(--spacing-6); display: flex; justify-content: center; gap: 6px;">
      <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <?php
          $url = '/admin/users?' . http_build_query(array_filter([
            'q' => $q ?: null,
            'role' => $role ?: null,
            'status' => $status ?: null,
            'page' => $i,
          ]));
        ?>
        <a href="<?= $url ?>" class="btn <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>" style="min-width: 36px; padding: 4px 10px; font-size: 0.8rem;">
          <?= $i ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>
