<div style="margin-bottom: var(--spacing-6);">
  <div style="margin-bottom: var(--spacing-4);">
    <a href="/admin/users" class="btn btn-secondary btn-sm">&larr; Kembali ke Kelola Pengguna</a>
  </div>

  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-6); box-shadow: var(--shadow-sm); margin-bottom: var(--spacing-6);">
    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--color-border); padding-bottom: var(--spacing-4); margin-bottom: var(--spacing-4); flex-wrap: wrap; gap: var(--spacing-3);">
      <div style="display: flex; align-items: center; gap: 14px;">
        <div style="width: 52px; height: 52px; border-radius: var(--radius-full); background: var(--color-primary-soft); color: var(--color-primary); display: flex; align-items: center; justify-content: center; font-size: 1.4rem; font-weight: 800;">
          <?= strtoupper(substr($user['name'], 0, 1)) ?>
        </div>
        <div>
          <h1 style="font-size: var(--font-size-lg); font-weight: 700;"><?= e($user['name']) ?></h1>
          <div style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
            <?= e($user['email']) ?> &bull; Bergabung sejak <?= date('d M Y', strtotime($user['created_at'])) ?>
          </div>
        </div>
      </div>

      <div style="display: flex; gap: 8px; align-items: center;">
        <span class="badge badge-<?= $user['status'] === 'active' ? 'completed' : 'cancelled' ?>">
          <?= $user['status'] === 'active' ? 'Akun Aktif' : 'Akun Ditangguhkan' ?>
        </span>
        <form action="/admin/users/<?= (int)$user['id'] ?>/status" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin mengubah status akun ini?');">
          <?= csrf_field() ?>
          <button type="submit" class="btn btn-<?= $user['status'] === 'active' ? 'danger' : 'primary' ?> btn-sm">
            <?= $user['status'] === 'active' ? 'Tangguhkan Akun' : 'Aktifkan Akun' ?>
          </button>
        </form>
      </div>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--spacing-4);">
      <div>
        <div style="font-size: 0.75rem; color: var(--color-text-muted);">Role Pengguna</div>
        <div style="font-weight: 700; text-transform: uppercase;"><?= e($user['role']) ?></div>
      </div>
      <div>
        <div style="font-size: 0.75rem; color: var(--color-text-muted);">Nomor Induk Mahasiswa (NIM)</div>
        <div style="font-weight: 700;"><?= e($user['student_id'] ?: '-') ?></div>
      </div>
      <div>
        <div style="font-size: 0.75rem; color: var(--color-text-muted);">Nomor Telepon / WA</div>
        <div style="font-weight: 700;"><?= e($user['phone'] ?: '-') ?></div>
      </div>
    </div>
  </div>

  <!-- User's Orders Table -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
    <h2 style="font-size: var(--font-size-base); font-weight: 700; margin-bottom: var(--spacing-4);">
      Riwayat Transaksi Pesanan Pengguna
    </h2>

    <?php if (!empty($orders)): ?>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Kode Pesanan</th>
              <th>Tanggal</th>
              <th>Metode</th>
              <th>Total</th>
              <th>Status Pesanan</th>
              <th>Status Bayar</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $ord): ?>
              <tr>
                <td><strong>#<?= e($ord['order_code']) ?></strong></td>
                <td><?= date('d M Y, H:i', strtotime($ord['created_at'])) ?></td>
                <td style="text-transform: uppercase; font-weight: 600; font-size: 0.75rem;"><?= e($ord['payment_method']) ?></td>
                <td style="font-weight: 700; color: var(--color-primary);"><?= rupiah($ord['total']) ?></td>
                <td>
                  <span class="badge badge-<?= e($ord['status']) ?>"><?= e(str_replace('_', ' ', $ord['status'])) ?></span>
                </td>
                <td>
                  <span class="badge badge-<?= e($ord['payment_status']) ?>"><?= e(str_replace('_', ' ', $ord['payment_status'])) ?></span>
                </td>
                <td>
                  <a href="/admin/orders/<?= (int)$ord['id'] ?>" class="btn btn-secondary btn-sm">Lihat Order</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <p style="color: var(--color-text-muted); font-size: var(--font-size-sm); text-align: center; padding: 2rem 0;">Pengguna ini belum pernah melakukan pemesanan.</p>
    <?php endif; ?>
  </div>
</div>
