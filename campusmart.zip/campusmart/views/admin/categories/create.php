<div style="max-width: 680px; margin: 0 auto;">
  <div style="margin-bottom: var(--spacing-4);">
    <a href="/admin/categories" class="btn btn-secondary btn-sm">&larr; Kembali ke Daftar Kategori</a>
  </div>

  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-6); box-shadow: var(--shadow-sm);">
    <h1 style="font-size: var(--font-size-lg); font-weight: 700; margin-bottom: var(--spacing-4); border-bottom: 1px solid var(--color-border); padding-bottom: var(--spacing-3);">
      Tambah Kategori Baru
    </h1>

    <form action="/admin/categories" method="POST">
      <?= csrf_field() ?>

      <div class="form-group">
        <label for="name" class="form-label">Nama Kategori *</label>
        <input type="text" id="name" name="name" class="form-control" placeholder="Contoh: Modul Kuliah & Buku" required autofocus>
      </div>

      <div class="form-group">
        <label for="slug" class="form-label">Slug URL (Opsional, otomatis dibuat jika kosong)</label>
        <input type="text" id="slug" name="slug" class="form-control" placeholder="contoh: modul-kuliah-buku">
        <small style="color: var(--color-text-muted); font-size: 0.75rem;">Hanya huruf kecil, angka, dan tanda hubung (-).</small>
      </div>

      <div class="form-group">
        <label for="description" class="form-label">Deskripsi Kategori</label>
        <textarea id="description" name="description" class="form-control" rows="3" placeholder="Jelaskan jenis produk dalam kategori ini..."></textarea>
      </div>

      <div class="form-group">
        <label for="status" class="form-label">Status Kategori</label>
        <select id="status" name="status" class="form-control">
          <option value="active">Aktif (Tampil di katalog mahasiswa)</option>
          <option value="inactive">Nonaktif (Disembunyikan dari katalog)</option>
        </select>
      </div>

      <div style="display: flex; gap: 8px; justify-content: flex-end; margin-top: var(--spacing-6);">
        <a href="/admin/categories" class="btn btn-secondary">Batal</a>
        <button type="submit" class="btn btn-primary">Simpan Kategori</button>
      </div>
    </form>
  </div>
</div>
