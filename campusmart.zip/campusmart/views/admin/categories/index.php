<div style="margin-bottom: var(--spacing-6);">
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-4); flex-wrap: wrap; gap: var(--spacing-3);">
    <div>
      <h1 style="font-size: var(--font-size-xl); font-weight: 700;">Daftar Kategori Produk</h1>
      <p style="font-size: var(--font-size-xs); color: var(--color-text-muted);">Kelola pengelompokan barang untuk memudahkan mahasiswa berbelanja.</p>
    </div>
    <a href="/admin/categories/create" class="btn btn-primary" style="gap: 6px;">
      <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
      <span>Tambah Kategori</span>
    </a>
  </div>

  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nama Kategori</th>
          <th>Slug URL</th>
          <th>Jumlah Produk</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($categories)): ?>
          <?php foreach ($categories as $cat): ?>
            <tr>
              <td><?= (int)$cat['id'] ?></td>
              <td>
                <div style="font-weight: 600; color: var(--color-text-main);"><?= e($cat['name']) ?></div>
                <div style="font-size: 0.75rem; color: var(--color-text-muted);"><?= e($cat['description'] ?: '-') ?></div>
              </td>
              <td><code><?= e($cat['slug']) ?></code></td>
              <td>
                <span class="badge" style="background: var(--color-primary-soft); color: var(--color-primary);">
                  <?= (int)$cat['product_count'] ?> Produk
                </span>
              </td>
              <td>
                <span class="badge badge-<?= $cat['status'] === 'active' ? 'completed' : 'cancelled' ?>">
                  <?= $cat['status'] === 'active' ? 'Aktif' : 'Nonaktif' ?>
                </span>
              </td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <a href="/admin/categories/<?= (int)$cat['id'] ?>/edit" class="btn btn-secondary btn-sm" title="Edit">
                    Edit
                  </a>
                  <form action="/admin/categories/<?= (int)$cat['id'] ?>/delete" method="POST" style="display: inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus kategori ini?');">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-danger btn-sm" title="Hapus">
                      Hapus
                    </button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="6" style="text-align: center; color: var(--color-text-muted); padding: 2rem;">
              Belum ada kategori. Silakan tambahkan kategori baru.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
