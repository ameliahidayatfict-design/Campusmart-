<div style="max-width: 760px; margin: 0 auto;">
  <div style="margin-bottom: var(--spacing-4);">
    <a href="/admin/products" class="btn btn-secondary btn-sm">&larr; Kembali ke Daftar Produk</a>
  </div>

  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-6); box-shadow: var(--shadow-sm);">
    <h1 style="font-size: var(--font-size-lg); font-weight: 700; margin-bottom: var(--spacing-4); border-bottom: 1px solid var(--color-border); padding-bottom: var(--spacing-3);">
      Edit Produk: <?= e($product['name']) ?>
    </h1>

    <form action="/admin/products/<?= (int)$product['id'] ?>/edit" method="POST" enctype="multipart/form-data">
      <?= csrf_field() ?>

      <div style="display: grid; grid-template-columns: 1fr; gap: var(--spacing-4);">
        <div class="form-group">
          <label for="name" class="form-label">Nama Produk *</label>
          <input type="text" id="name" name="name" class="form-control" value="<?= e($product['name']) ?>" required>
        </div>

        <div class="grid-2">
          <div class="form-group">
            <label for="category_id" class="form-label">Kategori *</label>
            <select id="category_id" name="category_id" class="form-control" required>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= (int)$cat['id'] ?>" <?= (int)$product['category_id'] === (int)$cat['id'] ? 'selected' : '' ?>>
                  <?= e($cat['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label for="slug" class="form-label">Slug URL *</label>
            <input type="text" id="slug" name="slug" class="form-control" value="<?= e($product['slug']) ?>" required>
          </div>
        </div>

        <div class="grid-2">
          <div class="form-group">
            <label for="price" class="form-label">Harga Satuan (Rp) *</label>
            <input type="number" id="price" name="price" class="form-control" value="<?= (float)$product['price'] ?>" min="0" step="100" required>
          </div>

          <div class="form-group">
            <label for="stock" class="form-label">Jumlah Stok *</label>
            <input type="number" id="stock" name="stock" class="form-control" value="<?= (int)$product['stock'] ?>" min="0" required>
          </div>
        </div>

        <!-- Current image preview & replace -->
        <div class="form-group">
          <label for="image" class="form-label">Foto Produk</label>
          <?php if (!empty($product['image_path'])): ?>
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
              <div style="width: 60px; height: 60px; border-radius: var(--radius-sm); border: 1px solid var(--color-border); overflow: hidden; background: #F8FAFC;">
                <img src="<?= asset($product['image_path']) ?>" alt="<?= e($product['name']) ?>" style="width: 100%; height: 100%; object-fit: contain;">
              </div>
              <span style="font-size: 0.75rem; color: var(--color-text-muted);">Foto saat ini. Pilih file baru di bawah jika ingin mengganti.</span>
            </div>
          <?php endif; ?>
          <input type="file" id="image" name="image" class="form-control" accept="image/jpeg,image/png,image/webp">
        </div>

        <div class="form-group">
          <label for="description" class="form-label">Deskripsi & Spesifikasi Produk</label>
          <textarea id="description" name="description" class="form-control" rows="4"><?= e($product['description']) ?></textarea>
        </div>

        <div class="form-group">
          <label for="status" class="form-label">Status Produk</label>
          <select id="status" name="status" class="form-control">
            <option value="active" <?= $product['status'] === 'active' ? 'selected' : '' ?>>Aktif (Dapat dicari dan dibeli mahasiswa)</option>
            <option value="inactive" <?= $product['status'] === 'inactive' ? 'selected' : '' ?>>Nonaktif (Disembunyikan dari katalog)</option>
          </select>
        </div>
      </div>

      <div style="display: flex; gap: 8px; justify-content: flex-end; margin-top: var(--spacing-6); border-top: 1px solid var(--color-border); padding-top: var(--spacing-4);">
        <a href="/admin/products" class="btn btn-secondary">Batal</a>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
      </div>
    </form>
  </div>
</div>
