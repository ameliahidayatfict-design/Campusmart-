<div style="max-width: 760px; margin: 0 auto;">
  <div style="margin-bottom: var(--spacing-4);">
    <a href="/admin/products" class="btn btn-secondary btn-sm">&larr; Kembali ke Daftar Produk</a>
  </div>

  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-6); box-shadow: var(--shadow-sm);">
    <h1 style="font-size: var(--font-size-lg); font-weight: 700; margin-bottom: var(--spacing-4); border-bottom: 1px solid var(--color-border); padding-bottom: var(--spacing-3);">
      Tambah Produk Baru
    </h1>

    <form action="/admin/products" method="POST" enctype="multipart/form-data">
      <?= csrf_field() ?>

      <div style="display: grid; grid-template-columns: 1fr; gap: var(--spacing-4);" class="form-grid">
        <div class="form-group">
          <label for="name" class="form-label">Nama Produk *</label>
          <input type="text" id="name" name="name" class="form-control" placeholder="Contoh: Pulpen Gel 0.5mm Hitam" required autofocus>
        </div>

        <div class="grid-2">
          <div class="form-group">
            <label for="category_id" class="form-label">Kategori *</label>
            <select id="category_id" name="category_id" class="form-control" required>
              <option value="">-- Pilih Kategori --</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= (int)$cat['id'] ?>"><?= e($cat['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label for="slug" class="form-label">Slug URL (Otomatis jika kosong)</label>
            <input type="text" id="slug" name="slug" class="form-control" placeholder="pulpen-gel-0-5mm">
          </div>
        </div>

        <div class="grid-2">
          <div class="form-group">
            <label for="price" class="form-label">Harga Satuan (Rp) *</label>
            <input type="number" id="price" name="price" class="form-control" placeholder="Contoh: 15000" min="0" step="100" required>
          </div>

          <div class="form-group">
            <label for="stock" class="form-label">Jumlah Stok Awal *</label>
            <input type="number" id="stock" name="stock" class="form-control" placeholder="Contoh: 50" min="0" required>
          </div>
        </div>

        <div class="form-group">
          <label for="image" class="form-label">Foto Produk (JPG, PNG, atau WebP, maks. 2MB)</label>
          <input type="file" id="image" name="image" class="form-control" accept="image/jpeg,image/png,image/webp">
          <small style="color: var(--color-text-muted); font-size: 0.75rem;">Disarankan foto berasio 1:1 dengan latar belakang bersih.</small>
        </div>

        <div class="form-group">
          <label for="description" class="form-label">Deskripsi & Spesifikasi Produk</label>
          <textarea id="description" name="description" class="form-control" rows="4" placeholder="Tuliskan spesifikasi, ukuran, warna, atau keunggulan barang..."></textarea>
        </div>

        <div class="form-group">
          <label for="status" class="form-label">Status Produk</label>
          <select id="status" name="status" class="form-control">
            <option value="active">Aktif (Dapat dicari dan dibeli mahasiswa)</option>
            <option value="inactive">Nonaktif (Disembunyikan dari katalog)</option>
          </select>
        </div>
      </div>

      <div style="display: flex; gap: 8px; justify-content: flex-end; margin-top: var(--spacing-6); border-top: 1px solid var(--color-border); padding-top: var(--spacing-4);">
        <a href="/admin/products" class="btn btn-secondary">Batal</a>
        <button type="submit" class="btn btn-primary">Simpan Produk</button>
      </div>
    </form>
  </div>
</div>
