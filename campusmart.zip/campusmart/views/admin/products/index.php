<div style="margin-bottom: var(--spacing-6);">
  <!-- Header Bar -->
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-4); flex-wrap: wrap; gap: var(--spacing-3);">
    <div>
      <h1 style="font-size: var(--font-size-xl); font-weight: 700;">Kelola Produk</h1>
      <p style="font-size: var(--font-size-xs); color: var(--color-text-muted);">Lihat, tambah, ubah, dan kelola stok barang kebutuhan mahasiswa.</p>
    </div>
    <a href="/admin/products/create" class="btn btn-primary" style="gap: 6px;">
      <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
      <span>Tambah Produk</span>
    </a>
  </div>

  <!-- Search and Category Filter Bar (matching Frame 28) -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); margin-bottom: var(--spacing-4); box-shadow: var(--shadow-sm);">
    <form action="/admin/products" method="GET" style="display: flex; gap: var(--spacing-3); flex-wrap: wrap;">
      <div style="flex: 1; min-width: 220px; position: relative;">
        <span style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--color-text-muted);">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        </span>
        <input type="text" name="q" class="form-control" placeholder="Cari nama produk, kata kunci..." value="<?= e($q) ?>" style="padding-left: 2.4rem;">
      </div>

      <div style="width: 220px;">
        <select name="category_id" class="form-control" onchange="this.form.submit()">
          <option value="0">Semua Kategori</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= (int)$cat['id'] ?>" <?= $selectedCategory === (int)$cat['id'] ? 'selected' : '' ?>>
              <?= e($cat['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <button type="submit" class="btn btn-secondary">Cari</button>
      <?php if (!empty($q) || $selectedCategory > 0): ?>
        <a href="/admin/products" class="btn btn-secondary" title="Reset Filter">&times;</a>
      <?php endif; ?>
    </form>
  </div>

  <!-- Products Table / List -->
  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th style="width: 60px;">Foto</th>
          <th>Nama & Kategori</th>
          <th>Harga</th>
          <th>Stok</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($products)): ?>
          <?php foreach ($products as $prod): ?>
            <tr>
              <td>
                <div style="width: 48px; height: 48px; border-radius: var(--radius-sm); background: #F1F5F9; display: flex; align-items: center; justify-content: center; overflow: hidden; border: 1px solid var(--color-border);">
                  <?php if (!empty($prod['image_path'])): ?>
                    <img src="<?= asset($prod['image_path']) ?>" alt="<?= e($prod['name']) ?>" style="width: 100%; height: 100%; object-fit: contain;" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'32\' height=\'32\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23800020\' stroke-width=\'1.5\'><rect x=\'3\' y=\'3\' width=\'18\' height=\'18\' rx=\'2\'/></svg>'">
                  <?php else: ?>
                    <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--color-text-muted);"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                  <?php endif; ?>
                </div>
              </td>
              <td>
                <div style="font-weight: 700; color: var(--color-text-main);"><?= e($prod['name']) ?></div>
                <div style="font-size: 0.75rem; color: var(--color-primary); font-weight: 600;"><?= e($prod['category_name']) ?></div>
                <div style="font-size: 0.7rem; color: var(--color-text-muted);">Slug: <code><?= e($prod['slug']) ?></code></div>
              </td>
              <td style="font-weight: 700; color: var(--color-primary);"><?= rupiah($prod['price']) ?></td>
              <td>
                <span style="font-weight: 600; color: <?= (int)$prod['stock'] > 10 ? 'var(--color-success)' : ((int)$prod['stock'] > 0 ? 'var(--color-warning)' : 'var(--color-danger)') ?>;">
                  <?= (int)$prod['stock'] ?> unit
                </span>
              </td>
              <td>
                <span class="badge badge-<?= $prod['status'] === 'active' ? 'completed' : 'cancelled' ?>">
                  <?= $prod['status'] === 'active' ? 'Aktif' : 'Nonaktif' ?>
                </span>
              </td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <a href="/products/<?= e($prod['slug']) ?>" target="_blank" class="btn btn-secondary btn-sm" title="Lihat di Toko">
                    Lihat
                  </a>
                  <a href="/admin/products/<?= (int)$prod['id'] ?>/edit" class="btn btn-secondary btn-sm" title="Edit">
                    Edit
                  </a>
                  <form action="/admin/products/<?= (int)$prod['id'] ?>/delete" method="POST" style="display: inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus / menonaktifkan produk ini?');">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-danger btn-sm" title="Hapus">
                      Hapus
                    </button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="6" style="text-align: center; color: var(--color-text-muted); padding: 3rem 0;">
              Tidak ada produk yang ditemukan.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($totalPages > 1): ?>
    <div style="margin-top: var(--spacing-6); display: flex; justify-content: center; gap: 6px;">
      <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <?php
          $url = '/admin/products?' . http_build_query(array_filter([
            'q' => $q ?: null,
            'category_id' => $selectedCategory ?: null,
            'page' => $i
          ]));
        ?>
        <a href="<?= $url ?>" class="btn <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>" style="min-width: 36px; padding: 4px 10px; font-size: 0.8rem;">
          <?= $i ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>
