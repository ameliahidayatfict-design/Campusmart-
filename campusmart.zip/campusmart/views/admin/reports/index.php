<div style="margin-bottom: var(--spacing-6);">
  <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: var(--spacing-4);">
    <div>
      <h1 style="font-size: var(--font-size-2xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 4px;">
        Laporan Penjualan & Transaksi
      </h1>
      <div style="font-size: var(--font-size-sm); color: var(--color-text-muted);">
        Agregasi data keuangan, perputaran pesanan kampus, dan evaluasi produk terlaris.
      </div>
    </div>
  </div>

  <!-- Filter Card -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); box-shadow: var(--shadow-sm); margin-bottom: var(--spacing-6);">
    <form action="/admin/reports" method="GET" style="display: flex; gap: 12px; align-items: flex-end; flex-wrap: wrap;">
      <div class="form-group" style="margin-bottom: 0; min-width: 140px;">
        <label for="start_date" class="form-label" style="font-size: 0.75rem;">Mulai Tanggal</label>
        <input type="date" name="start_date" id="start_date" class="form-control" style="padding: 6px 10px; font-size: 0.8rem;" value="<?= e($filters['start_date']) ?>">
      </div>

      <div class="form-group" style="margin-bottom: 0; min-width: 140px;">
        <label for="end_date" class="form-label" style="font-size: 0.75rem;">Sampai Tanggal</label>
        <input type="date" name="end_date" id="end_date" class="form-control" style="padding: 6px 10px; font-size: 0.8rem;" value="<?= e($filters['end_date']) ?>">
      </div>

      <div class="form-group" style="margin-bottom: 0; min-width: 150px;">
        <label for="status" class="form-label" style="font-size: 0.75rem;">Status Pesanan</label>
        <select name="status" id="status" class="form-control" style="padding: 6px 10px; font-size: 0.8rem;">
          <option value="">Semua Status</option>
          <option value="pending" <?= $filters['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
          <option value="confirmed" <?= $filters['status'] === 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
          <option value="processing" <?= $filters['status'] === 'processing' ? 'selected' : '' ?>>Processing</option>
          <option value="ready_for_pickup" <?= $filters['status'] === 'ready_for_pickup' ? 'selected' : '' ?>>Ready for Pickup</option>
          <option value="completed" <?= $filters['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
          <option value="cancelled" <?= $filters['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
        </select>
      </div>

      <div class="form-group" style="margin-bottom: 0; min-width: 150px;">
        <label for="payment_status" class="form-label" style="font-size: 0.75rem;">Status Bayar</label>
        <select name="payment_status" id="payment_status" class="form-control" style="padding: 6px 10px; font-size: 0.8rem;">
          <option value="">Semua Pembayaran</option>
          <option value="paid" <?= $filters['payment_status'] === 'paid' ? 'selected' : '' ?>>Lunas (Paid)</option>
          <option value="pending_verification" <?= $filters['payment_status'] === 'pending_verification' ? 'selected' : '' ?>>Menunggu Verifikasi</option>
          <option value="unpaid" <?= $filters['payment_status'] === 'unpaid' ? 'selected' : '' ?>>Belum Lunas (Unpaid)</option>
          <option value="rejected" <?= $filters['payment_status'] === 'rejected' ? 'selected' : '' ?>>Ditolak (Rejected)</option>
        </select>
      </div>

      <div style="display: flex; gap: 8px;">
        <button type="submit" class="btn btn-primary" style="padding: 6px 16px; font-size: 0.8rem; font-weight: 700;">
          Filter Data
        </button>
        <a href="/admin/reports" class="btn btn-secondary" style="padding: 6px 14px; font-size: 0.8rem;">
          Reset
        </a>
      </div>
    </form>
  </div>

  <!-- 4 Summary Metric Cards (Aggregated) -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: var(--spacing-4); margin-bottom: var(--spacing-6);">
    <!-- Card 1: Paid Revenue -->
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); box-shadow: var(--shadow-sm); border-top: 4px solid var(--color-success);">
      <div style="font-size: 0.75rem; color: var(--color-text-muted); font-weight: 700; text-transform: uppercase;">
        Pendapatan Lunas (Kas Masuk)
      </div>
      <div style="font-size: 1.4rem; font-weight: 800; color: var(--color-success); margin: 6px 0;">
        <?= rupiah($metrics['total_paid_revenue']) ?>
      </div>
      <div style="font-size: 0.7rem; color: var(--color-text-muted);">
        Uang riil yang sudah terverifikasi admin
      </div>
    </div>

    <!-- Card 2: Total Active GMV -->
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); box-shadow: var(--shadow-sm); border-top: 4px solid var(--color-primary);">
      <div style="font-size: 0.75rem; color: var(--color-text-muted); font-weight: 700; text-transform: uppercase;">
        Nilai Pesanan Aktif (GMV)
      </div>
      <div style="font-size: 1.4rem; font-weight: 800; color: var(--color-primary); margin: 6px 0;">
        <?= rupiah($metrics['total_gmv']) ?>
      </div>
      <div style="font-size: 0.7rem; color: var(--color-text-muted);">
        Total transaksi di luar pesanan dibatalkan
      </div>
    </div>

    <!-- Card 3: Unpaid Revenue -->
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); box-shadow: var(--shadow-sm); border-top: 4px solid #F59E0B;">
      <div style="font-size: 0.75rem; color: var(--color-text-muted); font-weight: 700; text-transform: uppercase;">
        Belum Lunas / Menunggu
      </div>
      <div style="font-size: 1.4rem; font-weight: 800; color: #D97706; margin: 6px 0;">
        <?= rupiah($metrics['total_unpaid_revenue']) ?>
      </div>
      <div style="font-size: 0.7rem; color: var(--color-text-muted);">
        Pesanan aktif COD atau QRIS menunggu bayar
      </div>
    </div>

    <!-- Card 4: Orders Breakdown -->
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); box-shadow: var(--shadow-sm); border-top: 4px solid #6366F1;">
      <div style="font-size: 0.75rem; color: var(--color-text-muted); font-weight: 700; text-transform: uppercase;">
        Volume Pesanan
      </div>
      <div style="font-size: 1.4rem; font-weight: 800; color: var(--color-text-main); margin: 6px 0;">
        <?= (int)$metrics['total_orders'] ?> <span style="font-size: 0.85rem; font-weight: 600;">pesanan</span>
      </div>
      <div style="font-size: 0.7rem; color: var(--color-text-muted);">
        <?= (int)$metrics['completed_count'] ?> selesai &bull; <?= (int)$metrics['cancelled_count'] ?> dibatalkan
      </div>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr; gap: var(--spacing-6); margin-bottom: var(--spacing-6);">
    <!-- Top 5 Best Selling Products -->
    <?php if (!empty($topProducts)): ?>
      <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
        <h2 style="font-size: var(--font-size-base); font-weight: 800; margin-bottom: var(--spacing-3); color: var(--color-text-main);">
          Top 5 Produk Terlaris (Berdasarkan Kuantitas Terjual)
        </h2>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th style="width: 50px;">No</th>
                <th>Nama Produk</th>
                <th style="text-align: center;">Total Kuantitas Terjual</th>
                <th style="text-align: right;">Total Nilai Penjualan</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($topProducts as $idx => $prod): ?>
                <tr>
                  <td style="font-weight: 700; color: var(--color-text-muted);"><?= $idx + 1 ?></td>
                  <td style="font-weight: 700; color: var(--color-text-main);"><?= e($prod['product_name']) ?></td>
                  <td style="text-align: center; font-weight: 700; color: var(--color-primary);"><?= (int)$prod['total_qty'] ?> unit</td>
                  <td style="text-align: right; font-weight: 700;"><?= rupiah($prod['total_sales']) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endif; ?>

    <!-- Detailed Transaction Table -->
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
      <h2 style="font-size: var(--font-size-base); font-weight: 800; margin-bottom: var(--spacing-3); color: var(--color-text-main);">
        Rincian Transaksi Pesanan (<?= (int)$total ?> Transaksi Ditemukan)
      </h2>

      <?php if (empty($orders)): ?>
        <p style="text-align: center; color: var(--color-text-muted); padding: 30px 0; font-size: var(--font-size-sm);">
          Tidak ada transaksi yang cocok dengan kriteria filter saat ini.
        </p>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Kode Pesanan</th>
                <th>Tanggal</th>
                <th>Mahasiswa Pemesan</th>
                <th>Metode</th>
                <th>Status Pesanan</th>
                <th>Status Pembayaran</th>
                <th style="text-align: right;">Nominal Total</th>
                <th style="text-align: center;">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($orders as $ord): ?>
                <tr>
                  <td>
                    <strong>#<?= e($ord['order_code']) ?></strong>
                  </td>
                  <td style="font-size: 0.75rem; color: var(--color-text-muted);">
                    <?= date('d M Y, H:i', strtotime($ord['created_at'])) ?>
                  </td>
                  <td>
                    <div style="font-weight: 600; font-size: var(--font-size-xs);"><?= e($ord['customer_name']) ?></div>
                    <div style="font-size: 0.7rem; color: var(--color-text-muted);"><?= e($ord['customer_email']) ?></div>
                  </td>
                  <td>
                    <span style="font-weight: 700; text-transform: uppercase; font-size: 0.75rem;"><?= e($ord['payment_method']) ?></span>
                  </td>
                  <td>
                    <span class="badge badge-<?= e($ord['status']) ?>">
                      <?= e(str_replace('_', ' ', $ord['status'])) ?>
                    </span>
                  </td>
                  <td>
                    <span class="badge badge-<?= e($ord['payment_status']) ?>">
                      <?= e(str_replace('_', ' ', $ord['payment_status'])) ?>
                    </span>
                  </td>
                  <td style="text-align: right; font-weight: 700; color: var(--color-primary);">
                    <?= rupiah($ord['total']) ?>
                  </td>
                  <td style="text-align: center;">
                    <a href="/admin/orders/<?= (int)$ord['id'] ?>" class="btn btn-secondary btn-sm" style="padding: 4px 8px; font-size: 0.75rem;">
                      Detail
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
          <div style="display: flex; justify-content: center; gap: 6px; margin-top: var(--spacing-4); flex-wrap: wrap;">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
              <?php
                $queryParams = array_merge($filters, ['page' => $p]);
                $pageUrl = '/admin/reports?' . http_build_query(array_filter($queryParams));
              ?>
              <a href="<?= e($pageUrl) ?>" class="btn <?= $p === $page ? 'btn-primary' : 'btn-secondary' ?> btn-sm" style="padding: 4px 10px; font-size: 0.75rem;">
                <?= $p ?>
              </a>
            <?php endfor; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
