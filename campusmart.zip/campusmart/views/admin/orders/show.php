<div style="margin-bottom: var(--spacing-6); max-width: 900px;">
  <!-- Back Button -->
  <div style="margin-bottom: var(--spacing-4);">
    <a href="/admin/orders" class="btn btn-secondary btn-sm">&larr; Kembali ke Kelola Pesanan</a>
  </div>

  <!-- Header Order Banner (matching Frame 29) -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm); margin-bottom: var(--spacing-6);">
    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 8px;">
      <div>
        <h1 style="font-size: var(--font-size-xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 2px;">
          Pesanan #<?= e($order['order_code']) ?>
        </h1>
        <div style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
          Dibuat: <?= date('d F Y, H:i', strtotime($order['created_at'])) ?> WIB
        </div>
      </div>

      <div style="display: flex; gap: 8px; align-items: center;">
        <span class="badge badge-<?= e($order['status']) ?>" style="font-size: 0.85rem; padding: 4px 14px;">
          <?= e(str_replace('_', ' ', $order['status'])) ?>
        </span>
        <span class="badge badge-<?= e($order['payment_status']) ?>" style="font-size: 0.85rem; padding: 4px 14px;">
          Bayar: <?= e(str_replace('_', ' ', $order['payment_status'])) ?>
        </span>
      </div>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr; gap: var(--spacing-6);" class="order-admin-grid">
    <!-- Customer Details Card (matching Frame 29) -->
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
      <h2 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3); color: var(--color-text-muted); text-transform: uppercase;">
        Data Pemesan (Mahasiswa)
      </h2>
      <div style="display: flex; align-items: center; gap: 12px; margin-bottom: var(--spacing-3);">
        <div style="width: 44px; height: 44px; border-radius: var(--radius-full); background: var(--color-primary-soft); color: var(--color-primary); display: flex; align-items: center; justify-content: center; font-weight: 800;">
          <?= strtoupper(substr($order['customer_name'], 0, 1)) ?>
        </div>
        <div>
          <div style="font-weight: 700; font-size: var(--font-size-base);"><?= e($order['customer_name']) ?></div>
          <div style="font-size: var(--font-size-xs); color: var(--color-text-muted);"><?= e($order['customer_email']) ?> &bull; <?= e($order['customer_phone'] ?: 'Tidak ada nomor telepon') ?></div>
          <?php if (!empty($order['student_id'])): ?>
            <div style="font-size: var(--font-size-xs); color: var(--color-primary); font-weight: 600;">NIM: <?= e($order['student_id']) ?></div>
          <?php endif; ?>
        </div>
      </div>
      <?php if (!empty($order['customer_note'])): ?>
        <div style="background: #F8FAFC; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: var(--spacing-3); font-size: var(--font-size-xs); color: var(--color-text-main);">
          <strong>Catatan Mahasiswa:</strong> "<?= e($order['customer_note']) ?>"
        </div>
      <?php endif; ?>
    </div>

    <!-- Order Items Snapshot (matching Frame 29) -->
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
      <h2 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3); color: var(--color-text-muted); text-transform: uppercase;">
        Rincian Barang Pesanan (Snapshot)
      </h2>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Produk</th>
              <th>Harga Satuan</th>
              <th>Kuantitas</th>
              <th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($items as $item): ?>
              <tr>
                <td>
                  <strong><?= e($item['product_name']) ?></strong>
                </td>
                <td><?= rupiah($item['unit_price']) ?></td>
                <td><?= (int)$item['quantity'] ?></td>
                <td style="font-weight: 700; color: var(--color-primary);"><?= rupiah($item['line_total']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3" style="text-align: right; font-weight: 600;">Subtotal:</td>
              <td style="font-weight: 700;"><?= rupiah($order['subtotal']) ?></td>
            </tr>
            <tr>
              <td colspan="3" style="text-align: right; font-weight: 600;">Pengiriman Internal Kampus:</td>
              <td style="font-weight: 600; color: var(--color-success);">Rp 0 (Counter Kampus)</td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td colspan="3" style="text-align: right; font-weight: 800; font-size: 1rem;">Total Pesanan:</td>
              <td style="font-weight: 800; color: var(--color-primary); font-size: 1.1rem;"><?= rupiah($order['total']) ?></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>

    <!-- Management Controls: Status Transition & Payment Verification -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--spacing-4);" class="controls-grid">
      <!-- Card 1: Perbarui Status Pesanan -->
      <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
        <h3 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3);">
          Perbarui Status Pesanan
        </h3>
        
        <?php if (!empty($allowedTransitions)): ?>
          <form action="/admin/orders/<?= (int)$order['id'] ?>/status" method="POST" data-confirm="Apakah Anda yakin ingin memperbarui status pesanan ini?">
            <?= csrf_field() ?>
            
            <div class="form-group">
              <label for="status" class="form-label">Transisi Status yang Diizinkan:</label>
              <select name="status" id="status" class="form-control" required>
                <option value="">-- Pilih Status Berikutnya --</option>
                <?php foreach ($allowedTransitions as $nextStatus): ?>
                  <option value="<?= e($nextStatus) ?>">
                    &rarr; Ubah ke <?= strtoupper(str_replace('_', ' ', $nextStatus)) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="form-group">
              <label for="note" class="form-label">Catatan Perubahan (Opsional)</label>
              <input type="text" name="note" id="note" class="form-control" placeholder="Contoh: Barang telah disiapkan di counter">
            </div>

            <button type="submit" class="btn btn-primary btn-block">
              Simpan Status Baru
            </button>
          </form>
        <?php else: ?>
          <p style="color: var(--color-text-muted); font-size: var(--font-size-xs);">
            Pesanan ini telah mencapai status terminal (<strong><?= strtoupper(str_replace('_', ' ', $order['status'])) ?></strong>). Tidak ada transisi status lanjutan yang diizinkan.
          </p>
        <?php endif; ?>
      </div>

      <!-- Card 2: Verifikasi Pembayaran -->
      <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
        <h3 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3);">
          Verifikasi Pembayaran (<?= strtoupper($order['payment_method']) ?>)
        </h3>

        <?php if ($payment): ?>
          <div style="font-size: var(--font-size-xs); color: var(--color-text-muted); margin-bottom: var(--spacing-3);">
            Nominal: <strong><?= rupiah($payment['amount']) ?></strong> &bull; Status: <strong><?= strtoupper($payment['status']) ?></strong>
            <?php if (!empty($payment['verifier_name'])): ?>
              <br>Diverifikasi oleh: <?= e($payment['verifier_name']) ?> pada <?= date('d M Y, H:i', strtotime($payment['verified_at'])) ?>
            <?php endif; ?>
          </div>

          <?php if (!empty($payment['proof_path'])): ?>
            <div style="background: #F8FAFC; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: var(--spacing-3); margin-bottom: var(--spacing-3);">
              <div style="font-weight: 700; font-size: var(--font-size-xs); margin-bottom: 6px;">Bukti Transfer Terlampir:</div>
              <a href="<?= asset($payment['proof_path']) ?>" target="_blank" title="Klik untuk membuka bukti ukuran penuh">
                <img src="<?= asset($payment['proof_path']) ?>" alt="Bukti Transfer" style="max-width: 100%; max-height: 160px; object-fit: contain; border: 1px solid var(--color-border); border-radius: var(--radius-sm); background: #FFFFFF; display: block;">
              </a>
              <div style="font-size: 0.7rem; margin-top: 4px;">
                <a href="<?= asset($payment['proof_path']) ?>" target="_blank" style="color: var(--color-primary); font-weight: 600;">&rarr; Buka Gambar Ukuran Penuh</a>
              </div>
            </div>
          <?php elseif ($order['payment_method'] === 'qris'): ?>
            <div style="background: #FFFBEB; border: 1px solid #FDE68A; border-radius: var(--radius-sm); padding: var(--spacing-2) var(--spacing-3); font-size: 0.7rem; color: #92400E; margin-bottom: var(--spacing-3);">
              Mahasiswa belum mengunggah bukti transfer QRIS.
            </div>
          <?php endif; ?>
        <?php endif; ?>

        <form action="/admin/orders/<?= (int)$order['id'] ?>/payment" method="POST" data-confirm="Apakah Anda yakin ingin memperbarui status pembayaran pesanan ini?">
          <?= csrf_field() ?>

          <div class="form-group">
            <label for="payment_status" class="form-label">Pilih Status Pembayaran:</label>
            <select name="payment_status" id="payment_status" class="form-control" required>
              <option value="unpaid" <?= $order['payment_status'] === 'unpaid' ? 'selected' : '' ?>>Belum Lunas (Unpaid)</option>
              <option value="pending_verification" <?= $order['payment_status'] === 'pending_verification' ? 'selected' : '' ?>>Menunggu Verifikasi</option>
              <option value="paid" <?= $order['payment_status'] === 'paid' ? 'selected' : '' ?>>Lunas / Terverifikasi (Paid)</option>
              <option value="rejected" <?= $order['payment_status'] === 'rejected' ? 'selected' : '' ?>>Ditolak (Rejected)</option>
            </select>
          </div>

          <button type="submit" class="btn btn-secondary btn-block">
            Perbarui Pembayaran
          </button>
        </form>
      </div>
    </div>

    <!-- Status History Audit Trail -->
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
      <h3 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3); color: var(--color-text-muted); text-transform: uppercase;">
        Log Audit Riwayat Perubahan Status
      </h3>
      <?php if (!empty($histories)): ?>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Waktu</th>
                <th>Status Baru</th>
                <th>Oleh</th>
                <th>Catatan</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($histories as $hist): ?>
                <tr>
                  <td style="font-size: 0.75rem;"><?= date('d M Y, H:i:s', strtotime($hist['created_at'])) ?></td>
                  <td>
                    <span class="badge badge-<?= e($hist['new_status']) ?>">
                      <?= e(str_replace('_', ' ', $hist['new_status'])) ?>
                    </span>
                  </td>
                  <td><?= e($hist['actor_name'] ?: 'Sistem') ?> (<?= e($hist['actor_role'] ?: '-') ?>)</td>
                  <td style="font-size: 0.8rem;"><?= e($hist['note'] ?: '-') ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p style="color: var(--color-text-muted); font-size: var(--font-size-xs);">Belum ada log riwayat status tercatat.</p>
      <?php endif; ?>
    </div>
  </div>

  <style>
    @media (max-width: 768px) {
      .controls-grid {
        grid-template-columns: 1fr !important;
      }
    }
  </style>
</div>
