<div style="margin-bottom: var(--spacing-6);">
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-4); flex-wrap: wrap; gap: var(--spacing-3);">
    <div>
      <h1 style="font-size: var(--font-size-xl); font-weight: 700;">Kelola Pesanan</h1>
      <p style="font-size: var(--font-size-xs); color: var(--color-text-muted);">Pantau, ubah status pesanan, dan verifikasi pembayaran mahasiswa.</p>
    </div>
  </div>

  <!-- Filter Bar -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); margin-bottom: var(--spacing-4); box-shadow: var(--shadow-sm);">
    <form action="/admin/orders" method="GET" style="display: flex; gap: var(--spacing-3); flex-wrap: wrap;">
      <div style="flex: 1; min-width: 200px; position: relative;">
        <span style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--color-text-muted);">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        </span>
        <input type="text" name="q" class="form-control" placeholder="Cari kode #CM..., nama pemesan..." value="<?= e($q) ?>" style="padding-left: 2.4rem;">
      </div>

      <div style="width: 170px;">
        <select name="status" class="form-control" onchange="this.form.submit()">
          <option value="">Semua Status Pesanan</option>
          <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>Pending</option>
          <option value="confirmed" <?= $status === 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
          <option value="processing" <?= $status === 'processing' ? 'selected' : '' ?>>Processing</option>
          <option value="ready_for_pickup" <?= $status === 'ready_for_pickup' ? 'selected' : '' ?>>Ready for Pickup</option>
          <option value="completed" <?= $status === 'completed' ? 'selected' : '' ?>>Completed</option>
          <option value="cancelled" <?= $status === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
        </select>
      </div>

      <div style="width: 170px;">
        <select name="payment_status" class="form-control" onchange="this.form.submit()">
          <option value="">Semua Status Bayar</option>
          <option value="unpaid" <?= $paymentStatus === 'unpaid' ? 'selected' : '' ?>>Belum Bayar (Unpaid)</option>
          <option value="pending_verification" <?= $paymentStatus === 'pending_verification' ? 'selected' : '' ?>>Menunggu Verifikasi</option>
          <option value="paid" <?= $paymentStatus === 'paid' ? 'selected' : '' ?>>Lunas (Paid)</option>
          <option value="rejected" <?= $paymentStatus === 'rejected' ? 'selected' : '' ?>>Ditolak (Rejected)</option>
        </select>
      </div>

      <div style="width: 130px;">
        <select name="payment_method" class="form-control" onchange="this.form.submit()">
          <option value="">Metode</option>
          <option value="qris" <?= $paymentMethod === 'qris' ? 'selected' : '' ?>>QRIS</option>
          <option value="cod" <?= $paymentMethod === 'cod' ? 'selected' : '' ?>>COD</option>
        </select>
      </div>

      <button type="submit" class="btn btn-secondary">Cari</button>
      <?php if (!empty($q) || !empty($status) || !empty($paymentStatus) || !empty($paymentMethod)): ?>
        <a href="/admin/orders" class="btn btn-secondary" title="Reset">&times;</a>
      <?php endif; ?>
    </form>
  </div>

  <!-- Orders Table -->
  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th>Kode Pesanan</th>
          <th>Pemesan</th>
          <th>Waktu Order</th>
          <th>Metode</th>
          <th>Total</th>
          <th>Status Pesanan</th>
          <th>Status Bayar</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($orders)): ?>
          <?php foreach ($orders as $ord): ?>
            <tr>
              <td>
                <div style="font-weight: 800; color: var(--color-text-main);">#<?= e($ord['order_code']) ?></div>
                <div style="font-size: 0.75rem; color: var(--color-text-muted);"><?= (int)$ord['item_count'] ?> item barang</div>
              </td>
              <td>
                <div style="font-weight: 700; color: var(--color-text-main);"><?= e($ord['customer_name']) ?></div>
                <div style="font-size: 0.75rem; color: var(--color-text-muted);"><?= e($ord['customer_email']) ?></div>
              </td>
              <td style="font-size: 0.8rem;"><?= date('d M Y, H:i', strtotime($ord['created_at'])) ?></td>
              <td>
                <span class="badge" style="background: #F1F5F9; font-weight: 700; text-transform: uppercase;">
                  <?= e($ord['payment_method']) ?>
                </span>
              </td>
              <td style="font-weight: 800; color: var(--color-primary);"><?= rupiah($ord['total']) ?></td>
              <td>
                <span class="badge badge-<?= e($ord['status']) ?>">
                  <?= e(str_replace('_', ' ', $ord['status'])) ?>
                </span>
              </td>
              <td>
                <span class="badge badge-<?= e($ord['payment_status']) ?>">
                  <?= e(str_replace('_', ' ', $ord['payment_status'])) ?>
                </span>
              </td>
              <td>
                <a href="/admin/orders/<?= (int)$ord['id'] ?>" class="btn btn-secondary btn-sm">
                  Kelola
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="8" style="text-align: center; color: var(--color-text-muted); padding: 3rem 0;">
              Tidak ada data pesanan yang cocok dengan kriteria filter.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($totalPages > 1): ?>
    <div style="margin-top: var(--spacing-6); display: flex; justify-content: center; gap: 6px;">
      <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <?php
          $url = '/admin/orders?' . http_build_query(array_filter([
            'q' => $q ?: null,
            'status' => $status ?: null,
            'payment_status' => $paymentStatus ?: null,
            'payment_method' => $paymentMethod ?: null,
            'page' => $i,
          ]));
        ?>
        <a href="<?= $url ?>" class="btn <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>" style="min-width: 36px; padding: 4px 10px; font-size: 0.8rem;">
          <?= $i ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>
