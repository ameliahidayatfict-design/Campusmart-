<div class="container" style="max-width: 960px; margin-top: var(--spacing-4);">
  <!-- Back Button & Breadcrumbs -->
  <div style="margin-bottom: var(--spacing-4); display: flex; align-items: center; gap: 8px;">
    <a href="/products" class="btn btn-secondary btn-sm" style="border-radius: var(--radius-full); padding: 4px 10px;">
      &larr; Kembali
    </a>
    <div style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
      <a href="/" style="color: var(--color-primary);">Beranda</a> &rsaquo;
      <a href="/products?category=<?= urlencode($product['category_slug']) ?>" style="color: var(--color-primary);"><?= e($product['category_name']) ?></a> &rsaquo;
      <span style="color: var(--color-text-main); font-weight: 500;"><?= e($product['name']) ?></span>
    </div>
  </div>

  <!-- Detail Product Card (2 Columns on Desktop, Stack on Mobile) -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-6); box-shadow: var(--shadow-sm); margin-bottom: var(--spacing-8);">
    <div style="display: grid; grid-template-columns: 1fr; gap: var(--spacing-8);" class="product-detail-grid">
      <!-- Left: Product Image -->
      <div style="background-color: #F8FAFC; border: 1px solid var(--color-border); border-radius: var(--radius-md); aspect-ratio: 1 / 1; display: flex; align-items: center; justify-content: center; overflow: hidden; max-height: 420px;">
        <?php if (!empty($product['image_path'])): ?>
          <img src="<?= asset($product['image_path']) ?>" alt="<?= e($product['name']) ?>" style="max-width: 85%; max-height: 85%; object-fit: contain;" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'180\' height=\'180\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23800020\' stroke-width=\'1\'><rect x=\'3\' y=\'3\' width=\'18\' height=\'18\' rx=\'2\'/><circle cx=\'8.5\' cy=\'8.5\' r=\'1.5\'/><path d=\'M21 15l-5-5L5 21\'/></svg>'">
        <?php else: ?>
          <div style="color: var(--color-text-muted);">Foto Produk</div>
        <?php endif; ?>
      </div>

      <!-- Right: Product Info & Actions -->
      <div style="display: flex; flex-direction: column;">
        <span style="font-size: var(--font-size-xs); font-weight: 700; color: var(--color-primary); text-transform: uppercase; margin-bottom: var(--spacing-1);">
          <?= e($product['category_name']) ?>
        </span>

        <h1 style="font-size: var(--font-size-2xl); font-weight: 800; color: var(--color-text-main); line-height: 1.25; margin-bottom: var(--spacing-3);">
          <?= e($product['name']) ?>
        </h1>

        <!-- Rating & Stock Status (matching Frame 7) -->
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: var(--spacing-4); flex-wrap: wrap;">
          <span style="font-size: var(--font-size-xs); font-weight: 600; color: #D97706; display: flex; align-items: center; gap: 4px;">
            <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            4.8 (Produk Terverifikasi)
          </span>

          <span style="font-size: var(--font-size-xs); display: flex; align-items: center; gap: 6px;">
            <span style="width: 8px; height: 8px; border-radius: var(--radius-full); background: <?= (int)$product['stock'] > 0 ? 'var(--color-success)' : 'var(--color-danger)' ?>;"></span>
            <span style="color: <?= (int)$product['stock'] > 0 ? 'var(--color-success)' : 'var(--color-danger)' ?>; font-weight: 600;">
              <?= (int)$product['stock'] > 0 ? 'Stok tersedia (' . (int)$product['stock'] . ' unit)' : 'Stok habis' ?>
            </span>
          </span>
        </div>

        <!-- Price -->
        <div style="font-size: 2rem; font-weight: 800; color: var(--color-primary); margin-bottom: var(--spacing-4);">
          <?= rupiah($product['price']) ?>
        </div>

        <!-- Description -->
        <div style="margin-bottom: var(--spacing-6); border-top: 1px solid var(--color-border); border-bottom: 1px solid var(--color-border); padding: var(--spacing-4) 0;">
          <h2 style="font-size: var(--font-size-sm); font-weight: 700; color: var(--color-text-main); margin-bottom: var(--spacing-2);">
            Deskripsi Produk
          </h2>
          <div style="font-size: var(--font-size-sm); color: var(--color-text-muted); line-height: 1.6;">
            <?= nl2br(e($product['description'] ?: 'Tidak ada deskripsi rinci untuk produk ini.')) ?>
          </div>
        </div>

        <!-- Penjual Info (matching Frame 7) -->
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: var(--spacing-6); background: #F8FAFC; padding: var(--spacing-3) var(--spacing-4); border-radius: var(--radius-md);">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 36px; height: 36px; border-radius: var(--radius-full); background: #E2E8F0; display: flex; align-items: center; justify-content: center; color: var(--color-primary); font-weight: 700;">
              CM
            </div>
            <div>
              <div style="font-size: var(--font-size-sm); font-weight: 700;">Official CampusMart Store</div>
              <div style="font-size: 0.7rem; color: var(--color-success); font-weight: 600;">&bull; Layanan Internal Kampus</div>
            </div>
          </div>
          <span style="font-size: var(--font-size-xs); color: var(--color-text-muted);">Gedung Rektorat Lt. 1</span>
        </div>

        <!-- Action Add to Cart Form with Alpine.js Live Update -->
        <form 
          action="/cart/add" 
          method="POST" 
          x-data="productAddToCart({ stock: <?= (int)$product['stock'] ?>, isLoggedIn: <?= is_logged_in() ? 'true' : 'false' ?> })"
          @submit.prevent="submit($el)"
          style="margin-top: auto;"
        >
          <?= csrf_field() ?>
          <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">

          <div style="display: flex; align-items: center; gap: var(--spacing-4); flex-wrap: wrap;">
            <!-- Quantity Stepper -->
            <div class="qty-stepper">
              <button type="button" class="qty-stepper-btn" @click="decrement()" :disabled="qty <= 1" title="Kurangi jumlah">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
              </button>
              <input type="number" name="quantity" x-model="qty" class="qty-stepper-input" min="1" max="<?= max(1, (int)$product['stock']) ?>" <?= (int)$product['stock'] <= 0 ? 'disabled' : '' ?> readonly>
              <button type="button" class="qty-stepper-btn" @click="increment()" :disabled="qty >= stock" title="Tambah jumlah">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
              </button>
            </div>

            <!-- Submit Button (Maroon) with Animated Feedback -->
            <button 
              type="submit" 
              class="btn btn-primary btn-lg" 
              :class="{ 'btn-success': added }"
              :disabled="stock <= 0 || loading"
              style="flex: 1; height: 46px; transition: all 0.25s ease;" 
              <?= (int)$product['stock'] <= 0 ? 'disabled style="opacity: 0.5; cursor: not-allowed;"' : '' ?>
            >
              <template x-if="loading">
                <span style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                  <svg class="cm-spinner" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10" stroke-width="3" stroke-opacity="0.25"></circle><path d="M12 2a10 10 0 0110 10" stroke-width="3"></path></svg>
                  Menambahkan...
                </span>
              </template>
              <template x-if="!loading && added">
                <span style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                  <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                  Ditambahkan!
                </span>
              </template>
              <template x-if="!loading && !added">
                <span style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                  <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
                  <?= (int)$product['stock'] > 0 ? 'Tambah ke Keranjang' : 'Stok Habis' ?>
                </span>
              </template>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <style>
    @media (min-width: 768px) {
      .product-detail-grid {
        grid-template-columns: 1fr 1.2fr !important;
      }
    }
  </style>

  <!-- Related Products (matching Frame 7) -->
  <?php if (!empty($related)): ?>
    <section style="margin-bottom: var(--spacing-8);">
      <div class="section-header">
        <h2 class="section-title">Produk Terkait Lainnya</h2>
        <a href="/products?category=<?= urlencode($product['category_slug']) ?>" class="section-link">Lihat di Kategori Ini</a>
      </div>
      <div class="product-grid">
        <?php foreach ($related as $rel): ?>
          <a href="/products/<?= e($rel['slug']) ?>" class="product-card">
            <div class="product-img-wrap">
              <?php if (!empty($rel['image_path'])): ?>
                <img src="<?= asset($rel['image_path']) ?>" alt="<?= e($rel['name']) ?>" class="product-img" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'120\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23800020\' stroke-width=\'1\'><rect x=\'3\' y=\'3\' width=\'18\' height=\'18\' rx=\'2\'/><circle cx=\'8.5\' cy=\'8.5\' r=\'1.5\'/><path d=\'M21 15l-5-5L5 21\'/></svg>'">
              <?php else: ?>
                <div style="color: var(--color-text-muted); font-size: 0.75rem;">Foto Produk</div>
              <?php endif; ?>
            </div>
            <div class="product-body">
              <span class="product-cat"><?= e($rel['category_name']) ?></span>
              <h3 class="product-title"><?= e($rel['name']) ?></h3>
              <div class="product-price-row">
                <span class="product-price"><?= rupiah($rel['price']) ?></span>
                <span class="product-stock">Stok: <?= (int)$rel['stock'] ?></span>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    </section>
  <?php endif; ?>
</div>
