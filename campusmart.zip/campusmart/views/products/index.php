<div class="container" style="margin-top: var(--spacing-4);">
  <!-- Breadcrumb & Header Title -->
  <div style="margin-bottom: var(--spacing-4);">
    <div style="font-size: var(--font-size-xs); color: var(--color-text-muted); margin-bottom: var(--spacing-1);">
      <a href="/" style="color: var(--color-primary); font-weight: 500;">Beranda</a> &rsaquo;
      <span>Katalog</span>
      <?php if (!empty($currentCategory)): ?>
        &rsaquo; <span style="font-weight: 600; color: var(--color-text-main);"><?= e($currentCategory['name']) ?></span>
      <?php endif; ?>
    </div>
    <div style="display: flex; align-items: baseline; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
      <h1 style="font-size: var(--font-size-2xl); font-weight: 800; color: var(--color-text-main);">
        <?= !empty($currentCategory) ? e($currentCategory['name']) : 'Katalog Produk Kampus' ?>
      </h1>
      <span style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
        Menampilkan <strong><?= count($products) ?></strong> dari <strong><?= $total ?></strong> produk
      </span>
    </div>
  </div>

  <!-- Mobile Category Scroll Chips -->
  <div class="category-scroll" style="margin-bottom: var(--spacing-4);">
    <a href="/products<?= !empty($q) ? '?q=' . urlencode($q) : '' ?>" class="category-chip <?= empty($currentCategory) ? 'active' : '' ?>">
      Semua Kategori
    </a>
    <?php foreach ($categories as $cat): ?>
      <?php
        $catUrl = '/products?category=' . urlencode($cat['slug']);
        if (!empty($q)) $catUrl .= '&q=' . urlencode($q);
      ?>
      <a href="<?= $catUrl ?>" class="category-chip <?= (!empty($currentCategory) && $currentCategory['slug'] === $cat['slug']) ? 'active' : '' ?>">
        <?= e($cat['name']) ?> (<?= (int)$cat['product_count'] ?>)
      </a>
    <?php endforeach; ?>
  </div>

  <!-- Desktop Grid Layout: Sidebar Filter (Left) & Products (Right) -->
  <div style="display: flex; gap: var(--spacing-6); align-items: flex-start;">
    <!-- Desktop Sidebar Filter -->
    <aside style="width: 240px; display: none; background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); box-shadow: var(--shadow-sm);" class="catalog-sidebar">
      <h2 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3); border-bottom: 1px solid var(--color-border); padding-bottom: var(--spacing-2);">
        Kategori
      </h2>
      <ul style="list-style: none; display: flex; flex-direction: column; gap: 6px; margin-bottom: var(--spacing-6);">
        <li>
          <a href="/products<?= !empty($q) ? '?q=' . urlencode($q) : '' ?>" style="display: flex; justify-content: space-between; font-size: var(--font-size-sm); color: <?= empty($currentCategory) ? 'var(--color-primary); font-weight: 700;' : 'var(--color-text-main);' ?>">
            <span>Semua</span>
            <span style="color: var(--color-text-muted); font-size: 0.75rem;"><?= $total ?></span>
          </a>
        </li>
        <?php foreach ($categories as $cat): ?>
          <li>
            <a href="/products?category=<?= urlencode($cat['slug']) ?><?= !empty($q) ? '&q=' . urlencode($q) : '' ?>" style="display: flex; justify-content: space-between; font-size: var(--font-size-sm); color: <?= (!empty($currentCategory) && $currentCategory['slug'] === $cat['slug']) ? 'var(--color-primary); font-weight: 700;' : 'var(--color-text-main);' ?>">
              <span><?= e($cat['name']) ?></span>
              <span style="color: var(--color-text-muted); font-size: 0.75rem;"><?= (int)$cat['product_count'] ?></span>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>

      <h2 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3); border-bottom: 1px solid var(--color-border); padding-bottom: var(--spacing-2);">
        Urutkan
      </h2>
      <form action="/products" method="GET" id="desktopSortForm">
        <?php if (!empty($q)): ?>
          <input type="hidden" name="q" value="<?= e($q) ?>">
        <?php endif; ?>
        <?php if (!empty($currentCategory)): ?>
          <input type="hidden" name="category" value="<?= e($currentCategory['slug']) ?>">
        <?php endif; ?>
        <select name="sort" class="form-control" onchange="this.form.submit()" style="font-size: var(--font-size-xs);">
          <option value="" <?= empty($sort) ? 'selected' : '' ?>>Terbaru</option>
          <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Harga: Rendah ke Tinggi</option>
          <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Harga: Tinggi ke Rendah</option>
          <option value="name_asc" <?= $sort === 'name_asc' ? 'selected' : '' ?>>Nama: A - Z</option>
        </select>
      </form>
    </aside>

    <style>
      @media (min-width: 1024px) {
        .catalog-sidebar {
          display: block !important;
        }
      }
    </style>

    <!-- Product Grid & Pagination (Right) -->
    <div style="flex: 1; min-width: 0;">
      <!-- Active Search/Filter Info -->
      <?php if (!empty($q) || !empty($currentCategory)): ?>
        <div style="background: var(--color-primary-soft); border: 1px solid var(--color-primary-light); padding: var(--spacing-3) var(--spacing-4); border-radius: var(--radius-md); margin-bottom: var(--spacing-4); display: flex; align-items: center; justify-content: space-between; font-size: var(--font-size-xs);">
          <div>
            <?php if (!empty($q)): ?>
              Pencarian: <strong>"<?= e($q) ?>"</strong>
            <?php endif; ?>
            <?php if (!empty($currentCategory)): ?>
              <?= !empty($q) ? '&bull;' : '' ?> Kategori: <strong><?= e($currentCategory['name']) ?></strong>
            <?php endif; ?>
          </div>
          <a href="/products" style="color: var(--color-primary); font-weight: 700;">Reset Filter &times;</a>
        </div>
      <?php endif; ?>

      <?php if (!empty($products)): ?>
        <div class="product-grid">
          <?php foreach ($products as $prod): ?>
            <a href="/products/<?= e($prod['slug']) ?>" class="product-card">
              <div class="product-img-wrap">
                <?php if (!empty($prod['image_path'])): ?>
                  <img src="<?= asset($prod['image_path']) ?>" alt="<?= e($prod['name']) ?>" class="product-img" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'120\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23800020\' stroke-width=\'1\'><rect x=\'3\' y=\'3\' width=\'18\' height=\'18\' rx=\'2\'/><circle cx=\'8.5\' cy=\'8.5\' r=\'1.5\'/><path d=\'M21 15l-5-5L5 21\'/></svg>'">
                <?php else: ?>
                  <div style="color: var(--color-text-muted); font-size: 0.75rem;">Foto Produk</div>
                <?php endif; ?>
              </div>
              <div class="product-body">
                <span class="product-cat"><?= e($prod['category_name']) ?></span>
                <h3 class="product-title"><?= e($prod['name']) ?></h3>
                <div class="product-price-row">
                  <span class="product-price"><?= rupiah($prod['price']) ?></span>
                  <span class="product-stock">Stok: <?= (int)$prod['stock'] ?></span>
                </div>
              </div>
            </a>
          <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
          <div style="margin-top: var(--spacing-8); display: flex; justify-content: center; gap: 6px; flex-wrap: wrap;">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
              <?php
                $queryParams = array_filter([
                  'category' => $currentCategory['slug'] ?? null,
                  'q' => $q ?: null,
                  'sort' => $sort ?: null,
                  'page' => $i,
                ]);
                $pageUrl = '/products?' . http_build_query($queryParams);
              ?>
              <a href="<?= $pageUrl ?>" class="btn <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>" style="min-width: 40px; padding: 6px 12px; font-size: 0.85rem;">
                <?= $i ?>
              </a>
            <?php endfor; ?>
          </div>
        <?php endif; ?>

      <?php else: ?>
        <!-- Empty State -->
        <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: 4rem 2rem; text-align: center;">
          <div style="width: 64px; height: 64px; margin: 0 auto var(--spacing-4) auto; background: var(--color-primary-soft); color: var(--color-primary); border-radius: var(--radius-full); display: flex; align-items: center; justify-content: center;">
            <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
          </div>
          <h2 style="font-size: var(--font-size-lg); font-weight: 700; color: var(--color-text-main); margin-bottom: var(--spacing-2);">
            Produk Tidak Ditemukan
          </h2>
          <p style="color: var(--color-text-muted); font-size: var(--font-size-sm); max-width: 420px; margin: 0 auto var(--spacing-6) auto;">
            Kami tidak menemukan produk yang sesuai dengan kata kunci atau filter kategori yang Anda pilih.
          </p>
          <a href="/products" class="btn btn-primary">Lihat Semua Produk</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
