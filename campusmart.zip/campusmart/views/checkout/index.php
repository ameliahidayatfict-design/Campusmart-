<div class="container" style="max-width: 1040px; margin-top: var(--spacing-4); margin-bottom: var(--spacing-8);">
  <div style="margin-bottom: var(--spacing-6);">
    <a href="/cart" class="btn btn-secondary btn-sm" style="margin-bottom: var(--spacing-3);">&larr; Kembali ke Keranjang</a>
    <h1 style="font-size: var(--font-size-2xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 4px;">
      Checkout Pesanan
    </h1>
    <div style="font-size: var(--font-size-sm); color: var(--color-text-muted);">
      Lengkapi data pemesan dan pilih metode pembayaran resmi kampus.
    </div>
  </div>

  <form action="/checkout" method="POST" enctype="multipart/form-data" id="checkout-form">
    <?= csrf_field() ?>

    <div style="display: grid; grid-template-columns: 1fr; gap: var(--spacing-6);" class="checkout-layout-grid">
      <!-- Left Column: Forms -->
      <div style="display: flex; flex-direction: column; gap: var(--spacing-5);">
        
        <!-- Card 1: Data Pemesan -->
        <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
          <h2 style="font-size: var(--font-size-base); font-weight: 800; margin-bottom: var(--spacing-4); color: var(--color-text-main); display: flex; align-items: center; gap: 8px;">
            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--color-primary);"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
            1. Data Pemesan
          </h2>

          <div class="form-group">
            <label for="customer_name" class="form-label">Nama Lengkap Mahasiswa <span style="color: var(--color-danger);">*</span></label>
            <input type="text" name="customer_name" id="customer_name" class="form-control" value="<?= e($old['customer_name'] ?? $user['name']) ?>" required>
            <?php if (!empty($errors['customer_name'])): ?>
              <div style="color: var(--color-danger); font-size: var(--font-size-xs); margin-top: 4px;"><?= e($errors['customer_name']) ?></div>
            <?php endif; ?>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--spacing-4);" class="contact-grid">
            <div class="form-group">
              <label for="customer_email" class="form-label">Email Kampus / Aktif <span style="color: var(--color-danger);">*</span></label>
              <input type="email" name="customer_email" id="customer_email" class="form-control" value="<?= e($old['customer_email'] ?? $user['email']) ?>" required>
              <?php if (!empty($errors['customer_email'])): ?>
                <div style="color: var(--color-danger); font-size: var(--font-size-xs); margin-top: 4px;"><?= e($errors['customer_email']) ?></div>
              <?php endif; ?>
            </div>

            <div class="form-group">
              <label for="customer_phone" class="form-label">Nomor WhatsApp / HP</label>
              <input type="tel" name="customer_phone" id="customer_phone" class="form-control" placeholder="08xxxxxxxxxx" value="<?= e($old['customer_phone'] ?? $user['phone'] ?? '') ?>">
            </div>
          </div>

          <div class="form-group" style="margin-bottom: 0;">
            <label for="customer_note" class="form-label">Catatan Tambahan untuk Petugas Counter (Opsional)</label>
            <input type="text" name="customer_note" id="customer_note" class="form-control" placeholder="Contoh: Ambil jam 13:00 setelah kelas praktikum" value="<?= e($old['customer_note'] ?? '') ?>">
          </div>
        </div>

        <!-- Card 2: Pengambilan Kampus -->
        <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
          <h2 style="font-size: var(--font-size-base); font-weight: 800; margin-bottom: var(--spacing-3); color: var(--color-text-main); display: flex; align-items: center; gap: 8px;">
            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--color-primary);"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            2. Titik Serah-Terima Internal Kampus
          </h2>

          <div style="background: var(--color-primary-soft); border-left: 4px solid var(--color-primary); padding: var(--spacing-4); border-radius: 0 var(--radius-md) var(--radius-md) 0;">
            <div style="font-weight: 700; font-size: var(--font-size-sm); color: var(--color-primary);">
              <?= e($settings['pickup_location'] ?? 'Counter Resmi CampusMart, Gedung Rektorat Lt. 1') ?>
            </div>
            <div style="font-size: var(--font-size-xs); color: var(--color-text-main); margin-top: 4px;">
              Jam Operasional: <?= e($settings['pickup_hours'] ?? 'Senin - Jumat: 08.00 - 16.00 WIB') ?>
            </div>
            <div style="font-size: var(--font-size-xs); color: var(--color-text-muted); margin-top: 6px;">
              Tidak ada biaya ekspedisi/ongkos kirim (Rp 0). Tunjukkan kode pesanan saat pesanan siap diambil.
            </div>
          </div>
        </div>

        <!-- Card 3: Pilihan Metode Pembayaran (matching Frame 9) -->
        <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-5); box-shadow: var(--shadow-sm);">
          <h2 style="font-size: var(--font-size-base); font-weight: 800; margin-bottom: var(--spacing-4); color: var(--color-text-main); display: flex; align-items: center; gap: 8px;">
            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--color-primary);"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
            3. Pilih Metode Pembayaran
          </h2>

          <?php if (!empty($errors['payment_method'])): ?>
            <div style="color: var(--color-danger); font-size: var(--font-size-xs); margin-bottom: var(--spacing-3);"><?= e($errors['payment_method']) ?></div>
          <?php endif; ?>

          <div style="display: flex; flex-direction: column; gap: var(--spacing-3);">
            <!-- Option 1: QRIS -->
            <label style="border: 2px solid <?= ($old['payment_method'] ?? 'qris') === 'qris' ? 'var(--color-primary)' : 'var(--color-border)' ?>; border-radius: var(--radius-md); padding: var(--spacing-4); cursor: pointer; display: block; background: <?= ($old['payment_method'] ?? 'qris') === 'qris' ? 'var(--color-primary-soft)' : '#FFFFFF' ?>;" id="label-qris">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 12px;">
                  <input type="radio" name="payment_method" value="qris" <?= ($old['payment_method'] ?? 'qris') === 'qris' ? 'checked' : '' ?> onchange="togglePayment(this.value)" style="accent-color: var(--color-primary);">
                  <div>
                    <div style="font-weight: 800; font-size: var(--font-size-sm); color: var(--color-text-main);">
                      QRIS — Quick Response Code Indonesian Standard
                    </div>
                    <div style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
                      Bebas biaya admin &bull; Scan via BCA, Mandiri, BRI, GoPay, OVO, ShopeePay, DANA
                    </div>
                  </div>
                </div>
                <span class="badge badge-confirmed" style="font-size: 0.7rem; background: #DCFCE7; color: #166534;">Direkomendasikan</span>
              </div>

              <!-- QRIS Instructions Details -->
              <div id="qris-box" style="margin-top: var(--spacing-4); padding-top: var(--spacing-4); border-top: 1px dashed var(--color-border); <?= ($old['payment_method'] ?? 'qris') === 'qris' ? '' : 'display: none;' ?>">
                
                <div style="display: flex; flex-wrap: wrap; gap: var(--spacing-4); align-items: flex-start; margin-bottom: var(--spacing-4);">
                  <!-- QRIS Card Image -->
                  <div style="flex: 0 0 auto; width: 100%; max-width: 260px; margin: 0 auto; background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 12px; box-shadow: var(--shadow-sm); text-align: center;">
                    <div style="position: relative; overflow: hidden; border-radius: 8px; border: 1px solid #E2E8F0; background: #FFFFFF;">
                      <img src="<?= asset('assets/images/qris-campusmart.png') ?>" alt="QRIS CampusMart" style="width: 100%; height: auto; display: block; object-fit: contain;">
                    </div>
                    <div style="margin-top: 10px;">
                      <a href="<?= asset('assets/images/qris-campusmart.png') ?>" target="_blank" download="QRIS-CampusMart.png" class="btn btn-outline" style="font-size: 0.75rem; padding: 6px 12px; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 6px; text-decoration: none;" onclick="event.stopPropagation();">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        Unduh / Buka Gambar QRIS
                      </a>
                    </div>
                  </div>

                  <!-- QRIS Instructions & Details -->
                  <div style="flex: 1 1 280px; min-width: 250px;">
                    <div style="background: #F8FAFC; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-3); margin-bottom: var(--spacing-3);">
                      <div style="font-size: var(--font-size-xs); color: var(--color-text-muted); margin-bottom: 2px;">Penerima / Merchant Resmi:</div>
                      <div style="font-size: var(--font-size-sm); font-weight: 800; color: var(--color-text-main); margin-bottom: 4px;">
                        <?= e($settings['qris_merchant_name'] ?? 'campusmart horizon, Stationery') ?>
                      </div>
                      <div style="font-size: var(--font-size-xs); color: var(--color-text-muted); display: flex; align-items: center; gap: 6px;">
                        <span>NMID: <strong style="color: var(--color-text-main);"><?= e($settings['qris_nmid'] ?? 'ID1026610748760') ?></strong></span>
                        <span class="badge" style="background: #E2E8F0; color: #334155; font-size: 0.65rem; padding: 2px 6px;">A01</span>
                      </div>
                    </div>

                    <div style="font-size: var(--font-size-xs); color: var(--color-text-main); line-height: 1.6; margin-bottom: var(--spacing-3);">
                      <div style="font-weight: 700; margin-bottom: 4px; color: var(--color-primary);">Petunjuk Pembayaran:</div>
                      <ol style="margin: 0; padding-left: 18px; color: var(--color-text-muted); display: flex; flex-direction: column; gap: 4px;">
                        <li>Buka aplikasi m-Banking (BCA, Mandiri, BRI, BNI) atau E-Wallet (GoPay, OVO, Dana, ShopeePay, LinkAja).</li>
                        <li>Pindai (scan) kode QRIS di samping atau unduh gambar QRIS ke galeri HP Anda.</li>
                        <li>Pastikan nama merchant penerima tertera: <strong><?= e($settings['qris_merchant_name'] ?? 'campusmart horizon, Stationery') ?></strong>.</li>
                        <li>Masukkan nominal sesuai total tagihan pesanan (<strong><?= rupiah($total) ?></strong>).</li>
                        <li>Simpan bukti transfer/struk dan unggah melalui form di bawah ini.</li>
                      </ol>
                    </div>
                  </div>
                </div>

                <div class="form-group" style="margin-bottom: 0;">
                  <label for="payment_proof" class="form-label" style="font-size: var(--font-size-xs); font-weight: 700;">Unggah Bukti Transfer Sekarang (Opsional):</label>
                  <input type="file" name="payment_proof" id="payment_proof" class="form-control" accept="image/jpeg,image/png,image/webp" style="font-size: var(--font-size-xs);" onclick="event.stopPropagation();">
                  <div style="font-size: 0.7rem; color: var(--color-text-muted); margin-top: 4px;">
                    Format JPG, PNG, atau WebP (Maksimal 2MB). Jika Anda belum sempat membayar, bukti transfer dapat diunggah nanti melalui menu <strong>Pesanan Saya</strong>.
                  </div>
                </div>
              </div>
            </label>

            <!-- Option 2: COD -->
            <label style="border: 2px solid <?= ($old['payment_method'] ?? '') === 'cod' ? 'var(--color-primary)' : 'var(--color-border)' ?>; border-radius: var(--radius-md); padding: var(--spacing-4); cursor: pointer; display: block; background: <?= ($old['payment_method'] ?? '') === 'cod' ? 'var(--color-primary-soft)' : '#FFFFFF' ?>;" id="label-cod">
              <div style="display: flex; align-items: center; gap: 12px;">
                <input type="radio" name="payment_method" value="cod" <?= ($old['payment_method'] ?? '') === 'cod' ? 'checked' : '' ?> onchange="togglePayment(this.value)" style="accent-color: var(--color-primary);">
                <div>
                  <div style="font-weight: 800; font-size: var(--font-size-sm); color: var(--color-text-main);">
                    COD (Cash on Delivery / Bayar Tunai di Counter Kampus)
                  </div>
                  <div style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
                    Bayar langsung saat mengambil barang di Counter Gedung Rektorat Lt. 1.
                  </div>
                </div>
              </div>

              <!-- COD Notice -->
              <div id="cod-box" style="margin-top: var(--spacing-3); padding-top: var(--spacing-3); border-top: 1px dashed var(--color-border); <?= ($old['payment_method'] ?? '') === 'cod' ? '' : 'display: none;' ?>">
                <div style="font-size: var(--font-size-xs); color: var(--color-text-main); line-height: 1.5;">
                  &bull; Pesanan COD akan berstatus <strong>Belum Lunas (Unpaid)</strong> saat dibuat.<br>
                  &bull; Petugas counter akan mengonfirmasi pembayaran dan menyerahkan struk setelah uang tunai diterima.
                </div>
              </div>
            </label>
          </div>
        </div>
      </div>

      <!-- Right Column: Order Summary (matching Frame 10) -->
      <div>
        <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-5); box-shadow: var(--shadow-sm); position: sticky; top: 80px;">
          <h2 style="font-size: var(--font-size-base); font-weight: 800; margin-bottom: var(--spacing-4); color: var(--color-text-main);">
            Ringkasan Pesanan (<?= (int)$itemCount ?> Barang)
          </h2>

          <!-- Mini Item List -->
          <div style="display: flex; flex-direction: column; gap: 10px; max-height: 240px; overflow-y: auto; padding-right: 4px; margin-bottom: var(--spacing-4);">
            <?php foreach ($items as $item): ?>
              <div style="display: flex; justify-content: space-between; align-items: center; font-size: var(--font-size-xs); border-bottom: 1px solid var(--color-border); padding-bottom: 8px;">
                <div style="display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0;">
                  <div style="width: 36px; height: 36px; border-radius: var(--radius-sm); background: #F8FAFC; border: 1px solid var(--color-border); overflow: hidden; flex-shrink: 0; display: flex; align-items: center; justify-content: center;">
                    <?php if (!empty($item['image_path'])): ?>
                      <img src="<?= asset($item['image_path']) ?>" alt="<?= e($item['name']) ?>" style="width: 100%; height: 100%; object-fit: contain;">
                    <?php else: ?>
                      <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--color-text-muted);"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                    <?php endif; ?>
                  </div>
                  <div style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                    <div style="font-weight: 700; color: var(--color-text-main);"><?= e($item['name']) ?></div>
                    <div style="color: var(--color-text-muted); font-size: 0.7rem;"><?= (int)$item['quantity'] ?> &times; <?= rupiah($item['price']) ?></div>
                  </div>
                </div>
                <div style="font-weight: 700; color: var(--color-primary); margin-left: 8px; flex-shrink: 0;">
                  <?= rupiah($item['line_total']) ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <!-- Total Calculation -->
          <div style="display: flex; justify-content: space-between; font-size: var(--font-size-xs); margin-bottom: 6px;">
            <span style="color: var(--color-text-muted);">Subtotal Produk</span>
            <span style="font-weight: 600;"><?= rupiah($subtotal) ?></span>
          </div>

          <div style="display: flex; justify-content: space-between; font-size: var(--font-size-xs); margin-bottom: 12px;">
            <span style="color: var(--color-text-muted);">Biaya Pengiriman Kampus</span>
            <span style="font-weight: 700; color: var(--color-success);">Rp 0 (Counter Kampus)</span>
          </div>

          <div style="border-top: 2px dashed var(--color-border); padding-top: var(--spacing-3); margin-top: var(--spacing-3); display: flex; justify-content: space-between; align-items: baseline; margin-bottom: var(--spacing-5);">
            <span style="font-size: var(--font-size-base); font-weight: 800; color: var(--color-text-main);">Total Pembayaran</span>
            <span style="font-size: var(--font-size-xl); font-weight: 800; color: var(--color-primary);"><?= rupiah($total) ?></span>
          </div>

          <button type="submit" class="btn btn-primary btn-block" style="padding: 14px; font-weight: 800; font-size: var(--font-size-sm); text-align: center;" id="submit-btn">
            Konfirmasi Pesanan Sekarang
          </button>

          <div style="margin-top: var(--spacing-4); font-size: 0.7rem; color: var(--color-text-muted); text-align: center; line-height: 1.4;">
            Dengan mengonfirmasi pesanan, Anda menyetujui ketentuan pengambilan barang internal kampus di Counter CampusMart.
          </div>
        </div>
      </div>
    </div>
  </form>
</div>

<script>
function togglePayment(method) {
  const qrisBox = document.getElementById('qris-box');
  const codBox = document.getElementById('cod-box');
  const labelQris = document.getElementById('label-qris');
  const labelCod = document.getElementById('label-cod');

  if (method === 'qris') {
    qrisBox.style.display = 'block';
    codBox.style.display = 'none';
    labelQris.style.borderColor = 'var(--color-primary)';
    labelQris.style.backgroundColor = 'var(--color-primary-soft)';
    labelCod.style.borderColor = 'var(--color-border)';
    labelCod.style.backgroundColor = '#FFFFFF';
  } else {
    qrisBox.style.display = 'none';
    codBox.style.display = 'block';
    labelCod.style.borderColor = 'var(--color-primary)';
    labelCod.style.backgroundColor = 'var(--color-primary-soft)';
    labelQris.style.borderColor = 'var(--color-border)';
    labelQris.style.backgroundColor = '#FFFFFF';
  }
}

// Double submission prevention
document.getElementById('checkout-form').addEventListener('submit', function() {
  const btn = document.getElementById('submit-btn');
  btn.disabled = true;
  btn.innerText = 'Memproses Pesanan...';
});
</script>

<style>
@media (min-width: 820px) {
  .checkout-layout-grid {
    grid-template-columns: 1fr 360px !important;
  }
}
@media (max-width: 600px) {
  .contact-grid {
    grid-template-columns: 1fr !important;
  }
}
</style>
