<div class="container" style="max-width: 680px; margin-top: var(--spacing-6);">
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-8); box-shadow: var(--shadow-sm); text-align: center;">
    <img src="<?= asset('assets/images/logo.png') ?>" alt="CampusMart Logo" style="height: 54px; margin: 0 auto var(--spacing-4) auto; object-fit: contain;">
    
    <h1 style="font-size: var(--font-size-xl); font-weight: 800; color: var(--color-primary); margin-bottom: var(--spacing-3);">
      Tentang CampusMart
    </h1>

    <p style="color: var(--color-text-main); font-size: var(--font-size-sm); line-height: 1.6; margin-bottom: var(--spacing-6);">
      CampusMart adalah platform marketplace terpadu untuk civitas akademika <?= e($settings['campus_name'] ?? 'Horizon University Indonesia') ?>. Kami menyediakan berbagai kebutuhan mahasiswa mulai dari alat tulis, buku modul perkuliahan, hingga merchandise resmi kampus dengan harga terjangkau dan kualitas terjamin.
    </p>

    <div style="text-align: left; border-top: 1px solid var(--color-border); padding-top: var(--spacing-4);">
      <div style="display: flex; justify-content: space-between; padding: var(--spacing-2) 0; border-bottom: 1px solid var(--color-border); font-size: var(--font-size-sm);">
        <span style="color: var(--color-text-muted);">Versi Sistem</span>
        <span style="font-weight: 600;">1.0.0 (Production Ready)</span>
      </div>
      <div style="display: flex; justify-content: space-between; padding: var(--spacing-2) 0; border-bottom: 1px solid var(--color-border); font-size: var(--font-size-sm);">
        <span style="color: var(--color-text-muted);">Lokasi Pengambilan</span>
        <span style="font-weight: 600; text-align: right;"><?= e($settings['pickup_location'] ?? 'Gedung Rektorat Lt. 1') ?></span>
      </div>
      <div style="display: flex; justify-content: space-between; padding: var(--spacing-2) 0; border-bottom: 1px solid var(--color-border); font-size: var(--font-size-sm);">
        <span style="color: var(--color-text-muted);">Jam Operasional</span>
        <span style="font-weight: 600;"><?= e($settings['pickup_hours'] ?? 'Senin - Jumat: 08.00 - 16.00 WIB') ?></span>
      </div>
      <div style="display: flex; justify-content: space-between; padding: var(--spacing-2) 0; font-size: var(--font-size-sm);">
        <span style="color: var(--color-text-muted);">Kontak Helpdesk</span>
        <span style="font-weight: 600;"><?= e($settings['contact_admin'] ?? '0812-3456-7890') ?></span>
      </div>
    </div>
  </div>
</div>
