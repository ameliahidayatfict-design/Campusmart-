<div class="container">
  <!-- Promo / Hero Banner (matching Frame 1 & Frame 4) -->
  <section class="promo-card">
    <div class="promo-content">
      <h1 class="promo-title">Semua kebutuhan kuliah<br>Ada di CampusMart</h1>
      <p class="promo-subtitle">Belanja kebutuhan kuliah jadi lebih mudah, cepat, dan terpercaya untuk seluruh sivitas kampus.</p>
      <a href="/products" class="btn btn-secondary" style="border-radius: var(--radius-full); font-weight: 700; color: var(--color-primary); border: none;">
        Belanja Sekarang &rarr;
      </a>
    </div>
  </section>

  <!-- Kategori Cepat (matching Frame 4) -->
  <section style="margin-bottom: var(--spacing-6);">
    <div class="section-header">
      <h2 class="section-title">Kategori Pilihan</h2>
      <a href="/categories" class="section-link">Lihat Semua</a>
    </div>
    <div class="category-scroll">
      <a href="/products" class="category-chip <?= empty($selectedCategory) ? 'active' : '' ?>">
        <span>Semua Produk</span>
      </a>
      <?php if (!empty($categories)): ?>
        <?php foreach ($categories as $cat): ?>
          <a href="/products?category=<?= e($cat['slug']) ?>" class="category-chip <?= ($selectedCategory ?? '') === $cat['slug'] ? 'active' : '' ?>">
            <span><?= e($cat['name']) ?></span>
          </a>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </section>

  <!-- Produk Terbaru (matching Frame 4) -->
  <section style="margin-bottom: var(--spacing-8);">
    <div class="section-header">
      <h2 class="section-title">Produk Terbaru</h2>
      <a href="/products" class="section-link">Lihat Semua</a>
    </div>

    <?php if (!empty($products)): ?>
      <div class="product-grid">
        <?php foreach ($products as $prod): ?>
          <a href="/products/<?= e($prod['slug']) ?>" class="product-card">
            <div class="product-img-wrap">
              <?php if (!empty($prod['image_path'])): ?>
                <img src="<?= asset($prod['image_path']) ?>" alt="<?= e($prod['name']) ?>" class="product-img" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'120\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23800020\' stroke-width=\'1\'><rect x=\'3\' y=\'3\' width=\'18\' height=\'18\' rx=\'2\'/><circle cx=\'8.5\' cy=\'8.5\' r=\'1.5\'/><path d=\'M21 15l-5-5L5 21\'/></svg>'">
              <?php else: ?>
                <div style="color: var(--color-text-muted); font-size: 0.75rem;">Foto Produk</div>
              <?php endif; ?>
            </div>
            <div class="product-body">
              <span class="product-cat"><?= e($prod['category_name'] ?? 'Katalog') ?></span>
              <h3 class="product-title"><?= e($prod['name']) ?></h3>
              <div class="product-price-row">
                <span class="product-price"><?= rupiah($prod['price']) ?></span>
                <span class="product-stock">Stok: <?= (int)$prod['stock'] ?></span>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div style="background: #fff; padding: 3rem; text-align: center; border-radius: var(--radius-md); border: 1px solid var(--color-border);">
        <p style="color: var(--color-text-muted);">Belum ada produk yang tersedia saat ini.</p>
      </div>
    <?php endif; ?>
  </section>
</div>
