<div class="container" style="max-width: 800px; margin-top: var(--spacing-6);">
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-6); box-shadow: var(--shadow-sm); margin-bottom: var(--spacing-6);">
    <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--color-border); padding-bottom: var(--spacing-4); margin-bottom: var(--spacing-6); flex-wrap: wrap; gap: var(--spacing-3);">
      <div style="display: flex; align-items: center; gap: 14px;">
        <div style="width: 56px; height: 56px; border-radius: var(--radius-full); background: var(--color-primary-soft); color: var(--color-primary); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: 800;">
          <?= strtoupper(substr($user['name'], 0, 1)) ?>
        </div>
        <div>
          <h1 style="font-size: var(--font-size-xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 2px;">
            <?= e($user['name']) ?>
          </h1>
          <div style="display: flex; align-items: center; gap: 8px; font-size: var(--font-size-xs); color: var(--color-text-muted);">
            <span><?= e($user['email']) ?></span> &bull;
            <span class="badge" style="background: var(--color-primary-soft); color: var(--color-primary); font-size: 0.7rem; text-transform: uppercase;">
              <?= e($user['role']) ?>
            </span>
          </div>
        </div>
      </div>

      <!-- Logout Form via POST + CSRF -->
      <form action="/logout" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin keluar dari akun?');">
        <?= csrf_field() ?>
        <button type="submit" class="btn btn-danger btn-sm" style="display: flex; align-items: center; gap: 6px;">
          <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
          <span>Keluar</span>
        </button>
      </form>
    </div>

    <!-- Update Profile Form -->
    <h2 style="font-size: var(--font-size-base); font-weight: 700; margin-bottom: var(--spacing-4);">Informasi Akun</h2>

    <form action="/profile" method="POST">
      <?= csrf_field() ?>

      <div style="display: grid; grid-template-columns: 1fr; gap: var(--spacing-4);">
        <div class="form-group">
          <label for="name" class="form-label">Nama Lengkap *</label>
          <input type="text" id="name" name="name" class="form-control" value="<?= e($user['name']) ?>" required>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--spacing-3);" class="profile-grid">
          <div class="form-group">
            <label for="email" class="form-label">Alamat Email (Tidak dapat diubah)</label>
            <input type="email" id="email" class="form-control" value="<?= e($user['email']) ?>" disabled style="background: #F1F5F9; cursor: not-allowed;">
          </div>

          <div class="form-group">
            <label for="student_id" class="form-label">NIM (Nomor Induk Mahasiswa)</label>
            <input type="text" id="student_id" name="student_id" class="form-control" value="<?= e($user['student_id'] ?? '') ?>" placeholder="2024001">
          </div>
        </div>

        <div class="form-group">
          <label for="phone" class="form-label">Nomor WhatsApp / HP</label>
          <input type="tel" id="phone" name="phone" class="form-control" value="<?= e($user['phone'] ?? '') ?>" placeholder="081234567890">
        </div>

        <!-- Optional Change Password -->
        <div style="background: #F8FAFC; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); margin-top: var(--spacing-2);">
          <h3 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3);">Ganti Password (Kosongkan jika tidak ingin mengubah)</h3>
          
          <div class="form-group">
            <label for="current_password" class="form-label">Password Saat Ini</label>
            <input type="password" id="current_password" name="current_password" class="form-control" placeholder="Masukkan password saat ini">
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--spacing-3);" class="profile-grid">
            <div class="form-group">
              <label for="new_password" class="form-label">Password Baru</label>
              <input type="password" id="new_password" name="new_password" class="form-control" placeholder="Minimal 6 karakter">
            </div>

            <div class="form-group">
              <label for="new_password_confirmation" class="form-label">Ulangi Password Baru</label>
              <input type="password" id="new_password_confirmation" name="new_password_confirmation" class="form-control" placeholder="Konfirmasi password baru">
            </div>
          </div>
        </div>

        <div style="display: flex; justify-content: flex-end; margin-top: var(--spacing-4);">
          <button type="submit" class="btn btn-primary">Simpan Perubahan Profil</button>
        </div>
      </div>
    </form>
  </div>

  <style>
    @media (max-width: 640px) {
      .profile-grid {
        grid-template-columns: 1fr !important;
      }
    }
  </style>

  <!-- Quick Links to Orders -->
  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-6); box-shadow: var(--shadow-sm); margin-bottom: var(--spacing-8);">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-4);">
      <h2 style="font-size: var(--font-size-base); font-weight: 700;">Pesanan Saya Terbaru</h2>
      <a href="/orders" style="font-size: var(--font-size-xs); color: var(--color-primary); font-weight: 600;">Lihat Semua Pesanan &rarr;</a>
    </div>

    <?php if (!empty($orders)): ?>
      <div style="display: flex; flex-direction: column; gap: var(--spacing-3);">
        <?php foreach ($orders as $ord): ?>
          <a href="/orders/<?= e($ord['order_code']) ?>" style="display: flex; justify-content: space-between; align-items: center; padding: var(--spacing-3) var(--spacing-4); border: 1px solid var(--color-border); border-radius: var(--radius-md); transition: var(--transition);" onmouseover="this.style.borderColor='var(--color-primary)'" onmouseout="this.style.borderColor='var(--color-border)'">
            <div>
              <div style="font-weight: 700; font-size: var(--font-size-sm); color: var(--color-text-main);">#<?= e($ord['order_code']) ?></div>
              <div style="font-size: 0.75rem; color: var(--color-text-muted);"><?= date('d M Y, H:i', strtotime($ord['created_at'])) ?> &bull; <?= e(strtoupper($ord['payment_method'])) ?></div>
            </div>
            <div style="text-align: right;">
              <span class="badge badge-<?= e($ord['status']) ?>" style="font-size: 0.7rem;"><?= e(str_replace('_', ' ', $ord['status'])) ?></span>
              <div style="font-weight: 700; color: var(--color-primary); font-size: var(--font-size-sm); margin-top: 2px;"><?= rupiah($ord['total']) ?></div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p style="color: var(--color-text-muted); font-size: var(--font-size-sm); text-align: center; padding: 1.5rem 0;">Belum ada riwayat pesanan.</p>
    <?php endif; ?>
  </div>
</div>
