<?php
$fSuccess = has_flash('success') ? flash('success') : null;
$fError   = has_flash('error') ? flash('error') : null;
$fWarning = has_flash('warning') ? flash('warning') : null;
$fInfo    = has_flash('info') ? flash('info') : null;
?>

<?php if ($fSuccess): ?>
  <div class="alert alert-success alert-auto-dismiss" role="alert" data-flash="success" data-message="<?= e($fSuccess) ?>" style="display: none;">
    <div style="display: flex; align-items: center; gap: 8px;">
      <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
      <span><?= e($fSuccess) ?></span>
    </div>
  </div>
<?php endif; ?>

<?php if ($fError): ?>
  <div class="alert alert-danger alert-auto-dismiss" role="alert" data-flash="error" data-message="<?= e($fError) ?>" style="display: none;">
    <div style="display: flex; align-items: center; gap: 8px;">
      <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
      <span><?= e($fError) ?></span>
    </div>
  </div>
<?php endif; ?>

<?php if ($fWarning): ?>
  <div class="alert alert-warning alert-auto-dismiss" role="alert" data-flash="warning" data-message="<?= e($fWarning) ?>" style="display: none;">
    <div style="display: flex; align-items: center; gap: 8px;">
      <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
      <span><?= e($fWarning) ?></span>
    </div>
  </div>
<?php endif; ?>

<?php if ($fInfo): ?>
  <div class="alert alert-info alert-auto-dismiss" role="alert" data-flash="info" data-message="<?= e($fInfo) ?>" style="display: none;">
    <div style="display: flex; align-items: center; gap: 8px;">
      <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
      <span><?= e($fInfo) ?></span>
    </div>
  </div>
<?php endif; ?>

<noscript>
  <style>
    .alert-auto-dismiss { display: block !important; }
  </style>
</noscript>
