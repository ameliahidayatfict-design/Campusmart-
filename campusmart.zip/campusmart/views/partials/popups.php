<!-- CAMPUSMART — Global Animated Popups & Toast Notifications (Alpine.js) -->
<div x-data="popupNotifications" class="cm-toast-container" aria-live="polite">
  <template x-for="item in notifications" :key="item.id">
    <div 
      x-show="item.visible"
      x-transition:enter="cm-popup-enter"
      x-transition:enter-start="cm-popup-enter-start"
      x-transition:enter-end="cm-popup-enter-end"
      x-transition:leave="cm-popup-leave"
      x-transition:leave-start="cm-popup-leave-start"
      x-transition:leave-end="cm-popup-leave-end"
      :class="'cm-toast cm-toast-' + item.type"
      role="alert"
    >
      <!-- Icon Indicator -->
      <div class="cm-toast-icon">
        <template x-if="item.type === 'success'">
          <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
        </template>
        <template x-if="item.type === 'error'">
          <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
        </template>
        <template x-if="item.type === 'warning'">
          <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
        </template>
        <template x-if="item.type === 'info'">
          <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
        </template>
      </div>

      <!-- Content -->
      <div class="cm-toast-body">
        <h4 class="cm-toast-title" x-text="item.title || 'Pemberitahuan'"></h4>
        <p class="cm-toast-message" x-text="item.message"></p>
      </div>

      <!-- Close Button -->
      <button type="button" @click="remove(item.id)" class="cm-toast-close" aria-label="Tutup">
        &times;
      </button>
    </div>
  </template>
</div>


