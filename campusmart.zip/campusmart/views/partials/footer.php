<footer class="site-footer">
  <div class="container">
    <p>&copy; <?= date('Y') ?> <strong>CAMPUSMART</strong> — Marketplace Kebutuhan Mahasiswa Lingkungan Internal Kampus.</p>
    <p style="margin-top: 4px; color: var(--color-text-light);">Horizon University Indonesia &bull; Belanja kebutuhan kuliah jadi lebih mudah, cepat, dan terpercaya.</p>
  </div>
</footer>
