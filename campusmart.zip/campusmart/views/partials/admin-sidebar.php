<?php
$currentUri = $_SERVER['REQUEST_URI'] ?? '/admin';
?>
<aside class="admin-sidebar" id="adminSidebar">
  <div class="sidebar-header" style="justify-content: space-between;">
    <a href="/admin" class="brand-link" style="gap: var(--spacing-2);">
      <img src="<?= asset('assets/images/logo.png') ?>" alt="CampusMart Admin" class="brand-logo" style="height: 30px;">
      <span class="badge badge-primary" style="font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; padding: 2px 6px; border-radius: var(--radius-sm);">Admin</span>
    </a>
    <button type="button" class="admin-sidebar-close" id="adminSidebarClose" aria-label="Tutup Menu">
      <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
    </button>
  </div>

  <ul class="sidebar-menu">
    <li class="sidebar-item <?= $currentUri === '/admin' ? 'active' : '' ?>">
      <a href="/admin">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
        <span>Dashboard</span>
      </a>
    </li>

    <li class="sidebar-item <?= str_starts_with($currentUri, '/admin/products') ? 'active' : '' ?>">
      <a href="/admin/products">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
        <span>Kelola Produk</span>
      </a>
    </li>

    <li class="sidebar-item <?= str_starts_with($currentUri, '/admin/categories') ? 'active' : '' ?>">
      <a href="/admin/categories">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"/></svg>
        <span>Kelola Kategori</span>
      </a>
    </li>

    <li class="sidebar-item <?= str_starts_with($currentUri, '/admin/orders') ? 'active' : '' ?>">
      <a href="/admin/orders">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
        <span>Kelola Pesanan</span>
      </a>
    </li>

    <li class="sidebar-item <?= str_starts_with($currentUri, '/admin/users') ? 'active' : '' ?>">
      <a href="/admin/users">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
        <span>Kelola Pengguna</span>
      </a>
    </li>

    <li class="sidebar-item <?= str_starts_with($currentUri, '/admin/reports') ? 'active' : '' ?>">
      <a href="/admin/reports">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
        <span>Laporan Penjualan</span>
      </a>
    </li>

    <li class="sidebar-item" style="margin-top: auto;">
      <a href="/" target="_blank">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
        <span>Lihat Toko Publik</span>
      </a>
    </li>
    <li class="sidebar-item">
      <a href="/logout" style="color: var(--color-danger);">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
        <span>Keluar (Logout)</span>
      </a>
    </li>
  </ul>
</aside>
