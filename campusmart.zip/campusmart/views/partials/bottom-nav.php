<?php
$currentUri = $_SERVER['REQUEST_URI'] ?? '/';
$user = auth_user();
?>
<nav class="bottom-nav" aria-label="Mobile Navigation">
  <!-- Beranda -->
  <a href="/" class="bottom-nav-item <?= $currentUri === '/' ? 'active' : '' ?>">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
    </svg>
    <span>Beranda</span>
  </a>

  <!-- Kategori -->
  <a href="/categories" class="bottom-nav-item <?= str_starts_with($currentUri, '/categories') ? 'active' : '' ?>">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
    </svg>
    <span>Kategori</span>
  </a>

  <!-- Keranjang -->
  <?php
    $bottomCartCount = $user ? \App\Models\Cart::countItems((int)$user['id']) : 0;
  ?>
  <a href="/cart" class="bottom-nav-item <?= str_starts_with($currentUri, '/cart') ? 'active' : '' ?>" x-data="cartBadge(<?= (int)$bottomCartCount ?>)" style="position: relative;">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>
    </svg>
    <span 
      class="cart-badge" 
      :class="{ 'badge-pop-animate': popping }" 
      x-show="count > 0" 
      x-text="count" 
      style="top: 2px; right: 22px; position: absolute; font-size: 0.65rem; min-width: 16px; height: 16px; <?= $bottomCartCount > 0 ? '' : 'display: none;' ?>"
    ><?= $bottomCartCount ?></span>
    <span>Keranjang</span>
  </a>

  <!-- Pesanan -->
  <a href="/orders" class="bottom-nav-item <?= str_starts_with($currentUri, '/orders') ? 'active' : '' ?>">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/>
    </svg>
    <span>Pesanan</span>
  </a>

  <!-- Akun -->
  <a href="<?= $user ? '/profile' : '/login' ?>" class="bottom-nav-item <?= in_array($currentUri, ['/profile', '/login', '/register']) ? 'active' : '' ?>">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
    </svg>
    <span>Akun</span>
  </a>
</nav>
