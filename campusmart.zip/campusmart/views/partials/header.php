<?php
$user = auth_user();
$currentUri = $_SERVER['REQUEST_URI'] ?? '/';
?>
<header class="site-header">
  <div class="container header-container">
    <!-- Brand Logo -->
    <a href="/" class="brand-link" title="CampusMart - Belanja Kebutuhan Kampus" aria-label="CampusMart Beranda">
      <span class="brand-badge">
        <img src="<?= asset('assets/images/logo.png') ?>" alt="CampusMart" class="brand-logo">
      </span>
    </a>

    <!-- Desktop Navigation -->
    <nav class="desktop-nav" aria-label="Main Navigation">
      <a href="/" class="nav-link <?= $currentUri === '/' ? 'active' : '' ?>">Beranda</a>
      <a href="/products" class="nav-link <?= str_starts_with($currentUri, '/products') ? 'active' : '' ?>">Katalog</a>
      <a href="/categories" class="nav-link <?= str_starts_with($currentUri, '/categories') ? 'active' : '' ?>">Kategori</a>
      <a href="/about" class="nav-link <?= $currentUri === '/about' ? 'active' : '' ?>">Tentang</a>
    </nav>

    <!-- Header Search Bar -->
    <div class="header-search">
      <form action="/products" method="GET" class="search-form">
        <span class="search-icon">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
          </svg>
        </span>
        <input type="text" name="q" class="search-input" placeholder="Cari produk..." value="<?= e($_GET['q'] ?? '') ?>" aria-label="Cari produk">
      </form>
    </div>

    <!-- Header Actions (Cart & User) -->
    <div class="header-actions">
      <!-- Keranjang Belanja with Alpine.js Live Counter -->
      <?php
        $cartCount = 0;
        if ($user) {
            $cartCount = \App\Models\Cart::countItems((int)$user['id']);
        }
      ?>
      <div x-data="cartBadge(<?= (int)$cartCount ?>)" style="display: inline-flex; position: relative;">
        <a href="/cart" class="icon-btn" title="Keranjang Belanja" aria-label="Keranjang Belanja">
          <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>
          </svg>
          <span 
            class="cart-badge" 
            :class="{ 'badge-pop-animate': popping }" 
            x-show="count > 0" 
            x-text="count"
            <?= $cartCount > 0 ? '' : 'style="display: none;"' ?>
          ><?= $cartCount ?></span>
        </a>
      </div>

      <!-- User Profile / Auth Links -->
      <?php if ($user): ?>
        <?php if ($user['role'] === 'admin'): ?>
          <a href="/admin" class="btn btn-sm btn-secondary hide-mobile" style="border-radius: var(--radius-full); font-size: 0.75rem;">
            Admin Panel
          </a>
        <?php endif; ?>
        <a href="/profile" class="icon-btn" title="Profil Akun (<?= e($user['name']) ?>)" aria-label="Profil Akun">
          <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
          </svg>
        </a>
      <?php else: ?>
        <a href="/login" class="btn btn-sm" style="background: rgba(255,255,255,0.2); color: #fff; border-radius: var(--radius-full);">
          Masuk
        </a>
      <?php endif; ?>
    </div>
  </div>
</header>
