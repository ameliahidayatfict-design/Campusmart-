<div style="text-align: center; margin-bottom: var(--spacing-6);">
  <h1 style="font-size: var(--font-size-xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 4px;">
    Selamat Datang di <span style="color: var(--color-primary);">CampusMart</span>
  </h1>
  <p style="font-size: var(--font-size-sm); color: var(--color-text-muted);">
    Masuk untuk melanjutkan belanja kebutuhan kampus
  </p>
</div>

<form action="/login" method="POST">
  <?= csrf_field() ?>

  <div class="form-group">
    <label for="email" class="form-label">Email Kampus / Akun</label>
    <div style="position: relative;">
      <input type="email" id="email" name="email" class="form-control" placeholder="Masukkan email (contoh: dina@gmail.com)" required autofocus>
    </div>
  </div>

  <div class="form-group">
    <label for="password" class="form-label">Password</label>
    <div style="position: relative; display: flex; align-items: center;">
      <input type="password" id="password" name="password" class="form-control" placeholder="Masukkan password" required style="padding-right: 42px;">
      <button type="button" data-toggle="password" data-target="password" style="position: absolute; right: 10px; background: transparent; border: none; cursor: pointer; color: var(--color-text-muted); display: flex; align-items: center;" title="Lihat password">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
      </button>
    </div>
  </div>

  <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: var(--spacing-6); font-size: var(--font-size-xs);">
    <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; color: var(--color-text-main);">
      <input type="checkbox" name="remember" value="1">
      <span>Ingat saya</span>
    </label>
  </div>

  <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-bottom: var(--spacing-4);">
    Masuk
  </button>

  <div style="text-align: center; font-size: var(--font-size-sm); color: var(--color-text-muted);">
    Belum punya Akun? <a href="/register" style="color: var(--color-primary); font-weight: 700;">Daftar di sini</a>
  </div>
</form>
