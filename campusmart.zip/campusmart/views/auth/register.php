<div style="text-align: center; margin-bottom: var(--spacing-6);">
  <h1 style="font-size: var(--font-size-xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 4px;">
    Daftar Akun Mahasiswa
  </h1>
  <p style="font-size: var(--font-size-sm); color: var(--color-text-muted);">
    Buat Akun baru untuk mulai berbelanja di CampusMart
  </p>

  <div style="margin-top: var(--spacing-3);">
    <span class="badge" style="background: var(--color-primary-soft); color: var(--color-primary); font-size: 0.75rem; padding: 4px 14px; font-weight: 700;">
      Akun Mahasiswa Kampus
    </span>
  </div>
</div>

<form action="/register" method="POST">
  <?= csrf_field() ?>

  <div class="form-group">
    <label for="name" class="form-label">Nama Lengkap *</label>
    <input type="text" id="name" name="name" class="form-control" placeholder="Masukkan nama lengkap" required autofocus>
  </div>

  <div class="form-group">
    <label for="email" class="form-label">Email Kampus / Pribadi *</label>
    <input type="email" id="email" name="email" class="form-control" placeholder="Masukkan email aktif" required>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--spacing-3);">
    <div class="form-group">
      <label for="student_id" class="form-label">NIM (Nomor Induk)</label>
      <input type="text" id="student_id" name="student_id" class="form-control" placeholder="Contoh: 2024001">
    </div>

    <div class="form-group">
      <label for="phone" class="form-label">Nomor WhatsApp / HP</label>
      <input type="tel" id="phone" name="phone" class="form-control" placeholder="081234567890">
    </div>
  </div>

  <div class="form-group">
    <label for="password" class="form-label">Password *</label>
    <div style="position: relative; display: flex; align-items: center;">
      <input type="password" id="password" name="password" class="form-control" placeholder="Minimal 6 karakter" required style="padding-right: 42px;">
      <button type="button" data-toggle="password" data-target="password" style="position: absolute; right: 10px; background: transparent; border: none; cursor: pointer; color: var(--color-text-muted); display: flex; align-items: center;" title="Lihat password">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
      </button>
    </div>
  </div>

  <div class="form-group">
    <label for="password_confirmation" class="form-label">Konfirmasi Password *</label>
    <div style="position: relative; display: flex; align-items: center;">
      <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" placeholder="Ulangi password" required style="padding-right: 42px;">
      <button type="button" data-toggle="password" data-target="password_confirmation" style="position: absolute; right: 10px; background: transparent; border: none; cursor: pointer; color: var(--color-text-muted); display: flex; align-items: center;" title="Lihat konfirmasi password">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
      </button>
    </div>
  </div>

  <div style="margin-bottom: var(--spacing-6); font-size: var(--font-size-xs);">
    <label style="display: flex; align-items: flex-start; gap: 8px; cursor: pointer; color: var(--color-text-main); line-height: 1.4;">
      <input type="checkbox" name="terms" value="1" required style="margin-top: 2px;">
      <span>Saya setuju dengan <strong style="color: var(--color-primary);">Syarat & Ketentuan</strong> yang berlaku di CampusMart.</span>
    </label>
  </div>

  <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-bottom: var(--spacing-4);">
    Daftar &rarr;
  </button>

  <div style="text-align: center; font-size: var(--font-size-sm); color: var(--color-text-muted);">
    Sudah punya akun? <a href="/login" style="color: var(--color-primary); font-weight: 700;">Masuk sekarang</a>
  </div>
</form>
