<div class="container" style="max-width: 760px; margin-top: var(--spacing-4);">
  <!-- Back Button -->
  <div style="margin-bottom: var(--spacing-4);">
    <a href="/orders" class="btn btn-secondary btn-sm">&larr; Kembali ke Riwayat Pesanan</a>
  </div>

  <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-6); box-shadow: var(--shadow-sm); margin-bottom: var(--spacing-6);">
    <!-- Header Order Details -->
    <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid var(--color-border); padding-bottom: var(--spacing-4); margin-bottom: var(--spacing-5); flex-wrap: wrap; gap: 8px;">
      <div>
        <h1 style="font-size: var(--font-size-xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 2px;">
          #<?= e($order['order_code']) ?>
        </h1>
        <div style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
          Dipesan pada: <?= date('d F Y, H:i', strtotime($order['created_at'])) ?> WIB
        </div>
      </div>

      <div style="text-align: right;">
        <span class="badge badge-<?= e($order['status']) ?>" style="font-size: 0.8rem; padding: 4px 12px;">
          <?= e(str_replace('_', ' ', $order['status'])) ?>
        </span>
        <div style="margin-top: 4px;">
          <span class="badge badge-<?= e($order['payment_status']) ?>" style="font-size: 0.7rem;">
            Pembayaran: <?= e(str_replace('_', ' ', $order['payment_status'])) ?>
          </span>
        </div>
      </div>
    </div>

    <!-- Status Message Banner (matching Frame 11) -->
    <div style="background: var(--color-primary-soft); border-left: 4px solid var(--color-primary); padding: var(--spacing-3) var(--spacing-4); border-radius: 0 var(--radius-md) var(--radius-md) 0; margin-bottom: var(--spacing-6);">
      <div style="font-weight: 700; font-size: var(--font-size-sm); color: var(--color-primary);">Status Pesanan Saat Ini:</div>
      <div style="font-size: var(--font-size-xs); color: var(--color-text-main); margin-top: 2px;">
        <?php if ($order['status'] === 'pending'): ?>
          Pesanan baru telah dibuat dan sedang menunggu konfirmasi admin.
        <?php elseif ($order['status'] === 'confirmed'): ?>
          Pesanan telah dikonfirmasi dan antrean penyiapan barang telah dibuat.
        <?php elseif ($order['status'] === 'processing'): ?>
          Pesanan sedang disiapkan di counter CampusMart kampus.
        <?php elseif ($order['status'] === 'ready_for_pickup'): ?>
          Barang sudah siap diambil! Silakan datang ke Counter CampusMart (Gedung Rektorat Lt. 1).
        <?php elseif ($order['status'] === 'completed'): ?>
          Transaksi selesai. Barang telah diserah-terimakan dengan baik.
        <?php elseif ($order['status'] === 'cancelled'): ?>
          Pesanan ini telah dibatalkan.
        <?php endif; ?>
      </div>
    </div>

    <!-- Product Items Snapshot (matching Frame 11) -->
    <h2 style="font-size: var(--font-size-base); font-weight: 700; margin-bottom: var(--spacing-4);">Daftar Produk</h2>
    <div style="display: flex; flex-direction: column; gap: var(--spacing-3); margin-bottom: var(--spacing-6);">
      <?php foreach ($items as $item): ?>
        <div style="display: flex; align-items: center; justify-content: space-between; padding: var(--spacing-3); border: 1px solid var(--color-border); border-radius: var(--radius-md); background: #F8FAFC;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="width: 48px; height: 48px; border-radius: var(--radius-sm); background: #FFFFFF; border: 1px solid var(--color-border); overflow: hidden; display: flex; align-items: center; justify-content: center;">
              <?php if (!empty($item['image_path'])): ?>
                <img src="<?= asset($item['image_path']) ?>" alt="<?= e($item['product_name']) ?>" style="width: 100%; height: 100%; object-fit: contain;">
              <?php else: ?>
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--color-text-muted);"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
              <?php endif; ?>
            </div>
            <div>
              <div style="font-weight: 700; font-size: var(--font-size-sm); color: var(--color-text-main);">
                <?= e($item['product_name']) ?>
              </div>
              <div style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
                <?= rupiah($item['unit_price']) ?> &times; <?= (int)$item['quantity'] ?>
              </div>
            </div>
          </div>
          <div style="font-weight: 700; font-size: var(--font-size-sm); color: var(--color-primary);">
            <?= rupiah($item['line_total']) ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Ringkasan Pembayaran (matching Frame 11) -->
    <div style="background: #F8FAFC; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-4); margin-bottom: var(--spacing-6);">
      <h2 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3);">Ringkasan Pembayaran</h2>
      
      <div style="display: flex; justify-content: space-between; font-size: var(--font-size-xs); padding: 4px 0;">
        <span style="color: var(--color-text-muted);">Metode Pembayaran</span>
        <span style="font-weight: 700; text-transform: uppercase;"><?= e($order['payment_method']) ?></span>
      </div>

      <div style="display: flex; justify-content: space-between; font-size: var(--font-size-xs); padding: 4px 0;">
        <span style="color: var(--color-text-muted);">Status Pembayaran</span>
        <span>
          <span class="badge badge-<?= e($order['payment_status']) ?>">
            <?= e(str_replace('_', ' ', $order['payment_status'])) ?>
          </span>
        </span>
      </div>

      <div style="display: flex; justify-content: space-between; font-size: var(--font-size-xs); padding: 4px 0;">
        <span style="color: var(--color-text-muted);">Subtotal Produk</span>
        <span><?= rupiah($order['subtotal']) ?></span>
      </div>

      <div style="display: flex; justify-content: space-between; font-size: var(--font-size-xs); padding: 4px 0;">
        <span style="color: var(--color-text-muted);">Pengiriman Kampus</span>
        <span style="font-weight: 600; color: var(--color-success);">Rp 0 (Ambil di Counter Kampus)</span>
      </div>

      <div style="display: flex; justify-content: space-between; font-size: var(--font-size-base); font-weight: 800; border-top: 1px solid var(--color-border); padding-top: var(--spacing-2); margin-top: var(--spacing-2);">
        <span>Total Pembayaran</span>
        <span style="color: var(--color-primary);"><?= rupiah($order['total']) ?></span>
      </div>
    </div>

    <!-- QRIS Payment Box and Proof Upload (Tahap 10C) -->
    <?php if ($order['payment_method'] === 'qris'): ?>
      <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-5); margin-bottom: var(--spacing-6); box-shadow: var(--shadow-sm);">
        <h2 style="font-size: var(--font-size-sm); font-weight: 700; color: var(--color-primary); margin-bottom: var(--spacing-3); display: flex; align-items: center; gap: 6px;">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/></svg>
          Instruksi Pembayaran QRIS Resmi
        </h2>

        <div style="display: flex; flex-wrap: wrap; gap: var(--spacing-4); align-items: flex-start; margin-bottom: var(--spacing-4);">
          <!-- QRIS Card Image -->
          <div style="flex: 0 0 auto; width: 100%; max-width: 220px; margin: 0 auto; background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 10px; box-shadow: var(--shadow-sm); text-align: center;">
            <div style="position: relative; overflow: hidden; border-radius: 8px; border: 1px solid #E2E8F0; background: #FFFFFF;">
              <img src="<?= asset('assets/images/qris-campusmart.png') ?>" alt="QRIS CampusMart" style="width: 100%; height: auto; display: block; object-fit: contain;">
            </div>
            <div style="margin-top: 8px;">
              <a href="<?= asset('assets/images/qris-campusmart.png') ?>" target="_blank" download="QRIS-CampusMart.png" class="btn btn-outline" style="font-size: 0.75rem; padding: 5px 10px; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 6px; text-decoration: none;">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                Unduh / Buka QRIS
              </a>
            </div>
          </div>

          <!-- Merchant & Instructions -->
          <div style="flex: 1 1 280px; min-width: 250px;">
            <div style="background: #F8FAFC; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--spacing-3); margin-bottom: var(--spacing-3);">
              <div style="font-size: var(--font-size-xs); color: var(--color-text-muted); margin-bottom: 2px;">Penerima / Merchant Resmi:</div>
              <div style="font-size: var(--font-size-sm); font-weight: 800; color: var(--color-text-main); margin-bottom: 4px;">
                <?= e($settings['qris_merchant_name'] ?? 'campusmart horizon, Stationery') ?>
              </div>
              <div style="font-size: var(--font-size-xs); color: var(--color-text-muted); display: flex; align-items: center; gap: 6px;">
                <span>NMID: <strong style="color: var(--color-text-main);"><?= e($settings['qris_nmid'] ?? 'ID1026610748760') ?></strong></span>
                <span class="badge" style="background: #E2E8F0; color: #334155; font-size: 0.65rem; padding: 2px 6px;">A01</span>
              </div>
            </div>

            <div style="font-size: var(--font-size-xs); color: var(--color-text-main); line-height: 1.6;">
              <ol style="margin: 0; padding-left: 18px; color: var(--color-text-muted); display: flex; flex-direction: column; gap: 4px;">
                <li>Transfer nominal tepat sebesar <strong style="color: var(--color-primary);"><?= rupiah($order['total']) ?></strong> via QRIS di samping.</li>
                <li>Pastikan nama merchant penerima adalah <strong><?= e($settings['qris_merchant_name'] ?? 'campusmart horizon, Stationery') ?></strong>.</li>
                <li>Simpan tangkapan layar/foto struk bukti transfer dan unggah melalui form di bawah ini.</li>
              </ol>
            </div>
          </div>
        </div>

        <?php if (!empty($payment['proof_path'])): ?>
          <div style="background: #F8FAFC; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: var(--spacing-3); display: flex; align-items: center; gap: 12px; margin-bottom: var(--spacing-3);">
            <a href="<?= asset($payment['proof_path']) ?>" target="_blank" style="width: 50px; height: 50px; border-radius: 4px; overflow: hidden; display: block; border: 1px solid var(--color-border); flex-shrink: 0;">
              <img src="<?= asset($payment['proof_path']) ?>" alt="Bukti Transfer" style="width: 100%; height: 100%; object-fit: cover;">
            </a>
            <div>
              <div style="font-size: var(--font-size-xs); font-weight: 700; color: var(--color-text-main);">Bukti Pembayaran Terunggah</div>
              <div style="font-size: 0.7rem; color: var(--color-text-muted);">
                Status verifikasi: <strong><?= strtoupper(str_replace('_', ' ', $payment['status'])) ?></strong>
                <?php if ($payment['status'] === 'paid'): ?>
                  <span style="color: var(--color-success); font-weight: 700;">(Lunas &bull; Diverifikasi admin)</span>
                <?php elseif ($payment['status'] === 'rejected'): ?>
                  <span style="color: var(--color-danger); font-weight: 700;">(Bukti ditolak &bull; Silakan unggah bukti yang benar)</span>
                <?php else: ?>
                  <span style="color: #D97706; font-weight: 700;">(Menunggu verifikasi admin)</span>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($order['payment_status'] !== 'paid'): ?>
          <form action="/orders/<?= e($order['order_code']) ?>/payment-proof" method="POST" enctype="multipart/form-data" style="margin-top: var(--spacing-3);">
            <?= csrf_field() ?>
            <div class="form-group" style="margin-bottom: var(--spacing-3);">
              <label for="proof-file" class="form-label" style="font-size: var(--font-size-xs);">
                <?= !empty($payment['proof_path']) ? 'Unggah Ulang Bukti Transfer Baru:' : 'Unggah Bukti Transfer QRIS:' ?>
              </label>
              <input type="file" name="payment_proof" id="proof-file" class="form-control" accept="image/jpeg,image/png,image/webp" required style="font-size: var(--font-size-xs);">
              <div style="font-size: 0.7rem; color: var(--color-text-muted); margin-top: 2px;">
                Maksimal 2MB. Format file: JPG, PNG, atau WebP.
              </div>
            </div>
            <button type="submit" class="btn btn-primary btn-sm">
              Kirim Bukti Pembayaran
            </button>
          </form>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <!-- Titik Pengambilan Internal Kampus -->
    <div style="border-top: 1px solid var(--color-border); padding-top: var(--spacing-4); font-size: var(--font-size-xs); color: var(--color-text-muted);">
      <strong>Titik Serah-Terima:</strong> Counter Resmi CampusMart, Gedung Rektorat Lt. 1, Horizon University Indonesia.<br>
      Tunjukkan kode pesanan <strong>#<?= e($order['order_code']) ?></strong> saat pengambilan barang.
    </div>
  </div>

  <!-- Audit Trail Riwayat Status -->
  <?php if (!empty($histories)): ?>
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-5); box-shadow: var(--shadow-sm); margin-bottom: var(--spacing-8);">
      <h2 style="font-size: var(--font-size-sm); font-weight: 700; margin-bottom: var(--spacing-3);">Log Riwayat Perjalanan Pesanan</h2>
      <div style="display: flex; flex-direction: column; gap: 8px;">
        <?php foreach ($histories as $hist): ?>
          <div style="display: flex; justify-content: space-between; font-size: var(--font-size-xs); border-left: 2px solid var(--color-primary); padding-left: 10px;">
            <div>
              <span class="badge badge-<?= e($hist['new_status']) ?>" style="font-size: 0.7rem;"><?= e(str_replace('_', ' ', $hist['new_status'])) ?></span>
              <span style="color: var(--color-text-main); margin-left: 6px;"><?= e($hist['note'] ?: 'Status diperbarui') ?></span>
            </div>
            <div style="color: var(--color-text-muted); font-size: 0.7rem;">
              <?= date('d M Y, H:i', strtotime($hist['created_at'])) ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>
</div>
