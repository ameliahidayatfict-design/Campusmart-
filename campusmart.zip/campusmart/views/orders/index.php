<div class="container" style="max-width: 760px; margin-top: var(--spacing-6);">
  <div style="margin-bottom: var(--spacing-4);">
    <h1 style="font-size: var(--font-size-2xl); font-weight: 800; color: var(--color-text-main); margin-bottom: 4px;">
      Riwayat Pesanan
    </h1>
    <p style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
      Pantau status pemrosesan dan serah-terima pesanan Anda di kampus.
    </p>
  </div>

  <?php if (!empty($orders)): ?>
    <div style="display: flex; flex-direction: column; gap: var(--spacing-3);">
      <?php foreach ($orders as $ord): ?>
        <a href="/orders/<?= e($ord['order_code']) ?>" style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: var(--spacing-4) var(--spacing-5); box-shadow: var(--shadow-sm); display: flex; align-items: center; justify-content: space-between; transition: var(--transition);" onmouseover="this.style.borderColor='var(--color-primary)'; this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='var(--color-border)'; this.style.transform='none'">
          <div style="display: flex; align-items: center; gap: 14px;">
            <div style="width: 44px; height: 44px; border-radius: var(--radius-md); background: var(--color-primary-soft); color: var(--color-primary); display: flex; align-items: center; justify-content: center;">
              <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
            </div>
            <div>
              <div style="font-weight: 800; font-size: var(--font-size-base); color: var(--color-text-main);">
                #<?= e($ord['order_code']) ?>
              </div>
              <div style="font-size: var(--font-size-xs); color: var(--color-text-muted);">
                <?= date('d M Y, H:i', strtotime($ord['created_at'])) ?> &bull; <?= e(strtoupper($ord['payment_method'])) ?>
              </div>
              <div style="font-size: 0.75rem; color: var(--color-text-muted); margin-top: 2px;">
                <?= (int)$ord['item_count'] ?> jenis barang
              </div>
            </div>
          </div>

          <div style="text-align: right;">
            <span class="badge badge-<?= e($ord['status']) ?>" style="font-size: 0.75rem; margin-bottom: 4px;">
              <?= e(str_replace('_', ' ', $ord['status'])) ?>
            </span>
            <div style="font-size: var(--font-size-base); font-weight: 800; color: var(--color-primary);">
              <?= rupiah($ord['total']) ?>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
      <div style="margin-top: var(--spacing-8); display: flex; justify-content: center; gap: 6px;">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
          <a href="/orders?page=<?= $i ?>" class="btn <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>" style="min-width: 38px; padding: 6px 12px; font-size: 0.85rem;">
            <?= $i ?>
          </a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>

  <?php else: ?>
    <div style="background: #FFFFFF; border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: 4rem 2rem; text-align: center;">
      <div style="width: 60px; height: 60px; margin: 0 auto var(--spacing-4) auto; background: var(--color-primary-soft); color: var(--color-primary); border-radius: var(--radius-full); display: flex; align-items: center; justify-content: center;">
        <svg width="30" height="30" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
      </div>
      <h2 style="font-size: var(--font-size-base); font-weight: 700; color: var(--color-text-main); margin-bottom: 4px;">Belum Ada Riwayat Pesanan</h2>
      <p style="color: var(--color-text-muted); font-size: var(--font-size-xs); margin-bottom: var(--spacing-6);">Anda belum pernah melakukan pemesanan di CampusMart.</p>
      <a href="/products" class="btn btn-primary">Mulai Belanja Sekarang</a>
    </div>
  <?php endif; ?>
</div>
