<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($title) ? e($title) . ' — Admin CampusMart' : 'Admin Panel — CampusMart' ?></title>
  
  <link rel="icon" type="image/png" href="<?= asset('assets/images/logo.png') ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400;1,600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= asset('assets/css/main.css') ?>">
</head>
<body>
  <div class="admin-wrapper">
    <?php require dirname(__DIR__) . '/partials/admin-sidebar.php'; ?>
    <div class="admin-backdrop" id="adminBackdrop"></div>

    <div class="admin-main">
      <header class="admin-topbar">
        <div style="display: flex; align-items: center; gap: 12px;">
          <button type="button" class="admin-sidebar-toggle" id="adminSidebarToggle" aria-label="Buka Menu Admin" title="Buka Menu">
            <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
          </button>
          <h2 style="font-size: 1.15rem; font-weight: 700; color: var(--color-text-main);">
            <?= isset($pageHeader) ? e($pageHeader) : 'Dashboard Admin' ?>
          </h2>
        </div>

        <div style="display: flex; align-items: center; gap: 16px;">
          <div style="text-align: right; line-height: 1.2;">
            <div style="font-weight: 600; font-size: 0.875rem;"><?= e(auth_user()['name'] ?? 'Admin') ?></div>
            <div style="font-size: 0.75rem; color: var(--color-primary); font-weight: 600;">Administrator</div>
          </div>
          <div style="width: 38px; height: 38px; border-radius: var(--radius-full); background: var(--color-primary); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700;">
            A
          </div>
        </div>
      </header>

      <main class="admin-content">
        <?php require dirname(__DIR__) . '/partials/flash.php'; ?>
        <?= $content ?>
        <?php require dirname(__DIR__) . '/partials/popups.php'; ?>
      </main>
    </div>
  </div>

  <script src="<?= asset('assets/js/alpine-app.js') ?>"></script>
  <script src="<?= asset('assets/js/alpine.min.js') ?>" defer></script>
  <script src="<?= asset('assets/js/app.js') ?>"></script>
  <script src="<?= asset('assets/js/sweetalert2.all.min.js') ?>"></script>
  <script src="<?= asset('assets/js/campus-alerts.js') ?>"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const toggleBtn = document.getElementById('adminSidebarToggle');
      const closeBtn = document.getElementById('adminSidebarClose');
      const sidebar = document.getElementById('adminSidebar');
      const backdrop = document.getElementById('adminBackdrop');

      function openSidebar() {
        sidebar?.classList.add('open');
        backdrop?.classList.add('active');
        document.body.style.overflow = 'hidden';
      }

      function closeSidebar() {
        sidebar?.classList.remove('open');
        backdrop?.classList.remove('active');
        document.body.style.overflow = '';
      }

      toggleBtn?.addEventListener('click', openSidebar);
      closeBtn?.addEventListener('click', closeSidebar);
      backdrop?.addEventListener('click', closeSidebar);

      sidebar?.querySelectorAll('.sidebar-item a')?.forEach(function(link) {
        link.addEventListener('click', function() {
          if (window.innerWidth < 1024) {
            closeSidebar();
          }
        });
      });
    });
  </script>
</body>
</html>
