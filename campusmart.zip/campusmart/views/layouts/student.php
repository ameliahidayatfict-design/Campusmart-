<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="CampusMart — Marketplace kebutuhan mahasiswa lingkungan internal kampus Horizon University Indonesia">
  <title><?= isset($title) ? e($title) . ' — CampusMart' : 'CampusMart — Belanja Kebutuhan Kampus' ?></title>
  
  <link rel="icon" type="image/png" href="<?= asset('assets/images/logo.png') ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400;1,600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= asset('assets/css/main.css') ?>">
</head>
<body>
  <?php require dirname(__DIR__) . '/partials/header.php'; ?>

  <main class="main-content" id="main-content">
    <div class="container" style="margin-top: var(--spacing-4);">
      <?php require dirname(__DIR__) . '/partials/flash.php'; ?>
    </div>
    <?= $content ?>
  </main>

  <?php require dirname(__DIR__) . '/partials/bottom-nav.php'; ?>
  <?php require dirname(__DIR__) . '/partials/footer.php'; ?>
  <?php require dirname(__DIR__) . '/partials/popups.php'; ?>

  <script src="<?= asset('assets/js/sweetalert2.all.min.js') ?>"></script>
  <script src="<?= asset('assets/js/campus-alerts.js') ?>"></script>
  <script src="<?= asset('assets/js/alpine-app.js') ?>"></script>
  <script src="<?= asset('assets/js/alpine.min.js') ?>" defer></script>
  <script src="<?= asset('assets/js/app.js') ?>"></script>
</body>
</html>
