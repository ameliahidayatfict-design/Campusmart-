<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($title) ? e($title) . ' — CampusMart' : 'Autentikasi — CampusMart' ?></title>
  
  <link rel="icon" type="image/png" href="<?= asset('assets/images/logo.png') ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400;1,600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= asset('assets/css/main.css') ?>">
  <style>
    .auth-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-4);
      background-color: var(--color-bg);
      position: relative;
    }
    .auth-card {
      width: 100%;
      max-width: 440px;
      background-color: #FFFFFF;
      border: 1px solid var(--color-border);
      border-radius: var(--radius-lg);
      padding: var(--spacing-8);
      box-shadow: var(--shadow-md);
      position: relative;
      z-index: 2;
    }
    .auth-logo-wrap {
      text-align: center;
      margin-bottom: var(--spacing-6);
    }
    .auth-logo {
      height: 48px;
      margin: 0 auto;
      object-fit: contain;
    }
    .auth-back-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 0.8125rem;
      font-weight: 600;
      color: var(--color-text-muted);
      text-decoration: none;
      padding: 6px 12px;
      border-radius: var(--radius-full);
      background-color: var(--color-surface);
      border: 1px solid var(--color-border);
      transition: all 0.2s ease;
    }
    .auth-back-btn:hover {
      color: var(--color-primary);
      border-color: var(--color-primary);
      background-color: var(--color-primary-soft);
      transform: translateX(-2px);
    }
  </style>
</head>
<body class="auth-page">
  <div class="auth-card">
    <div style="margin-bottom: var(--spacing-4);">
      <a href="/" class="auth-back-btn" title="Kembali ke Beranda">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
        </svg>
        <span>Kembali ke Beranda</span>
      </a>
    </div>

    <div class="auth-logo-wrap">
      <a href="/">
        <img src="<?= asset('assets/images/logo.png') ?>" alt="CampusMart" class="auth-logo">
      </a>
    </div>

    <?php require dirname(__DIR__) . '/partials/flash.php'; ?>
    <?= $content ?>
    <?php require dirname(__DIR__) . '/partials/popups.php'; ?>
  </div>

  <script src="<?= asset('assets/js/sweetalert2.all.min.js') ?>"></script>
  <script src="<?= asset('assets/js/campus-alerts.js') ?>"></script>
  <script src="<?= asset('assets/js/alpine-app.js') ?>"></script>
  <script src="<?= asset('assets/js/alpine.min.js') ?>" defer></script>
  <script src="<?= asset('assets/js/app.js') ?>"></script>
</body>
</html>
