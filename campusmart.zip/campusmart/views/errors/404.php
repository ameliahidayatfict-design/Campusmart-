<div class="container" style="text-align: center; padding: 4rem 1rem;">
  <div style="font-size: 5rem; font-weight: 800; color: var(--color-primary); line-height: 1;">404</div>
  <h1 style="font-size: 1.5rem; font-weight: 700; margin: 1rem 0; color: var(--color-text-main);">Halaman Tidak Ditemukan</h1>
  <p style="color: var(--color-text-muted); max-width: 480px; margin: 0 auto 2rem auto;">
    Maaf, halaman atau produk yang Anda cari tidak tersedia atau tautan sudah berpindah.
  </p>
  <a href="/" class="btn btn-primary btn-lg">Kembali ke Beranda</a>
</div>
