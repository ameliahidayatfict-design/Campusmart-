<div class="container" style="text-align: center; padding: 4rem 1rem;">
  <div style="font-size: 5rem; font-weight: 800; color: var(--color-danger); line-height: 1;">403</div>
  <h1 style="font-size: 1.5rem; font-weight: 700; margin: 1rem 0; color: var(--color-text-main);">Akses Ditolak</h1>
  <p style="color: var(--color-text-muted); max-width: 480px; margin: 0 auto 2rem auto;">
    Anda tidak memiliki hak otorisasi untuk mengakses halaman ini. Halaman ini hanya diperuntukkan bagi Administrator.
  </p>
  <a href="/" class="btn btn-primary btn-lg">Kembali ke Beranda</a>
</div>
