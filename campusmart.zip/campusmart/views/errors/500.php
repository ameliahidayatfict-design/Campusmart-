<div class="container" style="text-align: center; padding: 4rem 1rem;">
  <div style="font-size: 5rem; font-weight: 800; color: var(--color-warning); line-height: 1;">500</div>
  <h1 style="font-size: 1.5rem; font-weight: 700; margin: 1rem 0; color: var(--color-text-main);">Terjadi Kesalahan Server</h1>
  <p style="color: var(--color-text-muted); max-width: 480px; margin: 0 auto 2rem auto;">
    Sistem sedang mengalami kendala internal. Silakan coba beberapa saat lagi atau hubungi administrator.
  </p>
  <a href="/" class="btn btn-primary btn-lg">Kembali ke Beranda</a>
</div>
