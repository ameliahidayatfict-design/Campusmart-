<?php
/**
 * Test Suite for CAMPUSMART Tahap 9 & 10
 */

require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/helpers/helpers.php';

// Autoloader
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    $baseDir = __DIR__ . '/../app/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});

use App\Core\Database;
use App\Models\User;
use App\Models\Product;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Setting;

$passed = 0;
$failed = 0;

function assertTest(string $desc, bool $condition, ?string $detail = null) {
    global $passed, $failed;
    if ($condition) {
        echo " [PASS] $desc\n";
        $passed++;
    } else {
        echo " [FAIL] $desc" . ($detail ? " ($detail)" : "") . "\n";
        $failed++;
    }
}

echo "=======================================================\n";
echo "   CAMPUSMART — AUTOMATED TEST TAHAP 9 & 10            \n";
echo "=======================================================\n\n";

$pdo = Database::getConnection();

// -----------------------------------------------------------
// 1. TAHAP 9: KEAMANAN, RBAC & MODEL VALIDATION
// -----------------------------------------------------------
echo "--- 1. Keamanan & RBAC (Tahap 9) ---\n";

$adminUser = User::findByEmail('admin@campusmart.id');
$studentUser1 = User::findByEmail('dina@gmail.com');
$studentUser2 = User::findByEmail('aryasyah@gmail.com');

assertTest("Admin account exists and has role admin", $adminUser && $adminUser['role'] === 'admin');
assertTest("Student 1 exists and has role student", $studentUser1 && $studentUser1['role'] === 'student');
assertTest("Student 2 exists and has role student", $studentUser2 && $studentUser2['role'] === 'student');

// Verify IDOR check logic on orders: Student 1 order should not be accessible by Student 2
$student1Orders = Order::paginate(['user_id' => $studentUser1['id']], 1, 1);
$student1Order = $student1Orders['items'][0] ?? null;

if ($student1Order) {
    $isOwner1 = ((int)$student1Order['user_id'] === (int)$studentUser1['id']);
    $isOwner2 = ((int)$student1Order['user_id'] === (int)$studentUser2['id']);
    assertTest("Student 1 owns order #" . $student1Order['order_code'], $isOwner1);
    assertTest("IDOR check: Student 2 does NOT own Student 1's order", !$isOwner2);
}

// -----------------------------------------------------------
// 2. TAHAP 10A: KERANJANG BELANJA (CART)
// -----------------------------------------------------------
echo "\n--- 2. Keranjang Belanja (Tahap 10A) ---\n";

$testUserId = (int)$studentUser1['id'];
// Clear any existing test cart items
Cart::clearCart($testUserId);
assertTest("Cart initialized/cleared", Cart::countItems($testUserId) === 0);

// Fetch an active product
$product1 = Product::findById(1); // Buku Catatan Spiral
$initialStock1 = (int)$product1['stock'];

// Add item to cart
$addResult = Cart::addItem($testUserId, $product1['id'], 2);
assertTest("Add 2 units of product #1 to cart", $addResult['success']);
assertTest("Cart count equals 2", Cart::countItems($testUserId) === 2);

// Check totals
$totals = Cart::getTotals($testUserId);
$expectedTotal = (float)$product1['price'] * 2;
assertTest("Server-side subtotal calculation matches unit price * 2", abs($totals['subtotal'] - $expectedTotal) < 0.01);
assertTest("Campus shipping fee is strictly Rp 0", abs($totals['total'] - $totals['subtotal']) < 0.01);
assertTest("Cart has no invalid items initially", $totals['has_invalid'] === false);

// Try adding more than available stock
$exceedQty = $initialStock1 + 100;
$exceedResult = Cart::addItem($testUserId, $product1['id'], $exceedQty);
assertTest("Reject adding quantity that exceeds product stock", !$exceedResult['success']);

// Update quantity
$updateResult = Cart::updateItem($testUserId, $product1['id'], 3);
assertTest("Update cart quantity to 3", $updateResult['success']);
assertTest("Cart count updated to 3", Cart::countItems($testUserId) === 3);

// Isolation: Verify Student 2 cart is completely independent
$student2CartCount = Cart::countItems((int)$studentUser2['id']);
assertTest("Student 2 cart is completely isolated from Student 1", $student2CartCount !== 3);

// Remove item
Cart::removeItem($testUserId, $product1['id']);
assertTest("Remove item from cart", Cart::countItems($testUserId) === 0);

// -----------------------------------------------------------
// 3. TAHAP 10B & 10C: CHECKOUT, TRANSAKSI, STOK & PEMBAYARAN
// -----------------------------------------------------------
echo "\n--- 3. Checkout, Transaksi Stok, QRIS & COD (Tahap 10B & 10C) ---\n";

// Add product #1 (qty 2) to cart for checkout
Cart::addItem($testUserId, $product1['id'], 2);

// Pre-checkout stock check
$p1Before = Product::findById($product1['id']);
$stockBefore = (int)$p1Before['stock'];

// Execute transactional order creation (QRIS method)
$orderResult = Order::createOrder(
    $testUserId,
    'Dina Safitri Testing',
    'dina.test@horizon.ac.id',
    '081299998888',
    'Catatan pengujian checkout',
    'qris',
    null
);

assertTest("Checkout transaction executed successfully", $orderResult['success'] === true);
$createdOrderCode = $orderResult['order_code'] ?? null;
$createdOrderId = $orderResult['order_id'] ?? null;

assertTest("Unique order code generated (" . $createdOrderCode . ")", !empty($createdOrderCode));

// Verify stock was decremented by 2
$p1After = Product::findById($product1['id']);
$stockAfter = (int)$p1After['stock'];
assertTest("Product stock decremented from $stockBefore to $stockAfter", $stockAfter === ($stockBefore - 2));

// Verify cart is cleared after checkout
assertTest("Cart is cleared automatically after successful checkout", Cart::countItems($testUserId) === 0);

// Verify order record in DB
$createdOrder = Order::findById($createdOrderId);
assertTest("Order status is initial 'pending'", $createdOrder['status'] === 'pending');
assertTest("QRIS initial payment status is 'pending_verification'", $createdOrder['payment_status'] === 'pending_verification');
assertTest("Order subtotal matches server calculation", (float)$createdOrder['subtotal'] === (float)$product1['price'] * 2);
assertTest("Total matches subtotal (Rp 0 ongkir)", (float)$createdOrder['total'] === (float)$createdOrder['subtotal']);

// Verify snapshots in order_items
$orderItems = Order::getItems($createdOrderId);
assertTest("Order items snapshot count is 1", count($orderItems) === 1);
assertTest("Item snapshot product name preserved", $orderItems[0]['product_name'] === $product1['name']);
assertTest("Item snapshot unit price preserved", (float)$orderItems[0]['unit_price'] === (float)$product1['price']);
assertTest("Item snapshot quantity preserved", (int)$orderItems[0]['quantity'] === 2);

// Verify payment record
$paymentRecord = Order::getPayment($createdOrderId);
assertTest("Payment record created with method 'qris'", $paymentRecord && $paymentRecord['method'] === 'qris');
assertTest("Payment status is 'pending_verification'", $paymentRecord['status'] === 'pending_verification');

// Verify initial audit history logged
$histories = Order::getHistories($createdOrderId);
assertTest("Order status history logged initial pending creation", count($histories) >= 1 && $histories[0]['new_status'] === 'pending');

// Test Upload Payment Proof (Tahap 10C)
$proofTestPath = '/uploads/payments/test_proof_' . time() . '.png';
$proofUpdated = Order::updatePaymentProof($createdOrderId, $proofTestPath, $testUserId);
assertTest("Update payment proof for QRIS order", $proofUpdated);

$refreshedPayment = Order::getPayment($createdOrderId);
assertTest("Payment proof path saved correctly", $refreshedPayment['proof_path'] === $proofTestPath);

// Test Admin Payment Verification: Approve (Paid)
$payVerified = Order::updatePaymentStatus($createdOrderId, 'paid', (int)$adminUser['id']);
assertTest("Admin approves payment status to 'paid'", $payVerified);

$refreshedOrder = Order::findById($createdOrderId);
assertTest("Order payment_status is now 'paid'", $refreshedOrder['payment_status'] === 'paid');

// Test Safe Stock Recovery on Order Cancellation
// When an order is cancelled, stock must be returned back to the product
$cancelSuccess = Order::updateStatus($createdOrderId, 'cancelled', (int)$adminUser['id'], 'Pesanan dibatalkan untuk pengujian stock recovery');
assertTest("Order cancelled by admin", $cancelSuccess);

$p1Restored = Product::findById($product1['id']);
assertTest("Product stock restored safely upon cancellation (Back to $stockBefore)", (int)$p1Restored['stock'] === $stockBefore);

// -----------------------------------------------------------
// 4. TAHAP 10D: LAPORAN PENJUALAN ADMIN (SALES REPORT)
// -----------------------------------------------------------
echo "\n--- 4. Laporan Penjualan Admin (Tahap 10D) ---\n";

$report = Order::getSalesReport([]);
assertTest("Sales report returns metrics array", is_array($report['metrics']));
assertTest("Total orders is greater than 0", (int)$report['metrics']['total_orders'] > 0);
assertTest("Total GMV excludes cancelled orders", (float)$report['metrics']['total_gmv'] >= (float)$report['metrics']['total_paid_revenue']);
assertTest("Top products aggregation returns array", is_array($report['top_products']));

// Filter by status completed
$completedReport = Order::getSalesReport(['status' => 'completed']);
assertTest("Filter report by status 'completed' returns valid metrics", (int)$completedReport['metrics']['total_orders'] >= 1);

// Filter by payment_status paid
$paidReport = Order::getSalesReport(['payment_status' => 'paid']);
assertTest("Filter report by payment_status 'paid' returns paid revenue > 0", (float)$paidReport['metrics']['total_paid_revenue'] > 0);

// Filter by date
$todayDate = date('Y-m-d');
$todayReport = Order::getSalesReport(['start_date' => $todayDate, 'end_date' => $todayDate]);
assertTest("Filter report by current date returns valid metrics structure", isset($todayReport['metrics']['total_gmv']));

// -----------------------------------------------------------
// 5. SETTINGS MODEL
// -----------------------------------------------------------
echo "\n--- 5. Settings Model ---\n";
$allSettings = Setting::all();
assertTest("Settings contains campus_name", !empty($allSettings['campus_name']));
assertTest("Settings contains qris_merchant_name", !empty($allSettings['qris_merchant_name']));
assertTest("Settings contains pickup_location", !empty($allSettings['pickup_location']));

echo "\n=======================================================\n";
echo "   HASIL PENGUJIAN TAHAP 9 & 10: $passed PASSED, $failed FAILED\n";
echo "=======================================================\n";

if ($failed > 0) {
    exit(1);
}
