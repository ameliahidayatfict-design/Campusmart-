-- ============================================================
-- CAMPUSMART SEEDER DATA
-- ============================================================

USE `campusmart`;

-- 1. USERS SEED (Default Admin Account)
INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `student_id`, `phone`, `role`, `status`) VALUES
(1, 'Admin CampusMart', 'admin@campusmart.id', '$2y$10$s9GAFye6IbvkMuYBHjBzw.KM3hjGrkj0KKiF18RUvUfZ8GIMDAylm', NULL, '081234567890', 'admin', 'active')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- 2. CATEGORIES SEED
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `icon`, `status`) VALUES
(1, 'Buku', 'buku', 'Buku catatan, binder, modul, dan buku referensi kuliah.', 'book', 'active'),
(2, 'Alat Tulis', 'alat-tulis', 'Pulpen, pensil, sticky notes, penggaris, dan perlengkapan ujian.', 'pencil', 'active'),
(4, 'Aksesoris', 'aksesoris', 'Tumbler, tas ransel, lanyard, tote bag, dan merchandise resmi kampus.', 'shopping-bag', 'active')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- 3. SETTINGS SEED
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('campus_name', 'Horizon University Indonesia'),
('qris_merchant_name', 'campusmart horizon, Stationery'),
('qris_nmid', 'ID1026610748760'),
('qris_instruction', 'Silakan scan QRIS resmi kampus di atas dengan m-Banking / e-Wallet Anda. Pastikan nominal transfer sesuai dengan total pesanan, lalu unggah bukti transfer.'),
('pickup_location', 'Gedung Rektorat Lt. 1 - Counter CampusMart'),
('pickup_hours', 'Senin - Jumat: 08.00 - 16.00 WIB'),
('contact_admin', '0812-3456-7890 (WhatsApp Admin)')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`);
