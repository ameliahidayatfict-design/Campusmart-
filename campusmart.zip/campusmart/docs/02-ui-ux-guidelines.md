# 02 — UI/UX Guidelines

## 1. Referensi utama
Gunakan desain mobile CAMPUSMART yang diberikan client melalui Figma dan kumpulan screenshot frame. Screenshot tersebut mencakup halaman pembuka/onboarding, beranda, kategori, katalog, detail produk, keranjang, checkout/pembayaran, riwayat pesanan, profil, pengaturan/notifikasi, serta beberapa halaman admin seperti dashboard, produk, kategori, pesanan, dan laporan.

Figma: https://www.figma.com/design/yRXZ6fBzMreBLItsEa32Qt/Untitled?node-id=1-2&t=N5ELfLC24gxEJHpF-1

Screenshot client adalah referensi visual. Jangan mengganti identitas visual secara bebas. Bila suatu elemen tidak jelas, buat keputusan konsisten dan dokumentasikan.

## 2. Identitas visual
- Warna dominan: maroon, mengikuti logo CAMPUSMART.
- Rekomendasi token awal (sesuaikan dengan warna logo asli):
  - `--color-primary: #800020`
  - `--color-primary-dark: #5B0017`
  - `--color-primary-soft: #FFF5F6`
  - `--color-background: #FFFFFF`
  - `--color-surface: #FFFFFF`
  - `--color-text: #27272A`
  - `--color-muted: #71717A`
  - `--color-border: #E4E4E7`
  - `--color-success: #15803D`
  - `--color-warning: #B45309`
  - `--color-danger: #B91C1C`
- Maroon dipakai untuk tombol utama, header tertentu, navigasi aktif, badge penting, dan elemen identitas.
- Pastikan teks di atas maroon memenuhi kontras dan mudah dibaca.
- Hindari gradient, glow, efek glassmorphism berlebihan, dan dekorasi yang tidak terdapat pada referensi.
- Gunakan logo asli yang disediakan client; jangan menggambar ulang atau mengubah proporsinya.

## 3. Perilaku layout responsif
Breakpoint awal:
- Mobile: `< 768px`
- Tablet: `768px–1023px`
- Desktop: `>= 1024px`
- Desktop lebar: `>= 1440px`

Breakpoint boleh disesuaikan berdasarkan konten, bukan hanya ukuran perangkat.

### Mobile
- Pertahankan pola navigasi bawah yang tampak pada desain bila relevan untuk halaman mahasiswa.
- Katalog produk umumnya 2 kolom.
- Tombol aksi utama mudah dijangkau dan memiliki area klik memadai.
- Hindari horizontal overflow; form dan kartu harus mengikuti lebar layar.
- Halaman admin boleh menggunakan sidebar yang berubah menjadi drawer/menu ringkas.

### Desktop
Jangan sekadar memperbesar layout mobile.
- Header mahasiswa menjadi horizontal: logo, pencarian, navigasi/kategori, keranjang, dan akun.
- Batasi lebar konten agar tidak terlalu melebar; gunakan container terpusat.
- Beranda: area hero/promosi, kategori horizontal, dan grid produk 4 kolom (dapat 5 pada layar lebar).
- Katalog: filter di sisi kiri dan grid produk di sisi kanan; filter dapat menjadi panel/dropdown pada tablet.
- Detail produk: gambar di kiri dan informasi/harga/stok/kuantitas/aksi di kanan.
- Keranjang/checkout: daftar item di area utama dan ringkasan pesanan di panel samping pada desktop; susun vertikal di mobile.
- Riwayat pesanan: daftar atau tabel ringkas di desktop, kartu di mobile.
- Dashboard admin: sidebar di kiri, header halaman, kartu metrik, tabel dan filter di area utama.
- Tabel admin harus responsif: gunakan kolom penting saja pada layar kecil atau pola kartu; jangan memaksa seluruh tabel melampaui viewport.

## 4. Komponen konsisten
Buat komponen/template reusable menggunakan PHP include/require untuk:
- Header dan navigasi mahasiswa.
- Footer atau bottom navigation.
- Sidebar dan header admin.
- Breadcrumb.
- Kartu produk.
- Badge status pesanan/pembayaran.
- Input, select, textarea, tombol, alert, modal konfirmasi.
- Pagination, empty state, loading state, error state.
- Flash message untuk hasil aksi.

Gunakan kelas CSS yang konsisten dan hindari duplikasi style antarhalaman.

## 5. Aksesibilitas dan UX
- Setiap input memiliki label.
- Jangan mengandalkan warna saja untuk menjelaskan status.
- Tombol harus memiliki teks yang jelas; ikon saja perlu label aksesibel.
- Sediakan feedback untuk loading, sukses, validasi gagal, dan error.
- Pertahankan nilai input saat validasi gagal jika aman.
- Form tidak boleh kehilangan konteks ketika terjadi error.
- Gunakan gambar produk dengan rasio dan ukuran tampilan konsisten.
- Tampilkan empty state untuk katalog kosong, keranjang kosong, dan riwayat kosong.
- Jangan menampilkan data dummy sebagai data produksi.

## 6. Gambar dan aset
- Simpan aset statis publik di `public/assets/`.
- Logo sumber disimpan di folder aset proyek; salin versi yang dipakai ke `public/assets/images/` atau lokasi aset publik yang konsisten.
- Unggahan pengguna/produk harus divalidasi dan disimpan dengan nama acak, bukan nama file asli.
- Jangan menaruh file rahasia, konfigurasi `.env`, log, atau dump database di direktori publik.

## 7. Kriteria visual
- Cocokkan struktur, warna, tipografi, jarak, radius, dan hierarki dengan screenshot client.
- Periksa minimal pada lebar 375px, 768px, 1024px, dan 1440px.
- Tidak ada elemen terpotong, teks bertabrakan, horizontal scroll tak disengaja, atau tombol di luar layar.
