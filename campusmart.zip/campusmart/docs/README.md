# Dokumentasi Proyek CAMPUSMART

Dokumentasi ini menjadi acuan utama implementasi website CAMPUSMART menggunakan Antigravity.

## Gambaran proyek
CAMPUSMART adalah marketplace kebutuhan mahasiswa untuk lingkungan internal kampus. Mahasiswa dapat mencari dan memesan produk kebutuhan kuliah. Admin mengelola katalog, pengguna, pesanan, serta laporan penjualan. Transaksi diselesaikan secara internal kampus; tidak ada integrasi ekspedisi.

## Teknologi wajib
- PHP Native (tanpa Laravel, CodeIgniter, atau framework backend)
- PDO untuk akses database
- MySQL/MariaDB
- HTML, CSS, JavaScript
- Fetch API/AJAX boleh digunakan untuk interaksi dinamis
- Gunakan Composer hanya jika benar-benar diperlukan dan disetujui; jangan menambahkan framework tanpa persetujuan.

## Dokumen
1. `01-project-requirements.md` — tujuan, ruang lingkup, role, kebutuhan, dan asumsi.
2. `02-ui-ux-guidelines.md` — arahan desain dari screenshot Figma, sistem warna, dan responsivitas.
3. `03-architecture-database.md` — struktur kode, rancangan tabel, relasi, dan aturan transaksi.
4. `04-features-security.md` — alur fitur, status pesanan/pembayaran, validasi, dan keamanan.
5. `05-development-testing-deployment.md` — tahapan kerja, kriteria penerimaan, testing, dan deployment.
6. `AGENTS.md` — instruksi kerja khusus untuk AI coding agent.

## Cara menggunakan
- Baca semua dokumen sebelum mengubah atau membuat kode.
- Gunakan screenshot desain yang disediakan client sebagai referensi visual utama. Jangan mengarang ulang desain jika detail sudah terlihat pada referensi.
- Jika informasi penting belum ditentukan (misalnya mekanisme QRIS, pengambilan barang, atau persetujuan pembayaran), gunakan asumsi yang ditandai jelas dan jangan mengklaimnya sebagai keputusan client.
- Implementasikan bertahap, jalankan pengujian setelah setiap modul, dan perbarui progres.

## Keputusan yang masih perlu dikonfirmasi ke client
1. QRIS menggunakan QRIS statis dengan verifikasi admin atau payment gateway.
2. Lokasi, jam, dan prosedur pengambilan barang di kampus.
3. Apakah stok dikurangi saat pesanan dibuat atau setelah pembayaran/konfirmasi admin.
4. Apakah mahasiswa dapat membatalkan pesanan dan sampai status apa.
5. Informasi yang wajib diisi saat registrasi (mis. nama, email kampus, NIM, program studi, nomor HP).
6. Apakah satu pesanan dapat berisi beberapa produk dan apakah produk memiliki varian.
