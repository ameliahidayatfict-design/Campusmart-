# 04 — Feature Flows & Security

## 1. Alur mahasiswa
1. Mahasiswa registrasi dengan field yang disepakati.
2. Server memvalidasi data, memastikan email unik, lalu menyimpan password menggunakan `password_hash()`.
3. Mahasiswa login; server memverifikasi dengan `password_verify()` dan meregenerasi session ID.
4. Mahasiswa mencari produk, membuka detail, dan menambahkan item ke keranjang.
5. Saat checkout, server memvalidasi ulang stok, harga, kuantitas, dan status produk.
6. Mahasiswa memilih QRIS atau COD, membaca ringkasan, lalu mengonfirmasi pesanan.
7. Sistem membuat kode pesanan dan menampilkan detail transaksi serta langkah berikutnya.
8. Mahasiswa melihat status/riwayat dan detail pesanan.

## 2. Alur QRIS
Metode final perlu dikonfirmasi client.

### Opsi A — QRIS statis + verifikasi manual
- Sistem menampilkan QRIS resmi milik pihak penerima pembayaran.
- Sistem menampilkan nominal dan instruksi pembayaran yang disetujui client.
- Jika diperlukan, mahasiswa mengunggah bukti transfer.
- Pembayaran menjadi `pending_verification`.
- Admin memeriksa pembayaran dan mengubah status menjadi `paid` atau `rejected`.
- Sistem mencatat admin dan waktu verifikasi.
- Jangan pernah menyatakan pembayaran otomatis berhasil hanya karena file bukti diunggah.

### Opsi B — Payment gateway
- Gunakan penyedia yang mendukung QRIS dan callback/webhook resmi.
- Kredensial rahasia hanya berada di server.
- Validasi signature callback, nominal, order reference, dan status transaksi.
- Callback harus idempotent agar notifikasi berulang tidak menggandakan transaksi.
- Opsi ini memerlukan persetujuan client, akun merchant, biaya, serta konfigurasi tambahan.

Jangan mengarang QRIS merchant atau membuat QRIS pembayaran palsu untuk produksi.

## 3. Alur COD
- Pesanan dibuat dengan `payment_method = cod` dan `payment_status = unpaid`.
- Admin memproses pesanan hingga siap diserahkan.
- Pembayaran baru menjadi `paid` setelah uang diterima dan dikonfirmasi oleh pihak berwenang.
- Tandai pesanan selesai setelah serah-terima internal sesuai SOP kampus.
- Tidak ada biaya pengiriman atau status ekspedisi.

## 4. Status pesanan yang disarankan
- `pending`: pesanan baru menunggu peninjauan/konfirmasi.
- `confirmed`: pesanan diterima untuk diproses.
- `processing`: barang sedang disiapkan.
- `ready_for_pickup`: barang siap diambil/serah-terima.
- `completed`: transaksi selesai.
- `cancelled`: pesanan dibatalkan.

Perubahan status harus mengikuti transisi yang diizinkan. Jangan membiarkan user mengirim nilai status sembarang. Status pembayaran terpisah dari status pesanan.

## 5. Hak akses
### Mahasiswa
- Mengakses katalog dan halaman publik.
- Melihat/mengubah profil sendiri sesuai aturan.
- Melihat hanya keranjang dan pesanan miliknya.
- Tidak boleh mengakses halaman admin atau mengubah status pesanan/pembayaran melalui request langsung.

### Admin
- Mengakses modul administrasi.
- Mengelola produk, kategori, pengguna, pesanan, dan laporan sesuai hak akses.
- Verifikasi QRIS hanya oleh role yang diizinkan.
- Aksi sensitif harus divalidasi di server, bukan hanya menyembunyikan tombol.

## 6. Persyaratan keamanan wajib
- Semua query memakai PDO prepared statements; jangan gabungkan input user langsung ke SQL.
- Validasi input di server; escaping output HTML menggunakan `htmlspecialchars()` dengan encoding yang tepat.
- Gunakan `password_hash()` dan `password_verify()`.
- Regenerasi session ID setelah login; cookie session `HttpOnly`, `Secure` saat HTTPS, dan `SameSite` yang sesuai.
- Terapkan proteksi CSRF untuk semua aksi perubahan data berbasis session.
- Cek autentikasi dan role di setiap route/controller yang dilindungi.
- Terapkan validasi kepemilikan untuk detail pesanan, keranjang, dan bukti pembayaran.
- Batasi percobaan login dan berikan pesan error yang tidak membocorkan apakah akun tertentu ada.
- Validasi upload berdasarkan MIME type, ekstensi yang diizinkan, ukuran, dan nama file acak. Jangan mengeksekusi file upload.
- Simpan `.env`, dump SQL, log, dan konfigurasi rahasia di luar public web root.
- Nonaktifkan `display_errors` di produksi; log error ke lokasi privat.
- Gunakan HTTPS di hosting produksi.
- Jangan pernah menyimpan data kartu pembayaran atau password dalam teks biasa.
- Jangan mengandalkan JavaScript sebagai satu-satunya lapisan validasi.

## 7. Laporan penjualan
- Tentukan apakah laporan menghitung pesanan `completed` saja atau menyertakan status lain.
- Pisahkan jumlah pesanan dari pendapatan yang benar-benar dibayar.
- Filter periode tanggal dan status.
- Semua agregasi harus dihitung dari database dengan query yang tervalidasi.
- Gunakan format Rupiah dan timezone yang dikonfirmasi.
- Jika export CSV ditambahkan, cegah CSV formula injection dan batasi akses hanya untuk admin.

## 8. Error handling
- Tampilkan pesan yang jelas kepada pengguna, tanpa SQL, stack trace, path server, atau secret.
- Catat detail teknis ke log privat.
- Gunakan transaksi dan rollback pada operasi checkout yang gagal.
- Tambahkan halaman 403, 404, dan 500 yang konsisten dengan desain.
