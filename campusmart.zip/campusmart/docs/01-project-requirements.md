# 01 — Project Requirements

## 1. Ringkasan
**Nama:** CAMPUSMART  
**Jenis:** Marketplace kebutuhan mahasiswa untuk lingkungan internal kampus.  
**Tujuan:** Mengorganisasi katalog produk, pemesanan, pembayaran, dan pelaporan yang sebelumnya berpotensi tersebar di grup WhatsApp atau media sosial.

## 2. Role
### Mahasiswa
- Registrasi dan login.
- Melihat katalog, kategori, pencarian, dan detail produk.
- Menambahkan produk ke keranjang dan mengubah jumlah.
- Checkout dengan metode QRIS atau COD.
- Melihat status serta riwayat pesanan.
- Melihat detail pesanan dan instruksi penyelesaian transaksi.

### Admin
- Login ke area admin.
- Melihat ringkasan aktivitas marketplace.
- Mengelola produk dan kategori (tambah, lihat, ubah, hapus/nonaktifkan).
- Melihat dan mengelola data pengguna sesuai kewenangan.
- Mengelola pesanan dan memvalidasi pembayaran QRIS.
- Melihat laporan penjualan berdasarkan periode dan status.

## 3. Ruang lingkup fitur
- Autentikasi: register, login, logout, session.
- Katalog: kategori, pencarian, detail produk, status stok.
- Keranjang: tambah, ubah kuantitas, hapus item.
- Checkout: ringkasan barang, total harga, pilihan QRIS/COD, konfirmasi pesanan.
- Pembayaran: QRIS dan COD saja.
- Pesanan: status pesanan, detail, riwayat.
- Admin: dashboard, pengguna, kategori, produk, pesanan, laporan.
- UI responsif untuk mobile, tablet, dan desktop.

## 4. Batasan eksplisit
- Tidak ada integrasi kurir/ekspedisi.
- Tidak ada kalkulasi ongkir.
- Tidak menambahkan metode pembayaran lain tanpa persetujuan.
- Jangan menganggap QRIS otomatis terverifikasi kecuali ada integrasi payment gateway yang disepakati.
- Tidak perlu fitur multi-vendor/reseller kecuali client mengubah kebutuhan.
- Sistem harus tetap PHP Native + PDO + MySQL/MariaDB, HTML, CSS, dan JavaScript.

## 5. Aturan bisnis awal
- Harga dan nama produk pada pesanan harus disimpan sebagai snapshot pada detail pesanan agar riwayat tidak berubah ketika data produk diperbarui.
- Total transaksi dihitung di server, bukan dipercaya dari nilai yang dikirim browser.
- Produk tidak aktif tidak dapat dipesan.
- Jumlah pesanan harus berupa bilangan bulat positif dan tidak boleh melampaui stok tersedia.
- Setiap pesanan mempunyai kode unik yang tidak mudah ditebak.
- Perubahan status pesanan dan pembayaran harus dicatat.
- Admin tidak boleh melihat atau mengubah password pengguna dalam bentuk teks.
- Pesanan COD tetap harus dicatat sebagai belum dibayar sampai pembayaran diterima dan dikonfirmasi.
- Transaksi diselesaikan dengan mekanisme pengambilan/serah-terima internal kampus yang perlu dikonfirmasi client.

## 6. Hal yang belum diputuskan
Jangan membuat asumsi ini seolah keputusan final:
- QRIS statis dengan unggah bukti pembayaran/verifikasi manual atau QRIS melalui payment gateway.
- Titik dan jam pengambilan barang.
- Apakah admin harus menyetujui pesanan sebelum diproses.
- Kebijakan pembatalan dan pengembalian dana.
- Apakah registrasi dibatasi ke email kampus atau perlu verifikasi NIM.
- Apakah perlu unggah foto produk oleh admin dan batas ukuran/jenis file.
- Zona waktu dan format mata uang (rekomendasi: Asia/Makassar atau zona kampus yang dikonfirmasi; format Rupiah).
