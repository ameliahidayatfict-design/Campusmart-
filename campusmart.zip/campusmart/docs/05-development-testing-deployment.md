# 05 — Development, Testing & Deployment

## 1. Tahapan pengembangan
Ikuti urutan kerja client:

1. **Inisiasi Proyek** — pahami kebutuhan, batasan, aset, dan definisi selesai.
2. **Analisis & Basis Data** — tetapkan tabel, relasi, ERD, dan aturan transaksi.
3. **Desain UI/UX** — petakan screenshot mobile ke halaman desktop dan responsif.
4. **Setup Environment** — konfigurasi PHP, MySQL/MariaDB, PDO, `.env`/konfigurasi lokal, dan struktur folder.
5. **Integrasi Frontend** — layout, navigasi, komponen, CSS, JavaScript, responsivitas.
6. **Koneksi & CRUD (Bag. 1)** — kategori dan produk.
7. **Koneksi & CRUD (Bag. 2)** — pengguna, pesanan, serta modul admin lain.
8. **Otentikasi Sistem** — register, login, logout, session, dan profil.
9. **Keamanan & RBAC** — validasi role, CSRF, output escaping, kontrol kepemilikan.
10. **Fitur Lanjutan & Laporan** — cart, checkout, QRIS/COD, status, riwayat, laporan.
11. **Pengujian Sistem** — alur normal, edge cases, responsivitas, dan keamanan.
12. **Bug Fixing & Finalisasi** — perbaiki temuan, rapikan UI, dokumentasi, dan data awal.
13. **Deployment / Hosting** — konfigurasi produksi, database, HTTPS, backup, dan smoke test.

Urutan dapat disesuaikan bila ada dependensi, tetapi jangan melewati keamanan dan testing.

## 2. Cara kerja AI coding agent
Untuk setiap tahap:
1. Baca dokumen relevan.
2. Nyatakan rencana singkat dan file yang akan dibuat/diubah.
3. Implementasikan hanya lingkup tahap tersebut.
4. Jalankan pemeriksaan PHP syntax (`php -l`) untuk file PHP yang berubah.
5. Uji fitur dengan data pengembangan.
6. Periksa tampilan pada mobile dan desktop bila terkait UI.
7. Perbarui `docs/implementation-progress.md` atau catatan progres yang disepakati.
8. Laporkan file yang berubah, test yang dijalankan, hasil, serta isu yang belum selesai.

Jangan mengklaim fitur selesai jika belum diuji. Jangan menghapus file/aset client tanpa alasan dan persetujuan.

## 3. Checklist pengujian fungsional
### Autentikasi
- Registrasi valid berhasil; email duplikat ditolak.
- Password salah ditolak tanpa membocorkan detail akun.
- Logout mengakhiri session.
- Mahasiswa tidak dapat membuka route admin secara langsung.
- Session ID diregenerasi setelah login.

### Produk dan katalog
- Produk aktif tampil; produk nonaktif tidak bisa dibeli.
- Pencarian dan kategori bekerja.
- Harga dan stok tampil dengan benar.
- Input kuantitas nol, negatif, pecahan, atau melebihi stok ditolak.
- Gambar invalid atau terlalu besar ditolak.

### Keranjang dan checkout
- Tambah, ubah jumlah, dan hapus item bekerja.
- Harga dan stok divalidasi ulang di server.
- Total server sesuai detail item.
- Klik submit berulang tidak membuat pesanan ganda.
- Kegagalan saat checkout melakukan rollback.
- Stok tidak menjadi negatif saat dua checkout bersamaan.

### Pembayaran dan pesanan
- QRIS masuk ke status menunggu verifikasi sesuai metode yang dipilih.
- Hanya admin berwenang dapat memverifikasi pembayaran.
- COD tidak otomatis berstatus lunas saat order dibuat.
- Transisi status tidak dapat dilompati secara ilegal.
- Mahasiswa tidak dapat melihat pesanan milik pengguna lain.
- Riwayat mempertahankan snapshot harga dan nama produk.

### Admin dan laporan
- CRUD kategori/produk tervalidasi.
- Produk yang memiliki riwayat pesanan tidak merusak histori.
- Filter laporan periode dan status bekerja.
- Nilai laporan sesuai query transaksi yang menjadi dasar perhitungan.

### UI dan keamanan
- Uji lebar 375, 768, 1024, dan 1440 px.
- Tidak ada horizontal overflow atau tombol terpotong.
- Uji SQL injection, XSS, CSRF, akses langsung ke URL terproteksi, dan upload file.
- Error produksi tidak menampilkan detail teknis.

## 4. Environment lokal
- PHP dengan ekstensi `pdo_mysql` aktif.
- MySQL/MariaDB tersedia.
- Konfigurasi koneksi database disimpan di environment atau file konfigurasi privat yang tidak dapat diakses publik.
- `.env.example` hanya berisi nama variabel dan contoh placeholder, bukan secret.
- Siapkan database lokal, jalankan `schema.sql`, lalu data pengembangan dari `seeders.sql`.
- Dokumentasikan versi PHP dan database yang benar-benar dipakai.

## 5. Deployment checklist
- Backup database dan file penting sebelum deploy.
- Konfigurasi database produksi menggunakan akun dengan hak minimum.
- Pastikan web root mengarah ke folder `public/`.
- Folder `app/`, `docs/`, `database/`, dan `storage/` tidak dapat diakses langsung melalui web.
- Matikan debug/display errors; aktifkan logging privat.
- Aktifkan HTTPS dan cookie session secure.
- Atur permission upload/storage seminimal mungkin.
- Hapus kredensial demo dan data dummy yang tidak diperlukan.
- Buat akun admin awal dengan password unik yang diganti setelah setup.
- Uji login, katalog, checkout, QRIS/COD, perubahan status, dan laporan di server produksi.
- Pastikan backup dapat dipulihkan dan prosedur pembaruan aplikasi terdokumentasi.

## 6. Definition of Done
Sebuah fitur baru dianggap selesai bila:
- Memenuhi kebutuhan yang tertulis.
- Mengikuti desain dan responsif.
- Validasi server dan kontrol akses tersedia.
- Query aman menggunakan PDO.
- Error handling memadai.
- Pengujian relevan lulus.
- Tidak merusak fitur yang sudah ada.
- Dokumentasi/progres diperbarui.
