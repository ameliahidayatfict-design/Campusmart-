# 03 — Architecture & Database

## 1. Arsitektur yang disarankan
Gunakan pola MVC sederhana tanpa framework:
- **Routes/front controller:** memetakan URL dan HTTP method ke controller.
- **Controllers:** menerima request, memeriksa input, memanggil service/model, lalu memilih response/view.
- **Models/repositories:** semua query database menggunakan PDO.
- **Services:** aturan bisnis seperti checkout, stok, status pesanan, dan laporan.
- **Views:** template PHP untuk HTML; jangan menaruh query SQL di view.
- **Middleware/guards:** autentikasi dan pemeriksaan role.
- **Helpers/validators:** fungsi umum dan validasi yang reusable.

Hindari satu file PHP raksasa yang berisi query, HTML, dan seluruh aturan bisnis. Hindari pula abstraksi berlebihan yang tidak diperlukan.

## 2. Struktur folder aplikasi yang disarankan
```text
project/
├── AGENTS.md
├── README.md
├── .env.example
├── .gitignore
├── docs/
├── public/
│   ├── index.php
│   ├── .htaccess
│   └── assets/
├── app/
│   ├── config/
│   ├── core/
│   ├── middleware/
│   ├── controllers/
│   ├── models/
│   ├── services/
│   ├── validators/
│   └── helpers/
├── views/
│   ├── layouts/
│   ├── partials/
│   ├── home/
│   ├── products/
│   ├── cart/
│   ├── checkout/
│   ├── orders/
│   ├── auth/
│   ├── profile/
│   └── admin/
├── routes/
├── database/
└── storage/
    ├── logs/
    └── uploads/
```
Dokumen ini tidak mengharuskan semua kelas dibuat sejak awal. Tambahkan file ketika modul terkait mulai diimplementasikan.

## 3. Rancangan tabel inti
Gunakan InnoDB, foreign key, indeks yang sesuai, `utf8mb4`, dan tipe decimal untuk uang (jangan FLOAT/DOUBLE untuk nominal).

### `users`
- `id` PK
- `name`
- `email` UNIQUE
- `password_hash`
- `student_id` nullable/unique bila NIM diwajibkan
- `phone` nullable
- `role` (mis. `student`, `admin`)
- `status` (mis. `active`, `suspended`)
- `created_at`, `updated_at`

### `categories`
- `id` PK
- `name`
- `slug` UNIQUE
- `description` nullable
- `status`
- `created_at`, `updated_at`

### `products`
- `id` PK
- `category_id` FK
- `name`
- `slug` UNIQUE
- `description`
- `price` DECIMAL(12,2)
- `stock` INT UNSIGNED
- `image_path` nullable
- `status` (active/inactive)
- `created_at`, `updated_at`

### `carts` dan `cart_items` (opsional)
Jika keranjang harus tersimpan lintas sesi/perangkat, gunakan:
- `carts`: `id`, `user_id`, timestamps
- `cart_items`: `id`, `cart_id`, `product_id`, `quantity`, timestamps
Jika cukup sementara, keranjang dapat disimpan di session, tetapi stok dan harga tetap harus diverifikasi ulang saat checkout.

### `orders`
- `id` PK
- `order_code` UNIQUE
- `user_id` FK
- `status` (mis. `pending`, `confirmed`, `processing`, `ready_for_pickup`, `completed`, `cancelled`)
- `payment_method` (`qris`, `cod`)
- `payment_status` (`unpaid`, `pending_verification`, `paid`, `rejected`, `refunded` bila refund memang didukung)
- `subtotal` DECIMAL(12,2)
- `total` DECIMAL(12,2)
- `customer_note` nullable
- snapshot nama/email/telepon bila dibutuhkan untuk rekam transaksi
- timestamps

### `order_items`
- `id` PK
- `order_id` FK
- `product_id` nullable FK (produk bisa dihapus secara logis, tetapi detail historis dipertahankan)
- `product_name` snapshot
- `unit_price` DECIMAL(12,2) snapshot
- `quantity` INT UNSIGNED
- `line_total` DECIMAL(12,2)

### `payments`
- `id` PK
- `order_id` FK
- `method` (`qris`, `cod`)
- `amount` DECIMAL(12,2)
- `status` (`unpaid`, `pending_verification`, `paid`, `rejected`)
- `proof_path` nullable jika client menyetujui unggah bukti QRIS
- `reference` nullable
- `verified_by` nullable FK ke users
- `verified_at` nullable
- timestamps

### `order_status_histories`
- `id` PK
- `order_id` FK
- `old_status` nullable
- `new_status`
- `changed_by` nullable FK ke users
- `note` nullable
- `created_at`

### `settings` (opsional)
Untuk konfigurasi seperti instruksi pengambilan, teks instruksi QRIS, nama kampus, dan kontak admin. Jangan simpan rahasia/payment secret di tabel ini.

### `activity_logs` (opsional)
Log aksi administratif yang relevan tanpa menyimpan password, token, atau data sensitif yang tidak diperlukan.

## 4. Relasi utama
- Satu kategori memiliki banyak produk.
- Satu pengguna memiliki banyak pesanan.
- Satu pesanan memiliki banyak order item.
- Satu pesanan memiliki satu atau lebih record pembayaran jika desain transaksi memerlukannya; untuk versi sederhana, batasi satu pembayaran aktif per pesanan.
- Satu pesanan memiliki banyak riwayat status.
- Admin yang memverifikasi pembayaran direferensikan melalui `verified_by`.

## 5. Aturan integritas transaksi
Saat checkout:
1. Mulai transaksi database (`beginTransaction`).
2. Ambil ulang data produk dan harga dari database.
3. Kunci/validasi stok dengan strategi yang sesuai (`SELECT ... FOR UPDATE` dalam transaksi bila diperlukan).
4. Validasi produk aktif, kuantitas, stok, dan total.
5. Buat order dan order items dengan snapshot harga/nama.
6. Tentukan kebijakan reservasi/pengurangan stok yang disepakati.
7. Buat record pembayaran dan status awal.
8. Commit; rollback jika ada kegagalan.

Jangan menghitung total hanya dari JavaScript atau menerima harga final dari browser.

## 6. Catatan implementasi
- Nama tabel/kolom boleh disesuaikan selama konsisten dan terdokumentasi.
- Buat `database/schema.sql` dan `database/seeders.sql` untuk instalasi lokal.
- Seed data hanya untuk pengembangan/demo; jangan gunakan password default lemah di produksi.
- Tambahkan indeks pada foreign key, `order_code`, email, status, tanggal transaksi, dan kolom pencarian yang relevan.
- Pertimbangkan soft delete/nonaktifkan produk dan kategori yang sudah dipakai dalam transaksi agar histori tetap utuh.
