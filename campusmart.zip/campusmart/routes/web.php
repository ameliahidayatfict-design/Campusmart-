<?php
/**
 * CampusMart Web Routes Definition
 */

use App\Core\Router;
use App\Controllers\HomeController;
use App\Controllers\ProductController;
use App\Controllers\CategoryController;
use App\Controllers\AuthController;
use App\Controllers\ProfileController;
use App\Controllers\OrderController;
use App\Controllers\CartController;
use App\Controllers\CheckoutController;
use App\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Controllers\Admin\CategoryController as AdminCategoryController;
use App\Controllers\Admin\ProductController as AdminProductController;
use App\Controllers\Admin\UserController as AdminUserController;
use App\Controllers\Admin\OrderController as AdminOrderController;
use App\Controllers\Admin\ReportController as AdminReportController;
use App\Middleware\AuthMiddleware;
use App\Middleware\AdminMiddleware;
use App\Middleware\GuestMiddleware;

/** @var Router $router */

// 1. PUBLIC / VISITOR & STUDENT ROUTES
$router->get('/', [HomeController::class, 'index']);
$router->get('/about', [HomeController::class, 'about']);
$router->get('/products', [ProductController::class, 'index']);
$router->get('/products/{slug}', [ProductController::class, 'show']);
$router->get('/categories', [CategoryController::class, 'index']);

// Health check endpoint
$router->get('/health', function($req) {
    echo json_encode([
        'status' => 'OK',
        'php' => PHP_VERSION,
        'app' => config('app.name'),
        'database' => 'Connected via PDO',
        'timestamp' => date('Y-m-d H:i:s'),
    ]);
});

// 2. AUTHENTICATION ROUTES (Guests only for login/register)
$router->get('/login', [AuthController::class, 'showLogin'], [GuestMiddleware::class]);
$router->post('/login', [AuthController::class, 'login'], [GuestMiddleware::class]);
$router->get('/register', [AuthController::class, 'showRegister'], [GuestMiddleware::class]);
$router->post('/register', [AuthController::class, 'register'], [GuestMiddleware::class]);
$router->post('/logout', [AuthController::class, 'logout']);
$router->get('/logout', [AuthController::class, 'logout']);

// 3. STUDENT PROTECTED ROUTES (Requires Login)
$router->get('/profile', [ProfileController::class, 'show'], [AuthMiddleware::class]);
$router->post('/profile', [ProfileController::class, 'update'], [AuthMiddleware::class]);
$router->get('/orders', [OrderController::class, 'index'], [AuthMiddleware::class]);
$router->get('/orders/{order_code}', [OrderController::class, 'show'], [AuthMiddleware::class]);
$router->post('/orders/{order_code}/payment-proof', [CheckoutController::class, 'uploadProof'], [AuthMiddleware::class]);

// Shopping Cart (Tahap 10A)
$router->get('/cart', [CartController::class, 'index'], [AuthMiddleware::class]);
$router->post('/cart/add', [CartController::class, 'add'], [AuthMiddleware::class]);
$router->post('/cart/update', [CartController::class, 'update'], [AuthMiddleware::class]);
$router->post('/cart/remove', [CartController::class, 'remove'], [AuthMiddleware::class]);

// Checkout & Order Placement (Tahap 10B & 10C)
$router->get('/checkout', [CheckoutController::class, 'index'], [AuthMiddleware::class]);
$router->post('/checkout', [CheckoutController::class, 'process'], [AuthMiddleware::class]);

// 4. ADMIN PROTECTED ROUTES (Requires role = admin)
$router->get('/admin', [AdminDashboardController::class, 'index'], [AdminMiddleware::class]);

// Admin Category Management
$router->get('/admin/categories', [AdminCategoryController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/categories/create', [AdminCategoryController::class, 'create'], [AdminMiddleware::class]);
$router->post('/admin/categories', [AdminCategoryController::class, 'store'], [AdminMiddleware::class]);
$router->get('/admin/categories/{id}/edit', [AdminCategoryController::class, 'edit'], [AdminMiddleware::class]);
$router->post('/admin/categories/{id}/edit', [AdminCategoryController::class, 'update'], [AdminMiddleware::class]);
$router->post('/admin/categories/{id}/delete', [AdminCategoryController::class, 'delete'], [AdminMiddleware::class]);

// Admin Product Management
$router->get('/admin/products', [AdminProductController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/products/create', [AdminProductController::class, 'create'], [AdminMiddleware::class]);
$router->post('/admin/products', [AdminProductController::class, 'store'], [AdminMiddleware::class]);
$router->get('/admin/products/{id}/edit', [AdminProductController::class, 'edit'], [AdminMiddleware::class]);
$router->post('/admin/products/{id}/edit', [AdminProductController::class, 'update'], [AdminMiddleware::class]);
$router->post('/admin/products/{id}/delete', [AdminProductController::class, 'delete'], [AdminMiddleware::class]);

// Admin User Management
$router->get('/admin/users', [AdminUserController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/users/{id}', [AdminUserController::class, 'show'], [AdminMiddleware::class]);
$router->post('/admin/users/{id}/status', [AdminUserController::class, 'toggleStatus'], [AdminMiddleware::class]);

// Admin Order Management
$router->get('/admin/orders', [AdminOrderController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/orders/{id}', [AdminOrderController::class, 'show'], [AdminMiddleware::class]);
$router->post('/admin/orders/{id}/status', [AdminOrderController::class, 'updateStatus'], [AdminMiddleware::class]);
$router->post('/admin/orders/{id}/payment', [AdminOrderController::class, 'updatePayment'], [AdminMiddleware::class]);

// Admin Sales Reports (Tahap 10D)
$router->get('/admin/reports', [AdminReportController::class, 'index'], [AdminMiddleware::class]);
