# CAMPUSMART — Marketplace Kebutuhan Mahasiswa

CAMPUSMART adalah platform e-commerce kebutuhan mahasiswa berbasis web yang dikembangkan khusus untuk lingkungan internal kampus **Horizon University Indonesia**. Platform ini memfasilitasi transaksi perlengkapan perkuliahan, buku, alat tulis, dan merchandise kampus secara cepat, transparan, dan aman tanpa biaya pengiriman/ekspedisi (serah-terima fisik langsung di Counter CampusMart Gedung Rektorat Lt. 1).

---

## 🛠️ Arsitektur & Teknologi

- **Backend**: PHP Native (Strict typing, PSR-4 Autoloading, Clean Architecture MVC)
- **Database**: MySQL / MariaDB via **PDO** (Prepared Statements, Row-Locking Transactions `FOR UPDATE`)
- **Frontend**: HTML5 Semantik, Vanilla CSS (Custom Design System Maroon `#800020`), JavaScript Vanilla
- **Security**: CSRF Token Guard, Session Hardening (`SameSite=Lax`, `HttpOnly`, `Secure`), BCRYPT Password Hashing, Output Escaping `e()`, Rate Limiting, File Upload MIME Verification, IDOR & Multi-tenant Protection

---

## 📂 Struktur Direktori

```text
campusmart/
├── app/
│   ├── config/          # Konfigurasi aplikasi & database loader
│   ├── controllers/     # Controller Mahasiswa & Controller Admin (Admin/)
│   ├── core/            # Core MVC (Router, Request, Response, Controller, View, Database, Session, CSRF, Logger)
│   ├── helpers/         # Global helper functions (e(), rupiah(), flash(), auth_user())
│   ├── middleware/      # Middleware otorisasi (AuthMiddleware, AdminMiddleware, GuestMiddleware)
│   ├── models/          # Model PDO (User, Product, Category, Cart, Order, Setting)
│   └── services/        # Service pendukung (UploadService validasi MIME & size)
├── database/
│   ├── schema.sql       # Skema DDL 10 tabel InnoDB utf8mb4
│   └── seeders.sql      # Seeder data awal kategori, produk, akun demo, & settings
├── docs/                # Dokumentasi spesifikasi, UI/UX guidelines, & progres implementasi
├── public/              # Document root publik web server
│   ├── assets/          # Aset CSS (main.css), JavaScript, dan gambar logo/icon
│   ├── uploads/         # Direktori penyimpanan unggahan aman (terproteksi .htaccess)
│   ├── .htaccess        # Web server rewrite & security headers
│   └── index.php        # Front controller & entry point aplikasi
├── storage/             # Penyimpanan log & file internal (terproteksi dari publik)
│   └── logs/            # Log audit & exception dengan otomatisasi sanitasi password
├── tests/               # Test suite otomatis (system_qa_test.php)
├── .env                 # File environment lokal
├── .env.example         # Template konfigurasi environment
├── .htaccess            # Proteksi root & direct forward ke public/
└── README.md            # Dokumentasi ini
```

---

## 🚀 Panduan Instalasi & Menjalankan Lokal

### 1. Prasyarat Sistem
- PHP 8.1 atau lebih baru (dengan ekstensi `pdo_mysql`, `fileinfo`, `mbstring` aktif)
- MySQL 8.0+ atau MariaDB 10.4+
- Web server (PHP Built-in Server, Apache, atau Nginx)

### 2. Konfigurasi Database
1. Buat database baru bernama `campusmart` pada MySQL/MariaDB:
   ```sql
   CREATE DATABASE campusmart CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
2. Impor skema tabel:
   ```bash
   mysql -u root -p campusmart < database/schema.sql
   ```
3. Impor data awal/seeder:
   ```bash
   mysql -u root -p campusmart < database/seeders.sql
   ```

### 3. Konfigurasi Environment (`.env`)
Salin file `.env.example` menjadi `.env` dan sesuaikan kredensial database Anda:
```ini
APP_NAME=CAMPUSMART
APP_ENV=development
APP_DEBUG=true
APP_URL=http://127.0.0.1:8080
APP_TIMEZONE=Asia/Jakarta

DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=campusmart
DB_USER=root
DB_PASS=

SESSION_LIFETIME=7200
SESSION_SECURE_COOKIE=false
CSRF_SECRET=campusmart_local_secret_key_2026
```

### 4. Menjalankan Server Lokal
Jalankan server PHP built-in dengan document root mengarah ke folder `public/`:
```bash
php -S 127.0.0.1:8080 -t public
```
Akses website melalui browser di: **http://127.0.0.1:8080**

---

## 🔑 Akun Demo Pengembangan

| Role | Email | Password | Hak Akses |
|---|---|---|---|
| **Administrator** | `admin@campusmart.id` | `Password123!` | Dashboard Admin, Kelola Produk, Kategori, Pesanan, Verifikasi Pembayaran, Kelola Pengguna, Laporan Penjualan |
| **Mahasiswa** | `dina@gmail.com` | `Password123!` | Katalog, Keranjang, Checkout QRIS/COD, Upload Bukti Transfer, Riwayat Pesanan, Profil |
| **Mahasiswa** | `aryasyah@gmail.com` | `Password123!` | Akun uji coba isolasi keranjang & IDOR cross-tenant |

---

## 🧪 Menjalankan Pengujian Sistem (Automated QA)

Jalankan test suite komprehensif (mencakup 66 skenario functional, boundary, race conditions, stock recovery, CSRF, XSS, SQLi, IDOR, dan audit laporan keuangan):
```bash
php tests/system_qa_test.php
```

Pemeriksaan sintaks PHP pada seluruh file:
```powershell
Get-ChildItem -Path app, routes, views -Filter *.php -Recurse | ForEach-Object { php -l $_.FullName }
```

---

## 🔒 Kebijakan Transaksi & Pembayaran

1. **Stok & Penguncian Transaksi:**
   - Stok dikunci menggunakan `SELECT ... FOR UPDATE` saat checkout.
   - Stok dipotong secara otomatis saat pesanan dibuat.
   - Jika pesanan dibatalkan (`cancelled`), stok dikembalikan secara otomatis dan aman ke produk (hanya sekali).
2. **Metode Pembayaran:**
   - **QRIS**: Berstatus awal `pending_verification`. Mahasiswa mengunggah bukti transfer, admin memverifikasi secara manual tercatat di histori log audit.
   - **COD**: Berstatus awal `unpaid`. Petugas counter mengonfirmasi pembayaran menjadi `paid` saat serah-terima fisik di counter kampus.
3. **Ongkos Kirim:**
   - Pengambilan dilakukan langsung di **Counter Resmi CampusMart, Gedung Rektorat Lt. 1, Horizon University Indonesia** tanpa biaya ekspedisi (**Rp 0**).
