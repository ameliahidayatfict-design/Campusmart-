<?php
/**
 * CAMPUSMART — Comprehensive System QA & Security Test Suite (Tahap 11)
 * Run via CLI: php tests/system_qa_test.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/helpers/helpers.php';

// PSR-4 Autoloader
spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    $baseDir = __DIR__ . '/../app/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});

use App\Core\Database;
use App\Core\Session;
use App\Core\CSRF;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Setting;
use App\Services\UploadService;

$passedCount = 0;
$failedCount = 0;
$findings = [
    'P0' => [],
    'P1' => [],
    'P2' => [],
    'P3' => [],
];

function test(string $name, bool $condition, ?string $failDetail = null, string $severity = 'P1'): void {
    global $passedCount, $failedCount, $findings;
    if ($condition) {
        echo "  [PASS] {$name}\n";
        $passedCount++;
    } else {
        echo "  [FAIL] {$name}" . ($failDetail ? " — {$failDetail}" : "") . "\n";
        $failedCount++;
        $findings[$severity][] = "{$name}: {$failDetail}";
    }
}

echo "====================================================================\n";
echo "   CAMPUSMART — SYSTEM QA, BOUNDARY & SECURITY AUDIT (TAHAP 11)     \n";
echo "====================================================================\n\n";

$pdo = Database::getConnection();

// ====================================================================
// 1. FUNCTIONAL END-TO-END TESTING
// ====================================================================
echo "=== 1. Functional End-to-End Tests ===\n";

// 1.1 Registration & Unique Email Check
$testEmail = 'student.qa.' . time() . '@horizon.ac.id';
$duplicateEmail = 'dina@gmail.com';
test("Check unique email allows unused address", User::isEmailUnique($testEmail));
test("Check unique email rejects registered address", !User::isEmailUnique($duplicateEmail));

$createdStudentId = User::create([
    'name' => 'Mahasiswa QA System',
    'email' => $testEmail,
    'password_hash' => password_hash('Secret123!', PASSWORD_BCRYPT),
    'student_id' => '2026QA' . substr((string)time(), -4),
    'phone' => '081234500999',
    'role' => 'student',
    'status' => 'active',
]);
test("Registration creates user with ID", $createdStudentId > 0);

$studentUser = User::findById($createdStudentId);
test("Registered user strictly has role 'student'", $studentUser && $studentUser['role'] === 'student');

// 1.2 Authentication & Password Verification
$authSuccess = password_verify('Secret123!', $studentUser['password_hash']);
$authFail = password_verify('WrongPassword!', $studentUser['password_hash']);
test("Authentication succeeds with valid password", $authSuccess);
test("Authentication fails with invalid password", !$authFail);

// 1.3 Product & Category Browsing
$allCategories = Category::all(true);
test("Category list retrieved", count($allCategories) > 0);

$categorySlug = $allCategories[0]['slug'];
$filteredProducts = Product::paginate(['category_slug' => $categorySlug], 1, 10);
test("Product catalog filter by category works", isset($filteredProducts['items']));

$searchProducts = Product::paginate(['q' => 'Buku'], 1, 10);
test("Product search by keyword works", count($searchProducts['items']) > 0);

// 1.4 Cart CRUD
Cart::clearCart($createdStudentId);
test("Initial cart is empty", Cart::countItems($createdStudentId) === 0);

$testProduct = Product::findById(1); // Buku Catatan Spiral
$addCart = Cart::addItem($createdStudentId, (int)$testProduct['id'], 2);
test("Add product to cart succeeds", $addCart['success']);
test("Cart count is 2", Cart::countItems($createdStudentId) === 2);

$updateCart = Cart::updateItem($createdStudentId, (int)$testProduct['id'], 3);
test("Update quantity in cart succeeds", $updateCart['success']);
test("Cart count updated to 3", Cart::countItems($createdStudentId) === 3);

$totals = Cart::getTotals($createdStudentId);
$expectedTotal = (float)$testProduct['price'] * 3;
test("Cart subtotal matches exact unit price * qty", abs($totals['subtotal'] - $expectedTotal) < 0.01);
test("Campus shipping fee is strictly Rp 0", abs($totals['total'] - $totals['subtotal']) < 0.01);

Cart::removeItem($createdStudentId, (int)$testProduct['id']);
test("Remove item from cart succeeds", Cart::countItems($createdStudentId) === 0);

// 1.5 Checkout with QRIS
Cart::addItem($createdStudentId, (int)$testProduct['id'], 1);
$qrisOrder = Order::createOrder(
    $createdStudentId,
    $studentUser['name'],
    $studentUser['email'],
    $studentUser['phone'],
    'Catatan QRIS QA',
    'qris',
    null
);
test("QRIS checkout transaction succeeds", $qrisOrder['success']);
$qrisOrderId = $qrisOrder['order_id'];
$qrisOrderData = Order::findById($qrisOrderId);
test("QRIS initial order status is 'pending'", $qrisOrderData['status'] === 'pending');
test("QRIS initial payment status is 'pending_verification'", $qrisOrderData['payment_status'] === 'pending_verification');

// 1.6 Checkout with COD
Cart::addItem($createdStudentId, (int)$testProduct['id'], 1);
$codOrder = Order::createOrder(
    $createdStudentId,
    $studentUser['name'],
    $studentUser['email'],
    $studentUser['phone'],
    'Catatan COD QA',
    'cod',
    null
);
test("COD checkout transaction succeeds", $codOrder['success']);
$codOrderId = $codOrder['order_id'];
$codOrderData = Order::findById($codOrderId);
test("COD initial order status is 'pending'", $codOrderData['status'] === 'pending');
test("COD initial payment status is 'unpaid' (not auto paid)", $codOrderData['payment_status'] === 'unpaid');

// 1.7 Order Items Snapshot & History
$itemsSnapshot = Order::getItems($qrisOrderId);
test("Order items snapshot count is 1", count($itemsSnapshot) === 1);
test("Order item snapshot has product name", $itemsSnapshot[0]['product_name'] === $testProduct['name']);
test("Order item snapshot has exact unit price", (float)$itemsSnapshot[0]['unit_price'] === (float)$testProduct['price']);

$qrisHistories = Order::getHistories($qrisOrderId);
test("Order history has initial log", count($qrisHistories) >= 1 && $qrisHistories[0]['new_status'] === 'pending');

// 1.8 Admin Payment Verification
$adminUser = User::findByEmail('admin@campusmart.id');
$adminId = (int)$adminUser['id'];

$verifyPayment = Order::updatePaymentStatus($qrisOrderId, 'paid', $adminId);
test("Admin approves payment to 'paid'", $verifyPayment);
$verifiedOrder = Order::findById($qrisOrderId);
test("Order payment_status is updated to 'paid'", $verifiedOrder['payment_status'] === 'paid');

// 1.9 Order State Machine Transitions
// Transitions allowed: pending -> confirmed -> processing -> ready_for_pickup -> completed
$t1 = Order::updateStatus($qrisOrderId, 'confirmed', $adminId, 'Pesanan dikonfirmasi');
test("Transition: pending -> confirmed succeeds", $t1);

$t2 = Order::updateStatus($qrisOrderId, 'processing', $adminId, 'Sedang disiapkan');
test("Transition: confirmed -> processing succeeds", $t2);

$t3 = Order::updateStatus($qrisOrderId, 'ready_for_pickup', $adminId, 'Siap diambil di counter');
test("Transition: processing -> ready_for_pickup succeeds", $t3);

$t4 = Order::updateStatus($qrisOrderId, 'completed', $adminId, 'Barang diserahterimakan');
test("Transition: ready_for_pickup -> completed succeeds", $t4);

// Terminal state: completed cannot transition to anything
$illegalFromCompleted = Order::updateStatus($qrisOrderId, 'pending', $adminId);
test("Illegal transition from completed is blocked", !$illegalFromCompleted);

// ====================================================================
// 2. BOUNDARY & CONCURRENCY TESTING
// ====================================================================
echo "\n=== 2. Boundary & Concurrency Tests ===\n";

// 2.1 Zero Stock Purchase Check
$zeroStockProduct = Product::create([
    'category_id' => $allCategories[0]['id'],
    'name' => 'Produk Habis QA',
    'slug' => 'produk-habis-qa-' . time(),
    'description' => 'Test produk stok 0',
    'price' => 15000,
    'stock' => 0,
    'status' => 'active',
]);
$addZeroStock = Cart::addItem($createdStudentId, $zeroStockProduct, 1);
test("Cart rejects adding product with 0 stock", !$addZeroStock['success']);

// 2.2 Exact Stock Purchase & Stock Exhaustion
$exactStockProduct = Product::create([
    'category_id' => $allCategories[0]['id'],
    'name' => 'Produk Stok Pas QA',
    'slug' => 'produk-stok-pas-qa-' . time(),
    'description' => 'Test produk stok pas 2 unit',
    'price' => 20000,
    'stock' => 2,
    'status' => 'active',
]);

Cart::clearCart($createdStudentId);
Cart::addItem($createdStudentId, $exactStockProduct, 2);
$exactOrder = Order::createOrder($createdStudentId, 'Tester', 'test@test.com', '08123', null, 'cod');
test("Purchase exact stock succeeds", $exactOrder['success']);

$updatedProduct = Product::findById($exactStockProduct);
test("Stock drops exactly to 0 after purchasing exact stock", (int)$updatedProduct['stock'] === 0);

// 2.3 Purchasing more than available stock
Cart::clearCart($createdStudentId);
$addMoreThanStock = Cart::addItem($createdStudentId, $exactStockProduct, 1);
test("Cannot add to cart when stock is now 0", !$addMoreThanStock['success']);

// 2.4 Deactivated Product in Cart Blocked at Checkout
$tempProduct = Product::create([
    'category_id' => $allCategories[0]['id'],
    'name' => 'Produk Akan Dinonaktifkan',
    'slug' => 'produk-deaktif-' . time(),
    'description' => 'Test',
    'price' => 10000,
    'stock' => 10,
    'status' => 'active',
]);
Cart::addItem($createdStudentId, $tempProduct, 2);

// Now deactivate product in DB
Product::update($tempProduct, [
    'category_id' => $allCategories[0]['id'],
    'name' => 'Produk Akan Dinonaktifkan',
    'slug' => 'produk-deaktif-' . time(),
    'description' => 'Test',
    'price' => 10000,
    'stock' => 10,
    'status' => 'inactive',
]);

$checkoutInactive = Order::createOrder($createdStudentId, 'Tester', 'test@test.com', '08123', null, 'cod');
test("Checkout is blocked if product becomes inactive while in cart", !$checkoutInactive['success']);
Cart::clearCart($createdStudentId);

// 2.5 Price Changed in DB while in Cart
// Server recalculates from products table under FOR UPDATE lock
$priceChangeProduct = Product::create([
    'category_id' => $allCategories[0]['id'],
    'name' => 'Produk Harga Berubah',
    'slug' => 'produk-harga-berubah-' . time(),
    'description' => 'Test',
    'price' => 50000,
    'stock' => 10,
    'status' => 'active',
]);
Cart::addItem($createdStudentId, $priceChangeProduct, 1);

// Admin updates price to 60000 in DB
Product::update($priceChangeProduct, [
    'category_id' => $allCategories[0]['id'],
    'name' => 'Produk Harga Berubah',
    'slug' => 'produk-harga-berubah-' . time(),
    'description' => 'Test',
    'price' => 60000,
    'stock' => 10,
    'status' => 'active',
]);

$orderPriceCheck = Order::createOrder($createdStudentId, 'Tester', 'test@test.com', '08123', null, 'cod');
test("Checkout succeeds with updated price", $orderPriceCheck['success']);
$createdPriceOrder = Order::findById($orderPriceCheck['order_id']);
test("Server recalculated order total using fresh DB price (60000)", (float)$createdPriceOrder['total'] === 60000.0);

// 2.6 Order Cancellation and Stock Restoration
$cancelProduct = Product::create([
    'category_id' => $allCategories[0]['id'],
    'name' => 'Produk Cancel Restorasi',
    'slug' => 'produk-cancel-restorasi-' . time(),
    'description' => 'Test',
    'price' => 10000,
    'stock' => 5,
    'status' => 'active',
]);
Cart::addItem($createdStudentId, $cancelProduct, 2);
$orderToCancel = Order::createOrder($createdStudentId, 'Tester', 'test@test.com', '08123', null, 'cod');
$orderToCancelId = $orderToCancel['order_id'];

$stockAfterOrder = (int)Product::findById($cancelProduct)['stock'];
test("Stock decremented to 3 after checkout", $stockAfterOrder === 3);

$cancelRes = Order::updateStatus($orderToCancelId, 'cancelled', $adminId, 'Dibatalkan untuk uji restorasi stok');
test("Order successfully cancelled", $cancelRes);

$stockAfterCancel = (int)Product::findById($cancelProduct)['stock'];
test("Stock safely restored back to 5 after cancellation", $stockAfterCancel === 5);

// 2.7 Repeated Cancellation Prevention (Stock MUST NOT increase twice)
$repeatedCancelRes = Order::updateStatus($orderToCancelId, 'cancelled', $adminId, 'Coba cancel ulang');
test("Repeated cancellation of cancelled order is rejected", !$repeatedCancelRes);

$stockAfterRepeatedCancel = (int)Product::findById($cancelProduct)['stock'];
test("Stock remains 5 and was NOT increased a second time", $stockAfterRepeatedCancel === 5);

// 2.8 Cancelled order cannot be marked as Paid
$payCancelledOrder = Order::updatePaymentStatus($orderToCancelId, 'paid', $adminId);
test("Cancelled order cannot be marked as paid", !$payCancelledOrder);

// 2.9 Two Checkouts against Limited Stock (Stock = 1 Concurrency Simulation)
$contestedProduct = Product::create([
    'category_id' => $allCategories[0]['id'],
    'name' => 'Produk Stok Rebutan Concurrency',
    'slug' => 'produk-rebutan-' . time(),
    'description' => 'Test',
    'price' => 35000,
    'stock' => 1,
    'status' => 'active',
]);

// Both student 1 and student 2 put the last unit in their carts
Cart::clearCart($createdStudentId);
Cart::clearCart(2); // Dina
Cart::addItem($createdStudentId, $contestedProduct, 1);
Cart::addItem(2, $contestedProduct, 1);

// User A orders first
$resA = Order::createOrder($createdStudentId, 'Tester A', 'testerA@test.com', '0811', null, 'cod');
// User B orders immediately after
$resB = Order::createOrder(2, 'Tester B', 'testerB@test.com', '0822', null, 'cod');

$finalContestedStock = (int)Product::findById($contestedProduct)['stock'];
test("First user secures the last available stock", $resA['success'] === true);
test("Second user checkout is rejected due to exhausted stock under lock", $resB['success'] === false);
test("Stock drops to exactly 0 and NEVER becomes negative", $finalContestedStock === 0);
test("Second user cart remains intact because checkout failed", Cart::countItems(2) === 1);
Cart::clearCart(2);

// ====================================================================
// 3. SECURITY TESTING
// ====================================================================
echo "\n=== 3. Security Tests ===\n";

// 3.1 SQL Injection resistance
$sqlInjectionPayload = "1' OR '1'='1";
$sqlInjectionSearch = Product::paginate(['q' => $sqlInjectionPayload], 1, 10);
test("SQL Injection in search query treated safely as literal", isset($sqlInjectionSearch['items']));

$sqlInjectionLogin = User::findByEmail("admin@campusmart.id' OR '1'='1");
test("SQL Injection in login email query returns null safely", $sqlInjectionLogin === null);

// 3.2 Cross-Site Scripting (XSS) output escaping
$xssPayload = '<script>alert("XSS")</script><img src=x onerror=alert(1)>';
$escapedXSS = e($xssPayload);
test("Helper e() escapes script tags completely", !str_contains($escapedXSS, '<script>'));
test("Helper e() converts HTML quotes and brackets", str_contains($escapedXSS, '&lt;script&gt;'));

// 3.3 CSRF Protection Token Validation
Session::start();
$validToken = CSRF::getToken();
test("CSRF getToken generates 64-char hex token", strlen($validToken) === 64);
test("CSRF validates genuine token", CSRF::validateToken($validToken));
test("CSRF rejects empty token", !CSRF::validateToken(''));
test("CSRF rejects forged token", !CSRF::validateToken('forged_fake_token_12345678901234567890123456789012345678901234'));

// 3.4 IDOR Protection (Tenant Isolation)
$student2Id = 2; // Dina
$student3Id = 3; // Arya
$student2Order = Order::paginate(['user_id' => $student2Id], 1, 1)['items'][0] ?? null;

if ($student2Order) {
    test("IDOR check: Student 3 cannot access Student 2's order", (int)$student2Order['user_id'] !== $student3Id);
}

// 3.5 File Upload Validation
$fakePhpFile = [
    'name' => 'webshell.php',
    'type' => 'application/x-php',
    'tmp_name' => '',
    'error' => UPLOAD_ERR_OK,
    'size' => 1024,
];
// Test extension filtering
$ext = strtolower(pathinfo($fakePhpFile['name'], PATHINFO_EXTENSION));
test("Upload rejects dangerous .php extension", !in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true));

// Test excessive file size (> 2MB)
$oversizedFile = [
    'name' => 'huge_image.png',
    'type' => 'image/png',
    'tmp_name' => '',
    'error' => UPLOAD_ERR_OK,
    'size' => 3 * 1024 * 1024, // 3MB
];
test("Upload rejects file exceeding 2MB limit", $oversizedFile['size'] > 2097152);

// ====================================================================
// 4. PAYMENT & REVENUE REPORT RECONCILIATION AUDIT
// ====================================================================
echo "\n=== 4. Payment & Financial Report Audit ===\n";

$report = Order::getSalesReport([]);
$metrics = $report['metrics'];

test("Report GMV excludes cancelled orders", (float)$metrics['total_gmv'] >= (float)$metrics['total_paid_revenue']);

// Sum of actual paid orders from DB directly
$directPaidSum = (float)$pdo->query("SELECT COALESCE(SUM(total), 0) FROM orders WHERE payment_status = 'paid'")->fetchColumn();
test("Aggregated report paid revenue matches actual orders database exactly", abs((float)$metrics['total_paid_revenue'] - $directPaidSum) < 0.01);

// Cancelled orders revenue is 0
$cancelledRevenueInReport = (float)$pdo->query("SELECT COALESCE(SUM(total), 0) FROM orders WHERE status = 'cancelled' AND payment_status = 'paid'")->fetchColumn();
test("Zero cancelled orders are marked as paid in the database", $cancelledRevenueInReport === 0.0);

// Top products query validation
test("Top products list is limited to 5 products", count($report['top_products']) <= 5);

// ====================================================================
// SUMMARY
// ====================================================================
echo "\n====================================================================\n";
echo "   SYSTEM QA AUDIT FINISHED: {$passedCount} PASSED, {$failedCount} FAILED\n";
echo "====================================================================\n";

if ($failedCount > 0) {
    exit(1);
}
